
<?php

include "funciones.php";
function replace($cadena) {
	$cadena = str_replace("&AACUTE;", "Á", $cadena);
	$cadena = str_replace("&EACUTE;", "É", $cadena);
	$cadena = str_replace("&IACUTE;", "Í", $cadena);
	$cadena = str_replace("&OACUTE;", "Ó", $cadena);
	$cadena = str_replace("&UACUTE;", "Ú", $cadena);
	$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
	$cadena = str_replace("&aacute;", "á", $cadena);
	$cadena = str_replace("&eacute;", "é", $cadena);
	$cadena = str_replace("&iacute;", "í", $cadena);
	$cadena = str_replace("&oacute;", "ó", $cadena);
	$cadena = str_replace("&uacute;", "ú", $cadena);
	$cadena = str_replace("&ntilde;", "ñ", $cadena);
	return $cadena;
}
	$idAlumno = $_POST['id'];
	
	
	function generaTabla($id,$campo)
{
	$consulta = "select $campo,Nombre,Apellidos,AprobacionRegistro,AprobacionTrabajo from AsignacionDeSinodal,Profesor,firmarAutorizaciones where AsignacionDeSinodal.IdEstudiante = $id and Profesor.IdProfesor=AsignacionDeSinodal.$campo and firmarAutorizaciones.IdProfesor = AsignacionDeSinodal.$campo and firmarAutorizaciones.IdEstudiante = $id";
	$resultado = conexionMysql($consulta);
	
	if( mysql_num_rows($resultado) > 0 ) 
	{	
	
	echo "<td>"; echo replace(mysql_result($resultado, 0, 'Nombre')) ." ". replace(mysql_result($resultado, 0, 'Apellidos')); echo "</td>"; 
	echo "<td>"; 
	if ( mysql_result($resultado, 0, 'AprobacionRegistro') == true )
		echo "<label>SI</label>";
	else
		echo "<label>NO HA FIRMADO</label>";
	echo "</td>";
	
	echo "<td>";	 
	if ( mysql_result($resultado, 0, 'AprobacionTrabajo') == true )
		echo "<label>SI</label>";
	else
		echo "<label>NO HA FIRMADO</label>";
	echo "</td>";
	}
}	
	
	if( $idAlumno > 0 ) 
	{
		echo "<table border>";
			echo "<tr>";
				echo "<td><br></td>"; 
				echo "<th>"; echo "NOMBRE"; echo "</th>";
				echo "<th>"; echo "APROBÓ REGISTRO"; echo "</th>";
				echo "<th>"; echo "APROBÓ TRABAJO"; echo "</th>";
			echo "</tr>";
					
			echo "<tr>"; 
				echo "<th>"; echo "PRESIDENTE"; echo "</th>";
				generaTabla($idAlumno,'Presidente');				
			echo "</tr>";
			
			echo "<tr>"; echo "<th>";  echo "SECRETARIO"; echo "</th>";
				generaTabla($idAlumno,'Secretario');
			echo "</tr>";
			
			echo "<tr>"; 
				echo "<th>";  echo "VOCAL"; echo "</th>";
				generaTabla($idAlumno,'Vocal');
			echo "</tr>";
			
			echo "<tr>"; 
				echo "<th>"; echo "SUPLENTE"; echo "</th>";
				generaTabla($idAlumno,'Suplente');
				echo "</tr>";		
		echo "</table>";
	}
	else 
	{
		echo "<label>Selecciona un alumno.</label>";
	}
	
	
?>