<?php

include 'funciones.php';

function replace($cadena) {
	$cadena = str_replace("&AACUTE;", "Á", $cadena);
	$cadena = str_replace("&EACUTE;", "É", $cadena);
	$cadena = str_replace("&IACUTE;", "Í", $cadena);
	$cadena = str_replace("&OACUTE;", "Ó", $cadena);
	$cadena = str_replace("&UACUTE;", "Ú", $cadena);
	$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
	$cadena = str_replace("&aacute;", "á", $cadena);
	$cadena = str_replace("&eacute;", "é", $cadena);
	$cadena = str_replace("&iacute;", "í", $cadena);
	$cadena = str_replace("&oacute;", "ó", $cadena);
	$cadena = str_replace("&uacute;", "ú", $cadena);
	$cadena = str_replace("&ntilde;", "ñ", $cadena);
	$cadena = str_replace("&Aacute;", "Á", $cadena);
	$cadena = str_replace("&Eacute;", "É", $cadena);
	$cadena = str_replace("&Iacute;", "Í", $cadena);
	$cadena = str_replace("&Oacute;", "Ó", $cadena);
	$cadena = str_replace("&Uacute;", "Ú", $cadena);
	$cadena = str_replace("&Ntilde;", "Ñ", $cadena);
	
	return $cadena;
}

// Array que vincula los IDs de los selects declarados en el HTML con el nombre de la tabla donde se encuentra su contenido
$listadoSelects=array(
"alumnos"=>"Estudiante",
"documento"=>"Documentos"
);

function validaSelect($selectDestino)
{
	// Se valida que el select enviado via GET exista
	global $listadoSelects;
	if(isset($listadoSelects[$selectDestino])) return true;
	else return false;
}

function validaOpcion($opcionSeleccionada)
{
	// Se valida que la opcion seleccionada por el usuario en el select tenga un valor numerico
	if(is_numeric($opcionSeleccionada)) return true;
	else return false;
}

$selectDestino=$_GET["select"]; $opcionSeleccionada=$_GET["opcion"];

if(validaSelect($selectDestino) && validaOpcion($opcionSeleccionada))
{
	$consulta = sprintf("SELECT OpcionDeTitulacion,Reticula FROM Estudiante WHERE IdEstudiante = $opcionSeleccionada ");
	$resultado = conexionMysql($consulta);
	
				/**************************************************************************************
				******************   VI (EXAMEN GLOBAL POR ÁREAS DEL CONOCIMIENTO)  *******************
				**************************************************************************************/
												
				if( replace(mysql_result($resultado,0,'OpcionDeTitulacion')) == "VI (EXAMEN GLOBAL POR ÁREAS DEL CONOCIMIENTO)" ) 
				{
						// Comienzo a imprimir el select
					echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
						echo "<option value='doc19'>"; echo "Asignacion de Jurados opc 6 (Egel), 8 y 9 - división";echo"</option>";
						echo "<option value='doc12'>"; echo "Cambio de jurado(Escolares)";echo"</option>";
						echo "<option value='doc14'>"; echo "Cambio de jurado(Division)";echo"</option>";
					echo "</select>";				
				}
				
				/**************************************************************************************
				***********************   VII (MEMORIA DE EXPERIENCIA PROFESIONAL)  *******************
				**************************************************************************************/
								
				elseif( replace(mysql_result($resultado,0,'OpcionDeTitulacion')) == "VII (MEMORIA DE EXPERIENCIA PROFESIONAL)") 
				{
					// Comienzo a imprimir el select
					echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
						echo "<option value='doc20'>"; echo "Paso 1 .-Asignacion Asesor Memoria Experiencia Profesional";echo"</option>";
						echo "<option value='doc21'>"; echo "Paso 2 .- Asignacion y Comision Revisores - depto";echo"</option>";
						echo "<option value='doc22'>"; echo "Paso 3 .-Autorizacion Registro - depto";echo"</option>";
						echo "<option value='doc23'>"; echo "Paso 4 .- Se Autoriza Registro de opcion - división";echo"</option>";
						echo "<option value='doc24'>"; echo "Paso 5 .-Solicitud autorizacion impresion - división";echo"</option>";
						echo "<option value='doc12'>"; echo "Cambio de jurado(Escolares)";echo"</option>";
						echo "<option value='doc14'>"; echo "Cambio de jurado(Division)";echo"</option>";
					echo "</select>";				
				}
				
				/**************************************************************************************
				********************************   VIII (ESCOLARIDAD POR PROMEDIO)  *******************
				**************************************************************************************/
								
				elseif( replace(mysql_result($resultado,0,'OpcionDeTitulacion')) == "VIII (ESCOLARIDAD POR PROMEDIO)") 
				{
					// Comienzo a imprimir el select
					echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
						echo "<option value='doc19'>"; echo "Asignacion de Jurados opc 6 (Egel), 8 y 9 - división";echo"</option>";
						echo "<option value='doc12'>"; echo "Cambio de jurado(Escolares)";echo"</option>";
						echo "<option value='doc14'>"; echo "Cambio de jurado(Division)";echo"</option>";
					echo "</select>";				
				}
				
				/**************************************************************************************
				**********************   IX (ESCOLARIRAD POR ESTUDIOS DE POSGRADO)  *******************
				**************************************************************************************/
				
				elseif( replace(mysql_result($resultado,0,'OpcionDeTitulacion')) == "IX (ESCOLARIRAD POR ESTUDIOS DE POSGRADO)" ) 
				{
					// Comienzo a imprimir el select
					echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
						echo "<option value='doc19'>"; echo "Asignacion de Jurados opc 6 (Egel), 8 y 9 - división";echo"</option>";
						echo "<option value='doc12'>"; echo "Cambio de jurado(Escolares)";echo"</option>";
						echo "<option value='doc14'>"; echo "Cambio de jurado(Division)";echo"</option>";
					echo "</select>";				
				}
				
				/**************************************************************************************
				**************************   X (INFORME DE RESIDENCIA PROFESIONAL)  *******************
				**************************************************************************************/
								
				elseif( replace(mysql_result($resultado,0,'OpcionDeTitulacion')) == "X (INFORME DE RESIDENCIA PROFESIONAL)" ) 
				{
					// Comienzo a imprimir el select
					echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
						echo "<option value='doc25'>"; echo "Paso 1 .- Asignacion y Comision Revisores - depto";echo"</option>";
						echo "<option value='doc26'>"; echo "Paso 2 .-Autorizacion Registro - depto";echo"</option>";
						echo "<option value='doc27'>"; echo "Paso 3 .- Se Autoriza Registro de opcion - división";echo"</option>";
						echo "<option value='doc28'>"; echo "Paso 4 .-Solicitud autorizacion impresion - división";echo"</option>";						
						echo "<option value='doc12'>"; echo "Cambio de jurado(Escolares)";echo"</option>";
						echo "<option value='doc14'>"; echo "Cambio de jurado(Division)";echo"</option>";
					echo "</select>";				
				}
				
				/**************************************************************************************
				*******************   (INFORME TÉCNICO DE RESIDENCIA PROFESIONAL)2010  ****************
				**************************************************************************************/
								
				elseif( replace(mysql_result($resultado,0,'OpcionDeTitulacion')) == "(INFORME TÉCNICO DE RESIDENCIA PROFESIONAL)" ) 
				{
					// Comienzo a imprimir el select
					echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
						echo "<option value='doc29'>"; echo "Paso 1 .-Asignacion y Comision Revisores - depto - producto";echo"</option>";
						echo "<option value='doc30'>"; echo "Paso 2 .-Autorizacion Registro - depto - producto";echo"</option>";
						echo "<option value='doc31'>"; echo "Paso 3 .-Proyecto Titulacion Integral - Registro";echo"</option>";
						echo "<option value='doc32'>"; echo "Paso 4 .-Proyecto Titulacion Integral - Liberacion sin cedula";echo"</option>";						
						echo "<option value='doc33'>"; echo "Paso 5 .-Asignacion de Jurados Titulacion Integral";echo"</option>";
						echo "<option value='doc12'>"; echo "Cambio de jurado(Escolares)";echo"</option>";
						echo "<option value='doc14'>"; echo "Cambio de jurado(Division)";echo"</option>";
					echo "</select>";				
				}
				else
				{
					echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
					echo"<option>".replace(mysql_result($resultado,0,'OpcionDeTitulacion'))."</option>";						
					echo "</select>";		
				}
}
?>
