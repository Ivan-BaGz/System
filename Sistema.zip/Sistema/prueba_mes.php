<html>
	<head>
	
	</head>

	<body>
		
		<?php
		include 'funciones.php';
		
		//Muestra registros de  cada mes		
		
		$consulta = sprintf("select distinct FechaYHoraDeRegistro from Estudiante"); 
		$resultado = conexionMysql($consulta);
				
		$contador = 0;
		?>
		<form action="bitacora1.php" method="post">		
		
		<?php
		while( $fila = mysql_fetch_assoc($resultado) ) 
		{//inicio del while
		 $contador++;
		}

		echo $contador. "<br>"; 		
		
		for( $i=0; $i < $contador; $i++ ) 
		{
			$fecha = mysql_result($resultado,$i,'FechaYHoraDeRegistro');
		
			preg_match('/(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})/',$fecha,$partes);
			
		$fecha = $partes[1]."-".$partes[2];
		//arreglo con los meses del año
		$array_meses = array('Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre');
		
		//variable para el envio del mes		
		$mes = "";				
				
		//echo "<option value='$fecha'>";
			$encontrado = false;
			$j = 1;
			while( $encontrado == false )
			{
				if( $partes[2] == $j )
				{
					echo $partes[2]."<br>";
					$mes = $array_meses[$j-1];
					echo $array_meses[$j-1] . "-" .$partes[1];
					$encontrado = true;
				}
				$j++;	
			}
		echo "</option>";
			
		}//cierre del for()
		?>
		
		<?php
			echo "<input type='hidden' name='mes' value='".$mes."' >";
		?>
		<input type="submit" name="envia_fecha" value="Mostrar alumnos">
		</form>
	</body>	
	
</html>