
<?php

error_reporting( E_ERROR | E_WARNING );
include 'funciones.php';

function replace($cadena) {
	$cadena = str_replace("&AACUTE;", "Á", $cadena);
	$cadena = str_replace("&EACUTE;", "É", $cadena);
	$cadena = str_replace("&IACUTE;", "Í", $cadena);
	$cadena = str_replace("&OACUTE;", "Ó", $cadena);
	$cadena = str_replace("&UACUTE;", "Ú", $cadena);
	$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
	$cadena = str_replace("&aacute;", "á", $cadena);
	$cadena = str_replace("&eacute;", "é", $cadena);
	$cadena = str_replace("&iacute;", "í", $cadena);
	$cadena = str_replace("&oacute;", "ó", $cadena);
	$cadena = str_replace("&uacute;", "ú", $cadena);
	$cadena = str_replace("&ntilde;", "ñ", $cadena);
	return $cadena;
}

	function generaAlumnos() {
			
		//lista muestra los alumnos registrados	
		//echo "<label>SELECCIONA UN ALUMNO PARA CREAR DOCUMENTO<label>";	
		echo "<select name='alumnos' id='alumnos' onchange='mostrarInfo(this.value)' class='form-control' style='width:300;'>";
		echo "<option value='0'>Selecciona un alumno</option>";
		//Formular la consulta
		$consulta = sprintf("SELECT Nombre,Apellidos,IdEstudiante FROM Estudiante");
		$resultado = conexionMysql($consulta);			
		while($fila = mysql_fetch_assoc($resultado))
		{
			
			$id= $fila['IdEstudiante'];
			echo "<option value=$id ";
				if( $_POST["alumnos"] == $id )
				{ 
				echo "selected='selected'"; 
				}
				echo ">";
			echo replace($fila['Nombre']) . " " . replace($fila['Apellidos']);
			echo "</option>";
		}
		echo "</select>";
}

function notificacionAprobaciones() 
{
	
	//consultar la tabla de notificaciones
	$consulta = sprintf("select Estudiante.IdEstudiante as Id,Nombre,Apellidos,notAprobReg,notAprobTrab from notificaciones,Estudiante where notificaciones.IdEstudiante = Estudiante.IdEstudiante");
	$resultado = conexionMysql($consulta);	
	
	if( mysql_num_rows($resultado) > 0 ) 
	{	
		
		while( $fila = mysql_fetch_assoc($resultado) ) 
		{
			//variables que proporciona si o no notificar
			$notAprobReg = $fila['notAprobReg'];
			$notAprobTrab = $fila['notAprobTrab'];
			$id = $fila['Id'];
			
			if( $notAprobReg == true || $notAprobTrab == true)  
			{
				echo "<tr>";
					echo "<td bgcolor='#d0e7ff'><input type='checkbox' name='borrar[]' id='borrar[]' value='$id'>Eliminar esta notificación</td>"; 
					echo "<td bgcolor='#d0e7ff'>".replace($fila['Nombre'])." ".replace($fila['Apellidos'])."</td>";
					if( $notAprobReg == true )					 
					 echo "<td bgcolor='#d0e7ff'>Aprobación del Registro</td>";
					if( $notAprobTrab == true )
					 echo "<td bgcolor='#d0e7ff'>Aprobación del trabajo</td>";
				echo "</tr>";
			} 	
		}
	}
	else 
	{
		echo "<p>AUN NO HAY APROBACIONES</p>";
	}
}

?>

<html lang="es">
<head>

	<!--hoja de estilo para un ifrema-->
	
	<style type="text/css">
		#iframe
    	{
    		overflow:auto;
    		width:700px;
    		height:100px;
    	}
	
	</style>
	
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Consultar | firmas</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
	
	<script type="text/javascript">
	
		function validaForm()
		{	
			//valida la lista de alumnos
			
			if( document.getElementById('alumnos').value == 0  )
			{
				alert('Selecciona un alumno.');
				document.consultarFirmas.alumnos.focus();
				return false;
			}
		
			return true;			
		}
		
		
		</script>
		
		<script>

function mostrarInfo(id){

if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("datos").innerHTML=xmlhttp.responseText;
}else{
document.getElementById("datos").innerHTML='Cargando...';
}
}
xmlhttp.open("POST","proceso.php",true);
xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send("id="+id);

}

</script>
	
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
						<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Estudiantes <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="estudiantesregistrados.php">Estudiantes registrados</a></li>
							<li><a href="asignarSinodal.php">Asignar Revisores</a></li>
							<li><a href="listaAlumnos.php">Crear Documentos</a></li>
							<li><a href="cambioJurado.php">Cambio de jurado</a></li>
							<li><a href="cambioTema.php">Cambio de tema de tesis</a></li>
							<li><a href="bitacora2.php">Bitácora</a></li>
							</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Profesores <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="consultarFirmas.php">Firmas Registradas</a></li>							
							<li><a href="profesoresregistrados.php">Profesores registrados</a></li>
							<li><a href="firmasOficina.php">Firmas de liberacion</a></li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrador<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="modificacionesAdministrador.php">Modificaciones</a></li>
							<li><a href="actualizarPlantillas.php">Actualizar plantillas</a></li>
							<li><a href="archivosSubidos.php">Ver plantillas actualizadas</a></li>
							<li><a href="descomprimeZip.php">Descomprimir archivos ZIP</a></li>
						</ul>
					</li>
					
					<?php
					
					/*
					//marcar como vista la notificacion
					if( !empty($_GET['visto']) )
					{
						$visto = $_GET['visto'];
						$update = "UPDATE notificaciones SET NotificacionVista=true";
						openConectionMysql();
						mysql_query($update);
					}
					*/
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAdministrador where visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					?>
					<li class="active3"><a class="btn" href="verMensajesAdmon.php"><?php echo $mensajes ?> Mensaje(s)</a></li>
					<?php
					}
					else
						echo '<li class="active"><a class="btn" href="verMensajesAdmon.php">Mensajeria</a></li>';
					?>
				
					<li class="active"><a class="btn" href="perfiladministrador.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Administrador</a></li>
			<li class="active">Consultar firmas</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Consultar firmas realizadas</h1>
				</header>
				
				<div class="col-md-8 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<label>Firmas realizadas</label>
							<hr>
<?php
							
if( isset($_POST['borrar_notificaciones']) ) 
	{
		if( !empty($_POST['borrar']) ) 
		{			
			$eliminar = $_POST['borrar'];
			
			foreach( $eliminar as $notificacion )
			{
				//consultar el estado de las notificaciones
				$consulta = "SELECT notAprobReg,notAprobTrab from notificaciones where IdEstudiante = $notificacion ";
				$resultado = conexionMysql($consulta);
				if( mysql_result($resultado,0,'notAprobReg') == true )
				{
					$update = "UPDATE notificaciones SET notAprobReg = false where IdEstudiante = $notificacion";
					mysql_query($update);
				}				
				if( mysql_result($resultado,0,'notAprobTrab') == true )
				{
					$update = "UPDATE notificaciones SET notAprobTrab = false where IdEstudiante = $notificacion";
					mysql_query($update);
				}
			}
			//$self = $_SERVER['PHP_SELF']; //Obtenemos la página en la que nos encontramos
			//header("refresh:1; url=$self"); //Refrescamos la pagina	
		}
	}
?>

<form action="consultarFirmas.php" method="post">
	<div id="iframe">
		<?php
			echo "<table width='100%' border style='border:1px solid #cccccc;' align='center' cellpadding='4' cellspacing='0'>";
			notificacionAprobaciones();
			echo "</table>";
		?>
	</div>
	<input type="submit" name="borrar_notificaciones" value="ELIMINAR" class="btn btn-danger">
</form>

<?php

echo "<br>";

generaAlumnos();
?>

<div id="datos"></div>						
															
						</div>
					</div>
				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
