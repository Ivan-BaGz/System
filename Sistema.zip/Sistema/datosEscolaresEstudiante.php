<?php include 'seguridadestudiante.php'; ?>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Datos | alumno</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
	<script type="text/javascript">
		function proyecto(e) {
			tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==190) { //punto
				return true;
			}
			if (tecla==32) { // espacio
				return true; 
			}
			if (tecla==60) { // <
				return false;
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==189) { // guión
				return true;
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (tecla==0) { // ¿ ñ
				return true;
			}
			if (tecla==188) {
				return true;
			}
			if (e.shiftKey && tecla==49 /* ! */ || e.shiftKey && tecla==50 /* "" */ ||  
				e.shiftKey && tecla==54 /* & */ || e.shiftKey && tecla==55 /* / */ ||
				e.shiftKey && tecla==48 /* = */ || e.shiftKey && tecla==186 /* ; */ || 
				e.shiftKey && tecla==191 /* ? */ || e.shiftKey && tecla==192 /* ¨ */ || 
				e.shiftKey && tecla==219 /* [ */ || e.shiftKey && tecla==220 /* | */ || 
				e.shiftKey && tecla==221 /* ] */ || e.shiftKey && tecla==222 /* '' */ || 
				e.shiftKey && tecla==187 /* * */ || e.shiftKey && tecla==60 /* > */ ||
				e.shiftKey && tecla==0 /* ¡ */ || e.shiftKey && tecla==171 /* * */ ||
				e.shiftKey && tecla==174 /* [ */ || e.shiftKey && tecla==175 /* ] */ ||
				e.shiftKey && tecla==52 /* $ */ || e.shiftKey && tecla==53 /* % */) {
				return false;
			} 
			if (e.shiftKey && tecla==51 /* # */ || e.shiftKey && tecla==56 /* ( */ || 
				e.shiftKey && tecla==57 /* ) */ || e.shiftKey && tecla==189 /* _ */ ) {
				return true;
			}
			if (tecla==187 || tecla==191 || tecla==192 || tecla==219 || tecla==220 || 
				tecla==221 || tecla==222 || tecla==171 /* + */ || tecla==174 /* { */ || tecla==175 /* } */) {
				return false;
			}
			if (tecla==255 && tecla==81) { // @
				return false;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[0-9a-zA-Z\W]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function validar() {
			if (document.getElementById('CambiarCarrera').checked==false && document.getElementById('CambiarReticula').checked==false && document.getElementById('CambiarOpcionDeTitulacion').checked==false && document.getElementById('ModificarProyecto').checked==false) {
					alert('Imposible guardar cambios. No se ha seleccionado ninguna opción');
					return false;
			}
		}
		function habilitar1() {
			document.form1.Carrera.disabled=!document.form1.Carrera.disabled;
		}
		function habilitar2() {
			document.form1.Reticula.disabled=!document.form1.Reticula.disabled;
		}
		function habilitar3() {
			document.form1.OpcionDeTitulacion.disabled=!document.form1.OpcionDeTitulacion.disabled;
		}
		function habilitar4() {
			document.form1.Proyecto.disabled=!document.form1.Proyecto.disabled;
		}
	</script>
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="#"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">	
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Tu información <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="datosPersonalesEstudiante.php">Información personal</a></li>
							<li><a href="datosEscolaresEstudiante.php">Información general</a></li>
						</ul>
					</li>
					<li><a href="procesoTitulacionEstudiante.php">Proceso de titulación</a></li>
					<?php
					include "funciones.php";
					
					session_name('loginUsuario');
					session_start();
					
					$id = $_SESSION["id"];					
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAlumno where IdEstudiante = $id and visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');

					$consulta2 = "select HacerCorrecciones,DatosCorregidos from Estudiante where IdEstudiante = $id";
					$resultado2 = conexionMysql($consulta2);
					$hacerCorrecciones = mysql_result($resultado2, 0, 'HacerCorrecciones');
					$datosCorregidos = mysql_result($resultado2, 0, 'DatosCorregidos');

					if( $mensajes > 0 ) {
					?>
					<li class='active3'><a class='btn' href='verMensajesAlumno.php'><?php echo $mensajes ?> Mensaje(s)</a></li>
		            <?php
					}
					else {
						echo "<li class='active'><a class='btn' href='verMensajesAlumno.php'>Mensajeria</a></li>";
					}
					if ($hacerCorrecciones == 1 && $datosCorregidos == "no") {
						echo "<li class='active2'><a class='btn' href=''>Corrige tus datos</a></li>";
					}
					?>
					<li class="active"><a class="btn" href="perfilestudiante.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Información general del egresado</h1>
				</header>
				<br><br>
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Información</h3>
							<br>
							<?php
								function replace($cadena) {
									$cadena = str_replace("&AACUTE;", "Á", $cadena);
									$cadena = str_replace("&EACUTE;", "É", $cadena);
									$cadena = str_replace("&IACUTE;", "Í", $cadena);
									$cadena = str_replace("&OACUTE;", "Ó", $cadena);
									$cadena = str_replace("&UACUTE;", "Ú", $cadena);
									$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
									$cadena = str_replace("&aacute;", "á", $cadena);
									$cadena = str_replace("&eacute;", "é", $cadena);
									$cadena = str_replace("&iacute;", "í", $cadena);
									$cadena = str_replace("&oacute;", "ó", $cadena);
									$cadena = str_replace("&uacute;", "ú", $cadena);
									$cadena = str_replace("&ntilde;", "ñ", $cadena);
									return $cadena;
								}
								session_name("loginUsuario");
								session_start();
								$numControl = $_SESSION["numcontrol"];
								
								//$mysqli = new mysqli('localhost','root','samushomysql123');
								$mysqli = conexionMysqli();
								openConectionMysql();
								mysql_query("SET NAMES 'utf8'");
								$consulta = sprintf("SELECT * FROM Estudiante WHERE NumControl = $numControl");
								$resultado = mysql_query($consulta);
								$fila = mysql_fetch_assoc($resultado);

								$carrera_replace = $fila['Carrera'];
								$carrera_replace = replace($carrera_replace);
								$reticula_replace = $fila['Reticula'];
								$reticula_replace = replace($reticula_replace);
								$opcion_titulacion_replace = $fila['OpcionDeTitulacion'];
								$opcion_titulacion = replace($opcion_titulacion);
								$proyecto_replace = $fila['Proyecto'];
								$proyecto_replace = replace($proyecto_replace);
								
								if (isset($_POST['guardar_cambios'])) {
									$cambiar_carrera = $_POST['CambiarCarrera'];
									if ($cambiar_carrera != true) {
										echo "<p class='text-black2 text-center'>Imposible guardar cambios<br>No se ha seleccionado la opción:<br>'Cambiar carrera'</p>";
										$error = true;
									}
									if ($error != true) {
										openConectionMysql();
										mysql_query("SET NAMES 'utf8'");

										if ($cambiar_carrera == true) {
											$carrera = $mysqli->real_escape_string(htmlspecialchars($_POST['Carrera']));
											$carrera = htmlentities($carrera);
											$queryUpdateCarrera = "UPDATE Estudiante SET Carrera = '$carrera' WHERE NumControl = $numControl";
											if (mysql_query($queryUpdateCarrera)) {
												echo "<p class='text-black2 text-center'>Se ha cambiado la carrera correctamente</p>";
											}
											else {
												echo "<p class='text-black2 text-center'>No se ha logrado cambiar la carrera<br>Vuelva a intentarlo</p>";
											}
										}
									}	
								}
							?>
							<hr>
							<form name="form1" action="datosEscolaresEstudiante.php" method="post" onsubmit="">
								<div class="top-margin">
									<label>Carrera</label>
									<input name="Carrera_d" value="<?php echo $carrera_replace;?>" class="form-control-carrera" disabled>
								</div>
								<div class="top-margin">
									<label>Reticula</label>
									<input name="Reticula_d" value="<?php echo $reticula_replace;?>" 
									class="form-control-reticula" disabled>
								</div>
								<div class="top-margin">
									<label>Opción de titulación</label>
									<input name="OpcionDeTitulacion_d" value="<?php echo $opcion_titulacion_replace;?>" class="form-control-opciontitulacion" disabled>
								</div>
								<div class="top-margin">
									<label>Nombre del proyecto</label>
									<textarea name="Proyecto_d" cols="55" rows="5" class="form-control-proyecto"
									disabled><?php echo $proyecto_replace;?></textarea>
								</div>
								<hr>
								<h3 class="thin text-center">Modificaciones</h3>
								<br>
								<hr>
								<p class="text-muted text-center">Si desea cambiar su carrera habilite la opción <strong>"Cambiar<br> carrera",</strong> haga la corrección necesaria y de clic <br> en el botón <strong>"Guardar cambios"</strong></p>
								<br>
								<div class="top-margin centrar-checks">
									<label>Cambiar carrera</label>
									<input type="checkbox" name="CambiarCarrera" id="CambiarCarrera" 
									value="true" class="checks" onclick="habilitar1()">
								</div>
								<br>
								<div class="top-margin">
									<label>Carrera</label>
									<select name="Carrera" class="form-control-carrera" disabled>
										<option value="INGENIERIA EN SISTEMAS COMPUTACIONALES">Ingeniería en sistemas computacionales</option>
									</select>
								</div>
								<hr>
								<div class="row top-margin">
									<div class="col-lg-4 boton-borrarprofesor">
										<button class="btn btn-danger boton-guardarcambiosestudiante" type="submit" name="guardar_cambios" onclick="validar()">GUARDAR CAMBIOS</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</article>
			<!-- /Article -->
		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">
		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
				<br>
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								ALGUNOS DERECHOS RESERVADOS &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
