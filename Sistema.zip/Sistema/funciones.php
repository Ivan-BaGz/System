
<?php
//ARCHIVO DE FUNCIONES

//CONEXION PARA mysqli
function conexionMysqli()
{
	return new mysqli('localhost','root','samushomysql123');
}


//REALIZA SOLAMENTE UNA CONEXION A LA BASE DE DATOS
function openConectionMysql() {
	
	$enlace = mysql_connect('localhost','root','samushomysql123');
	mysql_query("SET NAMES 'utf8'");
	//comprobar la conexion	
	if(!$enlace)
	{
		die('NO SE LOGRO LA CONEXION; '.mysql_error());
	}
	//echo "CONECTADO SATISFACTORIAMENTE";
	//echo "</br>";
	
	//conexion a una base de datos
	$bd_seleccionada = mysql_select_db('Titulacion', $enlace);
	//comprobar la conexion con la base de datos
	if(!$bd_seleccionada)
	{
		die('NO NO SE PUEDE USAR LA BASE DE DATOS'.mysql_error());
	}
	//echo "CONECTADO A LA BASE DE DATOS";
	//echo "</br>";	
}

//ABRE LA CONEXION A LA BASE DE DATOS Y RECIBE UNA CONSULTA

function conexionMysql($consulta){
		
			$enlace = mysql_connect('localhost','root','samushomysql123');
			mysql_query("SET NAMES 'utf8'");
			//comprobar la conexion	
			if(!$enlace)
			{
				die('NO SE LOGRO LA CONEXION; '.mysql_error());
			}
			//echo "CONECTADO SATISFACTORIAMENTE";
			//echo "</br>";
			
			//conexion a una base de datos
			$bd_seleccionada = mysql_select_db('Titulacion', $enlace);
			//comprobar la conexion con la base de datos
			if(!$bd_seleccionada)
			{
				die('NO NO SE PUEDE USAR LA BASE DE DATOS'.mysql_error());
			}
			//echo "CONECTADO A LA BASE DE DATOS";
			//echo "</br>";
			
			//ejecutar la consulta
			$resultado = mysql_query($consulta);
			//comprobar el resultado
			//Lo siguiente muestra la consulta real enviada a mysql y el error ocurrido. Util para depuracion
			if(!$resultado)
			{
				$mensaje = 'Consulta no válida: ' . mysql_error() . "\n";
				$mensaje.= 'Consulta completa: ' . $consulta;
				die($mensaje);
			}
			else 
			{
				return $resultado;
			}
			//mysql_close($enlace);
					
		}
		
		
	

