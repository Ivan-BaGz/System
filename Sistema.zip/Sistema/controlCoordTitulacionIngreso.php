<?php 
	include 'funciones.php';

	$clave_de_acceso = $_POST['ClaveDeAcceso'];

	if ($clave_de_acceso == "") {
		header("Location: coordTitulacionIngreso.php?vacio=si");
	}
	else {
		openConectionMysql();
		$sentencia = "SELECT * FROM Administrador WHERE ClaveDeAcceso = '$clave_de_acceso' and IdAdministrador = 2";

		$res = mysql_query($sentencia);
		if (mysql_num_rows($res)>0) {
			session_name("loginUsuario"); //Asigno un nombre a la sesión
			session_start(); //Inicio la sesión
			$_SESSION["autentificado"]="si"; //Defino la sesión que demuestra que el usuario está autorizado
			$_SESSION["id"] = mysql_result($res, 0, "IdAdministrador");
			$_SESSION["nombre"] = mysql_result($res, 0, "Nombre");
			$_SESSION["clave"] = mysql_result($res, 0, "ClaveDeAcceso");
			$_SESSION["sexo"] = mysql_result($res, 0, "Sexo");
			$_SESSION["ultimoAcceso"] = date("Y-n-j H:i:s"); //Defino la fecha y hora de inicio de sesión en formato aaaa-mm-dd hh:mm:ss
			header("Location: perfilCoordTitulacion.php");
		}
		else {
			header("Location: coordTitulacionIngreso.php?error=si");
		}
	}
	mysqli_free_result($res);
	mysqli_close();
?>
