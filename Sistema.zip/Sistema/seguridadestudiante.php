<?php

error_reporting( E_WARNING | E_ERROR );
	//SE CAMBIA LA CONFIGURACIÓN DEL PHP.INI POR SI EL USUARIO CIERRA EL NAVEGADOR
	//ini_set("session.use_only_cookies", "1");
	//ini_set("session.use_trans_sid", "0");

	//INICIO LA SESIÓN
	session_name("loginUsuario");
	session_start();
	//session_set_cookie_params(0,"/",$HTTP_SERVER_VARS["HTTP_HOST"],0); //Cambiamos la duración a la cookie de la sesión

	//COMPRUEBA QUE EL USUARIO ESTÁ AUTENTIFICADO
	if ($_SESSION["autentificado"] != "si") {
		//SI NO EXISTE ENVÍO A LA PÁGINA DE AUTENTIFICACIÓN
		header("Location: signin.php");
		//ADEMAS SALGO DE ESTE SCRIPT
		exit();
	}
	else {
		//SI ESTÁ AUTENTIFICADO CALCULAMOS EL TIEMPO TRANSCURRIDO
		$fecha_guardada = $_SESSION["ultimoAcceso"];
		$ahora = date("Y-n-j H:i:s");
		$tiempo_transcurrido = (strtotime($ahora)-strtotime($fecha_guardada));

		//COMPARA EL TIEMPO TRANSCURRIDO
		if ($tiempo_transcurrido >= 900) { //SI PASARON 15 MINUTOS O MAS
			session_destroy(); //SE DESTRUYE LA SESIÓN
			header("Location: signin.php?caducado=si"); //SE REDIRECCIONA AL USUARIO A LA PÁGINA DE AUTENTICACIÓN
		}
		else { // DE LO CONTRARIO ACTUALIZO LA FECHA DE SESIÓN
			$_SESSION["ultimoAcceso"] = $ahora;
		}
	}
?>
