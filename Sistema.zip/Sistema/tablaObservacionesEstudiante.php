<?php

	include "funciones.php";	
	
	error_reporting( E_WARNING | E_ERROR );
	
	echo "<link rel='stylesheet' href='/bootstrap.min.css'>";
	echo "<link rel='stylesheet' href='/font-awesome.min.css'>";
	echo "<link rel='stylesheet' href='/bootstrap-theme.css' media='screen' >";
	echo "<link rel='stylesheet' href='/main.css'>"; 
	//tabla que muestra los alumnos registrados

	//conexion a mysql
	openConectionMysql();
	
	//CONSULTA
	session_name("loginUsuario");
	session_start();
	$numControl = $_SESSION["numcontrol"];
	//$consulta = sprintf("SELECT * FROM Profesor WHERE NumTargeta = '$num_targeta'");
	//$consulta2 = mysql_query("SELECT Nombre FROM Profesor WHERE NumTargeta = '$num_targeta'");
	$verCorrecciones = mysql_query("SELECT HacerCorrecciones FROM Estudiante WHERE NumControl = '$numControl'");
	$hacer_correcciones = mysql_result($verCorrecciones,0,'HacerCorrecciones');
	$datos_corregidos = mysql_query("SELECT DatosCorregidos FROM Estudiante WHERE NumControl = '$numControl'");
	$DatosCorregidos = mysql_result($datos_corregidos,0,'DatosCorregidos');
	//$consulta = sprintf("SELECT HacerCorrecciones FROM Profesor WHERE NumTargeta = '$num_targeta'");
	
	//COMPROBAR LA CONSULTA
	if(!$verCorrecciones)
	{
		$mensaje = "CONSULTA NO VALIDA ".mysql_error(). "<br />";
		$mensaje.= "CONSULTA COMPLETA ".$consulta;
		die($mensaje);
	}
	if (!$datos_corregidos) {
		$mensaje = "CONSULTA NO VALIDA ".mysql_error(). "<br />";
		$mensaje.= "CONSULTA COMPLETA ".$consulta;
		die($mensaje);
	}
	
	//TABLA A MOSTRAR DE OBSERVACIONES
	echo "<table border width='540' height='80'>";
	echo "<tr>";
		echo "<th class='thin text-marked text-center'>"; echo "Observaciones"; echo "</th>";
	echo "</tr>";	
			echo "<tr>";
				  echo "<td class='text-black2 text-center'>"; 
				  if ($hacer_correcciones == true) {
				  	if (strcmp($DatosCorregidos, "no") == 0) {
				  		echo "Necesita corregir sus datos";
				  	}
				  	else {
				  		if (strcmp($DatosCorregidos, "si") == 0) {
				  			echo "No necesita corregir sus datos";
				  		}
				  	}
				  } 
				  else {
				  		echo "No necesita corregir sus datos";
				  }
				  echo "</td>";
			echo "</tr>";
		//}
	echo "</table>";
?>
