
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Visor | mensajes</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8" />	
		
	<link rel="stylesheet" type="text/css" href="select_dependientes.css">
	<script type="text/javascript" src="select_dependientesListaAlumnos.js"></script>
		
	</head>
	
	<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="active"><a class="btn" href="enviarMensajesProfesor.php">Redactar mensajes</a></li>
					<li class="active"><a class="btn" href="verMensajesProfesor.php">Bandeja de entrada</a></li>
					<?php
						include 'funciones.php';

						session_name('loginUsuario');
						session_start();
					
						$id = $_SESSION["id"];

						$consulta2 = "select HacerCorrecciones,DatosCorregidos from Profesor where IdProfesor = $id";
						$resultado2 = conexionMysql($consulta2);
						$hacerCorrecciones = mysql_result($resultado2, 0, 'HacerCorrecciones');
						$datosCorregidos = mysql_result($resultado2, 0, 'DatosCorregidos');

						if ($hacerCorrecciones == 1 && $datosCorregidos == "no") {
							echo "<li class='active2'><a class='btn' href=''>Corrija sus datos</a></li>";
					}
					?>
					<li class="active"><a class="btn" href="perfilprofesor.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Estudiante</a></li>
			<li class="active">Visor de mensajes</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Ver mensajes</h1>
				</header>
				
				<div class="col-md-8 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">


<?php
error_reporting( E_WARNING | E_ERROR);

function generaMensaje($idProfesor,$idMensaje) 
{
	function replace($cadena) {
		$cadena = str_replace("&AACUTE;", "Á", $cadena);
		$cadena = str_replace("&EACUTE;", "É", $cadena);
		$cadena = str_replace("&IACUTE;", "Í", $cadena);
		$cadena = str_replace("&OACUTE;", "Ó", $cadena);
		$cadena = str_replace("&UACUTE;", "Ú", $cadena);
		$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
		$cadena = str_replace("&aacute;", "á", $cadena);
		$cadena = str_replace("&eacute;", "é", $cadena);
		$cadena = str_replace("&iacute;", "í", $cadena);
		$cadena = str_replace("&oacute;", "ó", $cadena);
		$cadena = str_replace("&uacute;", "ú", $cadena);
		$cadena = str_replace("&ntilde;", "ñ", $cadena);
		return $cadena;
	}
	//mostrar mensajes										 
	$consulta="SELECT Estudiante.IdEstudiante id,Profesor.Nombre profesor,Profesor.Apellidos apellidosp,Estudiante.Nombre estudiante,Estudiante.Apellidos apellidose,mensaje,DATE_FORMAT(fechaHora,'%d/%m/%Y a las %H:%i') fechaHora, asunto FROM Profesor,MensajesProfesor,Estudiante WHERE MensajesProfesor.IdEstudiante = Estudiante.IdEstudiante and MensajesProfesor.IdProfesor = Profesor.IdProfesor and MensajesProfesor.IdProfesor = $idProfesor and MensajesProfesor.IdMensaje = $idMensaje";
	
	$consulta2 = "SELECT Profesor.Nombre profesor,Profesor.Apellidos apellidosp,Administrador.Nombre admon,mensaje,DATE_FORMAT(fechaHora,'%d/%m/%Y a las %H:%i') fechaHora, asunto FROM Profesor,MensajesProfesor,Administrador WHERE MensajesProfesor.IdAdmon = Administrador.IdAdministrador and MensajesProfesor.IdProfesor = Profesor.IdProfesor and MensajesProfesor.IdProfesor = $idProfesor and MensajesProfesor.IdMensaje = $idMensaje";
	
	$consulta3 = "SELECT Profesor.Nombre profesor,Profesor.Apellidos apellidosp,Administrador.Nombre admon,mensaje,DATE_FORMAT(fechaHora,'%d/%m/%Y a las %H:%i') fechaHora, asunto FROM Profesor,MensajesProfesor,Administrador WHERE MensajesProfesor.IdCoordTitulacion = Administrador.IdAdministrador and MensajesProfesor.IdProfesor = Profesor.IdProfesor and MensajesProfesor.IdProfesor = $idProfesor and MensajesProfesor.IdMensaje = $idMensaje";
				
	$resultado = conexionMysql($consulta);
	$resultado2 = conexionMysql($consulta2);
	$resultado3 = conexionMysql($consulta3);
	
	//reanudar la session del usuario para crear variables
	session_name("loginUsuario");
	session_start();
										
if( mysql_num_rows($resultado) > 0 ) 
	{
		$fila = mysql_fetch_assoc($resultado);
		
		$_SESSION['ID'] = $fila['id'];
		$_SESSION['tabla'] = 'Estudiante';
	
		echo "<p class='text-black3'><font size='4'>MENSAJE DE "; echo replace($fila['estudiante']) ." ".replace($fila['apellidose']); echo "</p><br>";
		echo "<p class='text-black3'>Enviado el "; echo $fila['fechaHora']; echo "</p><br>";
		echo "<B>Asunto: </B>"; echo $fila['asunto']; echo "<br>";
		echo "<B>Mensaje: </B>".$fila['mensaje']; echo "</font><br>";
		
		//el alumno ya vio el mensaje
		$actualizar = "UPDATE MensajesProfesor SET visto=true WHERE IdMensaje = $idMensaje ";
		openConectionMysql();
		mysql_query($actualizar);
	}
	if( mysql_num_rows($resultado2) > 0 ) 
	{
		$fila = mysql_fetch_assoc($resultado2);
		
		$_SESSION['ID'] = 1;
		$_SESSION['tabla'] = 'Administrador';
	
		echo "<p class='text-black3'><font size='4'>MENSAJE DE "; echo replace($fila['admon']); echo "</p><br>";
		echo "<p class='text-black3'>Enviado el "; echo $fila['fechaHora']; echo "</p><br>";
		echo "<B>Asunto: </B>"; echo $fila['asunto']; echo "<br>";
		echo "<B>Mensaje: </B>".$fila['mensaje']; echo "</font><br>";
		
		//el alumno ya vio el mensaje
		$actualizar = "UPDATE MensajesProfesor SET visto=true WHERE IdMensaje = $idMensaje ";
		
		openConectionMysql();
		mysql_query($actualizar);
	}
	if( mysql_num_rows($resultado3) > 0 ) 
	{
		$fila = mysql_fetch_assoc($resultado3);
		
		$_SESSION['ID'] = 2;
		$_SESSION['tabla'] = 'Administrador';
	
		echo "<p class='text-black3'><font size='4'>MENSAJE DE "; echo replace($fila['admon']); echo "</p><br>";
		echo "<p class='text-black3'>Enviado el "; echo $fila['fechaHora']; echo "</p><br>";
		echo "<B>Asunto: </B>"; echo $fila['asunto']; echo "<br>";
		echo "<B>Mensaje: </B>".$fila['mensaje']; echo "</font><br>";
		
		//el alumno ya vio el mensaje
		$actualizar = "UPDATE MensajesProfesor SET visto=true WHERE IdMensaje = $idMensaje ";
		
		openConectionMysql();
		mysql_query($actualizar);
	}
	
					
}				

	$idProf = $_GET['user'];
	$idMen = $_GET['message'];
	
	echo "<form action='responderMensajeProfesor.php' method='post' >";	
			
	generaMensaje($idProf,$idMen);
	
	echo "<br><input type='submit' name='responder' value='Responder' class='btn btn-danger'>";
	echo "<form>";
	
?>



</div>
					</div>
				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>