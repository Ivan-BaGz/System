<?php

	include 'funciones.php';
	
	$insercion = "update Profesor set HacerCorrecciones=true where IdProfesor = 2";

	$resultado = conexionMysql($insercion);
	
	$consulta = "select HacerCorrecciones from Profesor where IdProfesor=2";
	
	$resultado = conexionMysql($consulta);
	$ver = mysql_result($resultado, 0,'HacerCorrecciones');
	echo $ver;
	if ( mysql_result($resultado, 0,'HacerCorrecciones') == true ) {
		echo "es verdadero";
	}
	else{
		echo "nel";
	}

?>
