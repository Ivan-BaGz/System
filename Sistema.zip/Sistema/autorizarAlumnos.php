
<?php
include "funciones.php";

function replace($cadena) {
		$cadena = str_replace("&AACUTE;", "Á", $cadena);
		$cadena = str_replace("&EACUTE;", "É", $cadena);
		$cadena = str_replace("&IACUTE;", "Í", $cadena);
		$cadena = str_replace("&OACUTE;", "Ó", $cadena);
		$cadena = str_replace("&UACUTE;", "Ú", $cadena);
		$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
		$cadena = str_replace("&aacute;", "á", $cadena);
		$cadena = str_replace("&eacute;", "é", $cadena);
		$cadena = str_replace("&iacute;", "í", $cadena);
		$cadena = str_replace("&oacute;", "ó", $cadena);
		$cadena = str_replace("&uacute;", "ú", $cadena);
		$cadena = str_replace("&ntilde;", "ñ", $cadena);
		return $cadena;
	}

function tablaPresidente($sinodal) 
{
		
	$consulta = "SELECT Nombre,Apellidos,Estudiante.IdEstudiante idEstudiante FROM AsignacionDeSinodal,Estudiante WHERE AsignacionDeSinodal.Presidente = '$sinodal' AND Estudiante.IdEstudiante=AsignacionDeSinodal.IdEstudiante";
	$resultado = conexionMysql($consulta);
	
		//$bgcolorAutorizado = "'#d0e7ff' style='border-right:1px solid #cccccc;'";
		//$bgcolorNoAutorizado =	"'#FFFF99' style='border-right:1px solid #cccccc;'";
		$bgcolorAutorizado = "'#d0e7ff'";
		$bgcolorNoAutorizado =	"'#FFFF99'";
																		
		//echo "<div id='iframe'>";
		//echo "<table width='100%' border style='border:1px solid #cccccc;' align='center' cellpadding='4' cellspacing='0'>";	
	
		if( mysql_num_rows($resultado) > 0 ) 
		{
			echo "<tr><td colspan='4' bgcolor='	ffc040'><label>Alumnos asignados como Presidente.</label></td></tr>";	
					
				
			while($fila = mysql_fetch_assoc($resultado)) 
			{
				$estudiante = $fila['idEstudiante'];
				
				//obtener cuantas firmas hay de autorizacion de registro
				$TodosAutorizanReg = "select count(*) firmas from firmarAutorizaciones where IdEstudiante = $estudiante and AprobacionRegistro = true";
				$resTodosAutorizanReg = conexionMysql($TodosAutorizanReg);
				$numFirmas = mysql_result($resTodosAutorizanReg, 0, 'firmas');
				
				//obtener cuantas firmas hay de autorizacion del trabajo
				$TodosAutorizanTrab = "select count(*) firmas from firmarAutorizaciones where IdEstudiante = $estudiante and AprobacionTrabajo = true";
				$resTodosAutorizanTrab = conexionMysql($TodosAutorizanTrab);
				$numFirmasTrab = mysql_result($resTodosAutorizanTrab, 0, 'firmas');
				
				//obtener la firma del suplente
				$suplente = "select Suplente from AsignacionDeSinodal where idEstudiante = $estudiante";
				$Suplente = conexionMysql($suplente);
				$idSuplente = mysql_result($Suplente, 0, 'Suplente');
				$suplente = "select AprobacionRegistro from firmarAutorizaciones where IdEstudiante = $estudiante and IdProfesor = $idSuplente";
				$Suplente = conexionMysql($suplente);
				$firmaSuplente = mysql_result($Suplente, 0, 'AprobacionRegistro'); 
				
				//que han firmado
				$consultaAutorizaciones = "select AprobacionRegistro,AprobacionTrabajo from firmarAutorizaciones where IdProfesor='$sinodal' and IdEstudiante = '$estudiante'";
				$autorizaciones = conexionMysql($consultaAutorizaciones);
				$registro = mysql_result($autorizaciones, 0, 'AprobacionRegistro');
				$trabajo = mysql_result($autorizaciones, 0, 'AprobacionTrabajo');
				
				//consultar si ya se ha aprobado registro o trabajo de titulacion del alumno
				$consultaEstudiante = sprintf("SELECT AutorizacionDeRegistroTrabajoTitulacion as registro,ProyectoAutorizado as trabajo from Estudiante where IdEstudiante = $estudiante ");				
				$resultadoEstudiante = conexionMysql($consultaEstudiante);
				$registroAprobado = mysql_result($resultadoEstudiante,0,'registro');
				$trabajoAprobado = mysql_result($resultadoEstudiante,0,'trabajo');
				
				/*
				if( $numFirmas > 3 || ($numFirmas == 3 && $firmaSuplente == false ) || $numFirmasTrab > 3) 
					{
						$update = "UPDATE notificaciones SET notAprobReg=true";
						mysql_query($update);
					}
					*/			
				
				echo "<tr>";
					echo "<td bgcolor=";
					if( $numFirmasTrab > 3 ) 
					{
						echo $bgcolorAutorizado.">". replace($fila['Nombre'])." ".replace($fila['Apellidos'])."</td>";
					}
					else 
					{
						echo $bgcolorNoAutorizado.">".replace($fila['Nombre'])." ".replace($fila['Apellidos'])."</td>";
					}
					echo "<td bgcolor=";
						if( $registro == true ){ 
							echo $bgcolorAutorizado. ">"; 
							echo "Apruebo Registro </td>";
							}
						else {
							echo $bgcolorNoAutorizado. ">";  echo "<a href='firmarDocumento.php?user=$estudiante&firma=AprobacionRegistro&fecha=FechaHoraAprobacionRegistro'>"; echo "Firmar Aprobación del Registro"; echo "</a>"; echo "</td>";}
					echo "<td bgcolor=";
					
					if( $numFirmas == 3 && $firmaSuplente == false || $numFirmas == 4 ) 
					{										   
						//enviar notificación de la aprobación del registro
						if( $registroAprobado == false	) 
						{
							$notificar = sprintf("UPDATE notificaciones SET notAprobReg=true,notAprobTrab=false WHERE IdEstudiante=$estudiante");
							mysql_query($notificar);
						}						
						
						//poner en 1 la autorizacion del registro del alumno
						$autorizaRegistro = "UPDATE Estudiante SET AutorizacionDeRegistroTrabajoTitulacion = true where IdEstudiante = $estudiante";
						mysql_query( $autorizaRegistro );
						if( $trabajo == true ){ 
							echo $bgcolorAutorizado.">";
							echo "Apruebo Trabajo </td>";
							}
						else {
							echo $bgcolorNoAutorizado. ">"; echo "<a href='firmarDocumento.php?user=$estudiante&firma=AprobacionTrabajo&fecha=FechaHoraAprobacionTrabajo'>"; echo "Firmar Aprobación del Trabajo"; echo "</a>"; echo "</td>";}
						
					}
					else 
					{
						echo $bgcolorNoAutorizado. ">";
						echo "Autorización del registro está en proceso...</td>";
					}
					
					echo "<td bgcolor=";
					if( $numFirmasTrab > 3 ) 
					{
						//notificar aprobación del trabajo
						if( $trabajoAprobado == false	)  
						{
							$notificar = "UPDATE notificaciones SET notAprobTrab = true  WHERE IdEstudiante = $estudiante";
							mysql_query($notificar);
						}						
						
						echo $bgcolorAutorizado.">";
						echo "Se autoriza impresion </td>";
						//$autorizaTrabajo = "UPDATE Estudiante SET AutorizacionDeImpresion=true,ProyectoAutorizado = true where IdEstudiante = $estudiante";
						//mysql_query( $autorizaTrabajo );
						$autorizaTrabajo = "UPDATE Estudiante SET ProyectoAutorizado = true where IdEstudiante = $estudiante";
						mysql_query( $autorizaTrabajo );
					}
							
					else {
							echo $bgcolorNoAutorizado. ">"; echo "Autorización del trabajo está en proceso...</td>";
							}										
								
				echo "</tr>";		
			}
		}
		else 
		{
			echo "<tr><td colspan='4' bgcolor='ffc040'> <label>No hay alumnos asignados como Presidente.</label></td></tr>";	
		}
		//echo "</table>";
		//echo "</div>";
		//echo "<br>";
}


function tablaSecretario($sinodal)  
{
		
	$consulta = "SELECT Nombre,Apellidos,Estudiante.IdEstudiante idEstudiante FROM AsignacionDeSinodal,Estudiante WHERE AsignacionDeSinodal.Secretario = '$sinodal' AND Estudiante.IdEstudiante=AsignacionDeSinodal.IdEstudiante";
	$resultado = conexionMysql($consulta);
	
		//$bgcolorAutorizado = "'#d0e7ff' style='border-right:1px solid #cccccc;'";
		//$bgcolorNoAutorizado =	"'#FFFF99' style='border-right:1px solid #cccccc;'";
		$bgcolorAutorizado = "'#d0e7ff'";
		$bgcolorNoAutorizado =	"'#FFFF99'";
																		
		//echo "<div id='iframe'>";
		//echo "<table width='100%' border style='border:1px solid #cccccc;' align='center' cellpadding='4' cellspacing='0'>";	
	
		if( mysql_num_rows($resultado) > 0 ) 
		{
			echo "<tr><td colspan='4'><br> </td></tr>";
			echo "<tr><td colspan='4' bgcolor='ffc040'><label>Alumnos asignados como Secretario.</label></td></tr>";	
					
				
			while($fila = mysql_fetch_assoc($resultado)) 
			{
				$estudiante = $fila['idEstudiante'];
				
				//obtener cuantas firmas hay de autorizacion de registro
				$TodosAutorizanReg = "select count(*) firmas from firmarAutorizaciones where IdEstudiante = $estudiante and AprobacionRegistro = true";
				$resTodosAutorizanReg = conexionMysql($TodosAutorizanReg);
				$numFirmas = mysql_result($resTodosAutorizanReg, 0, 'firmas');
				
				//obtener cuantas firmas hay de autorizacion del trabajo
				$TodosAutorizanTrab = "select count(*) firmas from firmarAutorizaciones where IdEstudiante = $estudiante and AprobacionTrabajo = true";
				$resTodosAutorizanTrab = conexionMysql($TodosAutorizanTrab);
				$numFirmasTrab = mysql_result($resTodosAutorizanTrab, 0, 'firmas');
				
				//obtener la firma del suplente
				$suplente = "select Suplente from AsignacionDeSinodal where idEstudiante = $estudiante";
				$Suplente = conexionMysql($suplente);
				$idSuplente = mysql_result($Suplente, 0, 'Suplente');
				$suplente = "select AprobacionRegistro from firmarAutorizaciones where IdEstudiante = $estudiante and IdProfesor = $idSuplente";
				$Suplente = conexionMysql($suplente);
				$firmaSuplente = mysql_result($Suplente, 0, 'AprobacionRegistro'); 
				
				//que han firmado
				$consultaAutorizaciones = "select AprobacionRegistro,AprobacionTrabajo from firmarAutorizaciones where IdProfesor='$sinodal' and IdEstudiante = '$estudiante'";
				$autorizaciones = conexionMysql($consultaAutorizaciones);
				$registro = mysql_result($autorizaciones, 0, 'AprobacionRegistro');
				$trabajo = mysql_result($autorizaciones, 0, 'AprobacionTrabajo');
				
				//consultar si ya se ha aprobado registro o trabajo de titulacion del alumno
				$consultaEstudiante = sprintf("SELECT AutorizacionDeRegistroTrabajoTitulacion as registro,ProyectoAutorizado as trabajo from Estudiante where IdEstudiante = $estudiante ");				
				$resultadoEstudiante = conexionMysql($consultaEstudiante);
				$registroAprobado = mysql_result($resultadoEstudiante,0,'registro');
				$trabajoAprobado = mysql_result($resultadoEstudiante,0,'trabajo');
				
				/*
				//notificaciones
				if( $numFirmas > 3 || ($numFirmas == 3 && $firmaSuplente == false ) || $numFirmasTrab > 3) 
					{
						$update = "UPDATE notificaciones SET NotificacionVista=false";
						mysql_query($update);
					}
					*/			
				
				echo "<tr>";
					echo "<td bgcolor=";
					if( $numFirmasTrab > 3 ) 
					{
						echo $bgcolorAutorizado.">".replace($fila['Nombre'])." ".replace($fila['Apellidos'])."</td>";
					}
					else 
					{
						echo $bgcolorNoAutorizado.">".replace($fila['Nombre'])." ".replace($fila['Apellidos'])."</td>";
					}
					echo "<td bgcolor=";
						if( $registro == true ){ 
							echo $bgcolorAutorizado. ">"; 
							echo "Apruebo Registro </td>";
							}
						else {
							echo $bgcolorNoAutorizado. ">";  echo "<a href='firmarDocumento.php?user=$estudiante&firma=AprobacionRegistro&fecha=FechaHoraAprobacionRegistro'>"; echo "Firmar Aprobación del Registro"; echo "</a>"; echo "</td>";}
					echo "<td bgcolor=";
					
					if( $numFirmas == 3 && $firmaSuplente == false || $numFirmas == 4 ) 
					{
						
						//enviar notificación de la aprobación del registro
						if( $registroAprobado == false	) 
						{
							$notificar = sprintf("UPDATE notificaciones SET notAprobReg=true,notAprobTrab=false WHERE IdEstudiante=$estudiante");
							mysql_query($notificar);
						}						
						
						//poner en 1 la autorizacion del registro del alumno
						$autorizaRegistro = "UPDATE Estudiante SET AutorizacionDeRegistroTrabajoTitulacion = true where IdEstudiante = $estudiante";
						mysql_query( $autorizaRegistro );
						if( $trabajo == true ){ 
							echo $bgcolorAutorizado.">";
							echo "Apruebo Trabajo </td>";
							}
						else {
							echo $bgcolorNoAutorizado. ">"; echo "<a href='firmarDocumento.php?user=$estudiante&firma=AprobacionTrabajo&fecha=FechaHoraAprobacionTrabajo'>"; echo "Firmar Aprobación del Trabajo"; echo "</a>"; echo "</td>";}
						
					}
					else 
					{
						echo $bgcolorNoAutorizado. ">";
						echo "Autorización del registro está en proceso...</td>";
					}
					
					echo "<td bgcolor=";
					if( $numFirmasTrab > 3 ) 
					{
						//notificar aprobación del trabajo
						if( $trabajoAprobado == false	)  
						{
							$notificar = "UPDATE notificaciones SET notAprobTrab = true  WHERE IdEstudiante = $estudiante";
							mysql_query($notificar);
						}						
						
						echo $bgcolorAutorizado.">";
						echo "Se autoriza impresion </td>";
						//$autorizaTrabajo = "UPDATE Estudiante SET AutorizacionDeImpresion=true,ProyectoAutorizado = true where IdEstudiante = $estudiante";
						//mysql_query( $autorizaTrabajo );
						$autorizaTrabajo = "UPDATE Estudiante SET ProyectoAutorizado = true where IdEstudiante = $estudiante";
						mysql_query( $autorizaTrabajo );
					}
							
					else {
							echo $bgcolorNoAutorizado. ">"; echo "Autorización del trabajo está en proceso...</td>";
							}										
								
				echo "</tr>";		
			}
		}
		else 
		{
			echo "<tr><td colspan='4'><br> </td></tr>";
			echo "<tr><td colspan='4' bgcolor='ffc040'> <label>No hay alumnos asignados como Secretario.</label></td></tr>";	
		}
		//echo "</table>";
		//echo "</div>";
		//echo "<br>";
}

function tablaVocal($sinodal)  
{
		
	$consulta = "SELECT Nombre,Apellidos,Estudiante.IdEstudiante idEstudiante FROM AsignacionDeSinodal,Estudiante WHERE AsignacionDeSinodal.Vocal = '$sinodal' AND Estudiante.IdEstudiante=AsignacionDeSinodal.IdEstudiante";
	$resultado = conexionMysql($consulta);
	
		//$bgcolorAutorizado = "'#d0e7ff' style='border-right:1px solid #cccccc;'";
		//$bgcolorNoAutorizado =	"'#FFFF99' style='border-right:1px solid #cccccc;'";
		$bgcolorAutorizado = "'#d0e7ff'";
		$bgcolorNoAutorizado =	"'#FFFF99'";
																		
		//echo "<div id='iframe'>";
		//echo "<table width='100%' border style='border:1px solid #cccccc;' align='center' cellpadding='4' cellspacing='0'>";	
	
		if( mysql_num_rows($resultado) > 0 ) 
		{
			echo "<tr><td colspan='4'><br> </td></tr>";
			echo "<tr><td colspan='4' bgcolor='ffc040'><label>Alumnos asignados como Vocal.</label></td></tr>";	
					
				
			while($fila = mysql_fetch_assoc($resultado)) 
			{
				$estudiante = $fila['idEstudiante'];
				
				//obtener cuantas firmas hay de autorizacion de registro
				$TodosAutorizanReg = "select count(*) firmas from firmarAutorizaciones where IdEstudiante = $estudiante and AprobacionRegistro = true";
				$resTodosAutorizanReg = conexionMysql($TodosAutorizanReg);
				$numFirmas = mysql_result($resTodosAutorizanReg, 0, 'firmas');
				
				//obtener cuantas firmas hay de autorizacion del trabajo
				$TodosAutorizanTrab = "select count(*) firmas from firmarAutorizaciones where IdEstudiante = $estudiante and AprobacionTrabajo = true";
				$resTodosAutorizanTrab = conexionMysql($TodosAutorizanTrab);
				$numFirmasTrab = mysql_result($resTodosAutorizanTrab, 0, 'firmas');
				
				//obtener la firma del suplente
				$suplente = "select Suplente from AsignacionDeSinodal where idEstudiante = $estudiante";
				$Suplente = conexionMysql($suplente);
				$idSuplente = mysql_result($Suplente, 0, 'Suplente');
				$suplente = "select AprobacionRegistro from firmarAutorizaciones where IdEstudiante = $estudiante and IdProfesor = $idSuplente";
				$Suplente = conexionMysql($suplente);
				$firmaSuplente = mysql_result($Suplente, 0, 'AprobacionRegistro'); 
				
				//que han firmado
				$consultaAutorizaciones = "select AprobacionRegistro,AprobacionTrabajo from firmarAutorizaciones where IdProfesor='$sinodal' and IdEstudiante = '$estudiante'";
				$autorizaciones = conexionMysql($consultaAutorizaciones);
				$registro = mysql_result($autorizaciones, 0, 'AprobacionRegistro');
				$trabajo = mysql_result($autorizaciones, 0, 'AprobacionTrabajo');
				
				//consultar si ya se ha aprobado registro o trabajo de titulacion del alumno
				$consultaEstudiante = sprintf("SELECT AutorizacionDeRegistroTrabajoTitulacion as registro,ProyectoAutorizado as trabajo from Estudiante where IdEstudiante = $estudiante ");				
				$resultadoEstudiante = conexionMysql($consultaEstudiante);
				$registroAprobado = mysql_result($resultadoEstudiante,0,'registro');
				$trabajoAprobado = mysql_result($resultadoEstudiante,0,'trabajo');
				
				/*
				//notificaciones
				if( $numFirmas > 3 || ($numFirmas == 3 && $firmaSuplente == false ) || $numFirmasTrab > 3) 
					{
						$update = "UPDATE notificaciones SET NotificacionVista=false";
						mysql_query($update);
					}
					*/			
				
				echo "<tr>";
					echo "<td bgcolor=";
					if( $numFirmasTrab > 3 ) 
					{
						echo $bgcolorAutorizado.">".replace($fila['Nombre'])." ".replace($fila['Apellidos'])."</td>";
					}
					else 
					{
						echo $bgcolorNoAutorizado.">".replace($fila['Nombre'])." ".replace($fila['Apellidos'])."</td>";
					}
					echo "<td bgcolor=";
						if( $registro == true ){ 
							echo $bgcolorAutorizado. ">"; 
							echo "Apruebo Registro </td>";
							}
						else {
							echo $bgcolorNoAutorizado. ">";  echo "<a href='firmarDocumento.php?user=$estudiante&firma=AprobacionRegistro&fecha=FechaHoraAprobacionRegistro'>"; echo "Firmar Aprobación del Registro"; echo "</a>"; echo "</td>";}
					echo "<td bgcolor=";
					
					if( $numFirmas == 3 && $firmaSuplente == false || $numFirmas == 4 ) 
					{
						//enviar notificación de la aprobación del registro
						
						if( $registroAprobado == false	) 
						{
							$notificar = sprintf("UPDATE notificaciones SET notAprobReg=true,notAprobTrab=false WHERE IdEstudiante=$estudiante");
							mysql_query($notificar);
						}						
						
						//poner en 1 la autorizacion del registro del alumno
						$autorizaRegistro = "UPDATE Estudiante SET AutorizacionDeRegistroTrabajoTitulacion = true where IdEstudiante = $estudiante";
						mysql_query( $autorizaRegistro );
						if( $trabajo == true ){ 
							echo $bgcolorAutorizado.">";
							echo "Apruebo Trabajo </td>";
							}
						else {
							echo $bgcolorNoAutorizado. ">"; echo "<a href='firmarDocumento.php?user=$estudiante&firma=AprobacionTrabajo&fecha=FechaHoraAprobacionTrabajo'>"; echo "Firmar Aprobación del Trabajo"; echo "</a>"; echo "</td>";}
						
					}
					else 
					{
						echo $bgcolorNoAutorizado. ">";
						echo "Autorización del registro está en proceso...</td>";
					}
					
					echo "<td bgcolor=";
					if( $numFirmasTrab > 3 ) 
					{
						//notificar aprobación del trabajo
						if( $trabajoAprobado == false	)  
						{
							$notificar = "UPDATE notificaciones SET notAprobTrab = true  WHERE IdEstudiante = $estudiante";
							mysql_query($notificar);
						}						
						
						echo $bgcolorAutorizado.">";
						echo "Se autoriza impresion </td>";
						//$autorizaTrabajo = "UPDATE Estudiante SET AutorizacionDeImpresion=true,ProyectoAutorizado = true where IdEstudiante = $estudiante";
						//mysql_query( $autorizaTrabajo );
						$autorizaTrabajo = "UPDATE Estudiante SET ProyectoAutorizado = true where IdEstudiante = $estudiante";
						mysql_query( $autorizaTrabajo );
					}
							
					else {
							echo $bgcolorNoAutorizado. ">"; echo "Autorización del trabajo está en proceso...</td>";
							}										
								
				echo "</tr>";		
			}
		}
		else 
		{
			echo "<tr><td colspan='4'><br> </td></tr>";	
			echo "<tr><td colspan='4' bgcolor='ffc040'> <label>No hay alumnos asignados como Vocal.</label></td></tr>";	
		}
		//echo "</table>";
		//echo "</div>";
		//echo "<br>";
}

function tablaSuplente($sinodal)  
{
		
	$consulta = "SELECT Nombre,Apellidos,Estudiante.IdEstudiante idEstudiante FROM AsignacionDeSinodal,Estudiante WHERE AsignacionDeSinodal.Suplente = '$sinodal' AND Estudiante.IdEstudiante=AsignacionDeSinodal.IdEstudiante";
	$resultado = conexionMysql($consulta);
	
		//$bgcolorAutorizado = "'#d0e7ff' style='border-right:1px solid #cccccc;'";
		//$bgcolorNoAutorizado =	"'#FFFF99' style='border-right:1px solid #cccccc;'";
		$bgcolorAutorizado = "'#d0e7ff'";
		$bgcolorNoAutorizado =	"'#FFFF99'";
																		
		//echo "<div id='iframe'>";
		//echo "<table width='100%' border style='border:1px solid #cccccc;' align='center' cellpadding='4' cellspacing='0'>";	
	
		if( mysql_num_rows($resultado) > 0 ) 
		{
			echo "<tr><td colspan='4'><br> </td></tr>";
			echo "<tr><td colspan='4' bgcolor='ffc040'><label>Alumnos asignados como Suplente.</label></td></tr>";	
					
				
			while($fila = mysql_fetch_assoc($resultado)) 
			{
				$estudiante = $fila['idEstudiante'];
				
				//obtener cuantas firmas hay de autorizacion de registro
				$TodosAutorizanReg = "select count(*) firmas from firmarAutorizaciones where IdEstudiante = $estudiante and AprobacionRegistro = true";
				$resTodosAutorizanReg = conexionMysql($TodosAutorizanReg);
				$numFirmas = mysql_result($resTodosAutorizanReg, 0, 'firmas');
				
				//obtener cuantas firmas hay de autorizacion del trabajo
				$TodosAutorizanTrab = "select count(*) firmas from firmarAutorizaciones where IdEstudiante = $estudiante and AprobacionTrabajo = true";
				$resTodosAutorizanTrab = conexionMysql($TodosAutorizanTrab);
				$numFirmasTrab = mysql_result($resTodosAutorizanTrab, 0, 'firmas');
				
				//obtener la firma del suplente
				$suplente = "select Suplente from AsignacionDeSinodal where idEstudiante = $estudiante";
				$Suplente = conexionMysql($suplente);
				$idSuplente = mysql_result($Suplente, 0, 'Suplente');
				$suplente = "select AprobacionRegistro from firmarAutorizaciones where IdEstudiante = $estudiante and IdProfesor = $idSuplente";
				$Suplente = conexionMysql($suplente);
				$firmaSuplente = mysql_result($Suplente, 0, 'AprobacionRegistro'); 
				
				//que han firmado
				$consultaAutorizaciones = "select AprobacionRegistro,AprobacionTrabajo from firmarAutorizaciones where IdProfesor='$sinodal' and IdEstudiante = '$estudiante'";
				$autorizaciones = conexionMysql($consultaAutorizaciones);
				$registro = mysql_result($autorizaciones, 0, 'AprobacionRegistro');
				$trabajo = mysql_result($autorizaciones, 0, 'AprobacionTrabajo');
				
				//consultar si ya se ha aprobado registro o trabajo de titulacion del alumno
				$consultaEstudiante = sprintf("SELECT AutorizacionDeRegistroTrabajoTitulacion as registro,ProyectoAutorizado as trabajo from Estudiante where IdEstudiante = $estudiante ");				
				$resultadoEstudiante = conexionMysql($consultaEstudiante);
				$registroAprobado = mysql_result($resultadoEstudiante,0,'registro');
				$trabajoAprobado = mysql_result($resultadoEstudiante,0,'trabajo');
				
				/*
				//notificaciones
				if( $numFirmas > 3 || ($numFirmas == 3 && $firmaSuplente == false ) || $numFirmasTrab > 3) 
					{
						$update = "UPDATE notificaciones SET NotificacionVista=false";
						mysql_query($update);
					}
					*/			
				
				echo "<tr>";
					echo "<td bgcolor=";
					if( $numFirmasTrab > 3 ) 
					{
						echo $bgcolorAutorizado.">".replace($fila['Nombre'])." ".replace($fila['Apellidos'])."</td>";
					}
					else 
					{
						echo $bgcolorNoAutorizado.">".replace($fila['Nombre'])." ".replace($fila['Apellidos'])."</td>";
					}
					echo "<td bgcolor=";
						if( $registro == true ){ 
							echo $bgcolorAutorizado. ">"; 
							echo "Apruebo Registro </td>";
							}
						else {
							echo $bgcolorNoAutorizado. ">";  echo "<a href='firmarDocumento.php?user=$estudiante&firma=AprobacionRegistro&fecha=FechaHoraAprobacionRegistro'>"; echo "Firmar Aprobación del Registro"; echo "</a>"; echo "</td>";}
					echo "<td bgcolor=";
					
					if( $numFirmas == 3 && $firmaSuplente == false || $numFirmas == 4 ) 
					{
						//enviar notificación de la aprobación del registro
						if( $registroAprobado == false	) 
						{
							$notificar = sprintf("UPDATE notificaciones SET notAprobReg=true,notAprobTrab=false WHERE IdEstudiante=$estudiante");
							mysql_query($notificar);
						}						
						
						//poner en 1 la autorizacion del registro del alumno
						$autorizaRegistro = "UPDATE Estudiante SET AutorizacionDeRegistroTrabajoTitulacion = true where IdEstudiante = $estudiante";
						mysql_query( $autorizaRegistro );
						if( $trabajo == true ){ 
							echo $bgcolorAutorizado.">";
							echo "Apruebo Trabajo </td>";
							}
						else {
							echo $bgcolorNoAutorizado. ">"; echo "<a href='firmarDocumento.php?user=$estudiante&firma=AprobacionTrabajo&fecha=FechaHoraAprobacionTrabajo'>"; echo "Firmar Aprobación del Trabajo"; echo "</a>"; echo "</td>";}
						
					}
					else 
					{
						echo $bgcolorNoAutorizado. ">";
						echo "Autorización del registro está en proceso...</td>";
					}
					
					echo "<td bgcolor=";
					if( $numFirmasTrab > 3 ) 
					{
						//notificar aprobación del trabajo
						if( $trabajoAprobado == false	)  
						{
							$notificar = "UPDATE notificaciones SET notAprobTrab = true  WHERE IdEstudiante = $estudiante";
							mysql_query($notificar);
						}						
						
						echo $bgcolorAutorizado.">";
						echo "Se autoriza impresion </td>";
						//$autorizaTrabajo = "UPDATE Estudiante SET AutorizacionDeImpresion=true,ProyectoAutorizado = true where IdEstudiante = $estudiante";
						//mysql_query( $autorizaTrabajo );
						$autorizaTrabajo = "UPDATE Estudiante SET ProyectoAutorizado = true where IdEstudiante = $estudiante";
						mysql_query( $autorizaTrabajo );
					}
							
					else {
							echo $bgcolorNoAutorizado. ">"; echo "Autorización del trabajo está en proceso...</td>";
							}										
								
				echo "</tr>";		
			}
		}
		else 
		{
			echo "<tr><td colspan='4'><br> </td></tr>";
			echo "<tr><td colspan='4' bgcolor='ffc040'> <label>No hay alumnos asignados como Suplente.</label></td></tr>";	
		}
		//echo "</table>";
		//echo "</div>";
		//echo "<br>";
}

?>

<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Firmar | documentos</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8" />	
		
	<link rel="stylesheet" type="text/css" href="select_dependientes.css">
	<script type="text/javascript" src="select_dependientesListaAlumnos.js"></script>
		
	<style type="text/css">
	
	div.mensaje
    {
    	position:relative; top:-10px; left:330px;
		width: 500px;
		padding: 5px;
		border: solid 4px red;;
		color: red;	
	}
		#iframe
    	{
    		overflow:auto;
    		width:1200px;
    		height:600px;
    	}
	</style>	
		
	</head>
	
	<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li><a href="datospersonalesprofesor.php">Datos personales</a></li>
					<li class="dropdown">	
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Egresados <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="autorizarAlumnos.php">Aprobar Documentos</a></li>
						</ul>
					</li>
					<?php

					session_name('loginUsuario');
					session_start();
					
					$id = $_SESSION["id"];					
					
					$consulta = "select count(*) as MensajesNuevos from MensajesProfesor where IdProfesor = $id and visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');

					$consulta2 = "select HacerCorrecciones,DatosCorregidos from Profesor where IdProfesor = $id";
					$resultado2 = conexionMysql($consulta2);
					$hacerCorrecciones = mysql_result($resultado2, 0, 'HacerCorrecciones');
					$datosCorregidos = mysql_result($resultado2, 0, 'DatosCorregidos');

					if( $mensajes > 0 ) {
					?>
					<li class="active3"><a class="btn" href="verMensajesProfesor.php"><?php echo $mensajes ?> mensaje(s)</a></li>
					<?php
					}
					else {
						echo '<li class="active"><a class="btn" href="verMensajesProfesor.php">Mensajeria</a></li>';
					}
					if ($hacerCorrecciones == 1 && $datosCorregidos == "no") {
						echo "<li class='active2'><a class='btn' href=''>Corrija sus datos</a></li>";
					}
					?>
					<li class="active"><a class="btn" href="perfilprofesor.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Profesor</a></li>
			<li class="active">Firmar Documentos</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Firmar documentos</h1>
				</header>
				
				<!--
				<div class="col-md-8 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
				-->
		
	
	<?php		
	
		$id_sinodal = $_SESSION["id"];
		
		//Notificacion para firmar en la oficina de titulacion
		
		$consulta = sprintf("select distinct firmarAutorizaciones.IdEstudiante from Estudiante,firmarAutorizaciones where firmarAutorizaciones.IdProfesor = $id_sinodal and firmarAutorizaciones.firmaLiberacionOficina = false and Estudiante.AutorizacionDeRegistroTrabajoTitulacion = true");
			$resultado = conexionMysql($consulta);		 
				 
			if( mysql_num_rows($resultado) > 0 ) 
			{
				echo "<div class = 'mensaje'>";
				echo "<p class='text-alert'>Por favor acuda a la oficina de titulación del departamento de sistemas para firmar la liberación de:<br><br>";
				
				while( $fila = mysql_fetch_assoc($resultado) ) 
				{
					$id = $fila['IdEstudiante'];
					$consult = sprintf("select Nombre,Apellidos from Estudiante where IdEstudiante = $id");
					$result = conexionMysql($consult);
								
					echo replace(mysql_result($result,0,'Nombre')) . " " . replace(mysql_result($result,0,'Apellidos')) . "<br>";
				}
			}
			echo "</p>";
			/*
			$consulta = sprintf("SELECT Nombre,Apellidos FROM AsignacionDeSinodal,Estudiante WHERE AsignacionDeSinodal.Presidente = $id_sinodal AND Estudiante.IdEstudiante=AsignacionDeSinodal.IdEstudiante and Estudiante.AutorizacionDeRegistroTrabajoTitulacion = true");
			$resultado = conexionMysql($consulta);
			echo "<p class='text-alert'>Por favor acuda a la oficina de titulación del departamento de sistemas para firmar la liberación de:<br><br>";
			
			if( mysql_num_rows($resultado) > 0 ) 
			{
				while( $fila = mysql_fetch_assoc($resultado) ) 
				{
					echo replace($fila['Nombre']) . " " . replace($fila['Apellidos']) . "(Presidente)<br>";
				}
			}
			$consulta = sprintf("SELECT Nombre,Apellidos FROM AsignacionDeSinodal,Estudiante WHERE AsignacionDeSinodal.Secretario = $id_sinodal AND Estudiante.IdEstudiante=AsignacionDeSinodal.IdEstudiante and Estudiante.AutorizacionDeRegistroTrabajoTitulacion = true");
			$resultado = conexionMysql($consulta);
					
			if( mysql_num_rows($resultado) > 0 ) 
			{
				while( $fila = mysql_fetch_assoc($resultado) ) 
				{
					echo replace($fila['Nombre']) . " " . replace($fila['Apellidos']) . "(Presidente)<br>";
				}
			}
			
			$consulta = sprintf("SELECT Nombre,Apellidos FROM AsignacionDeSinodal,Estudiante WHERE AsignacionDeSinodal.Vocal = $id_sinodal AND Estudiante.IdEstudiante=AsignacionDeSinodal.IdEstudiante and Estudiante.AutorizacionDeRegistroTrabajoTitulacion = true");
			$resultado = conexionMysql($consulta);
					
			if( mysql_num_rows($resultado) > 0 ) 
			{
				while( $fila = mysql_fetch_assoc($resultado) ) 
				{
					echo replace($fila['Nombre']) . " " . replace($fila['Apellidos']) . "(Presidente)<br>";
				}
			}
			
			$consulta = sprintf("SELECT Nombre,Apellidos FROM AsignacionDeSinodal,Estudiante WHERE AsignacionDeSinodal.Suplente = $id_sinodal AND Estudiante.IdEstudiante=AsignacionDeSinodal.IdEstudiante and Estudiante.AutorizacionDeRegistroTrabajoTitulacion = true");
			$resultado = conexionMysql($consulta);
					
			if( mysql_num_rows($resultado) > 0 ) 
			{
				while( $fila = mysql_fetch_assoc($resultado) ) 
				{
					echo replace($fila['Nombre']) . " " . replace($fila['Apellidos']) . "(Presidente)<br>";
				}
			}
			echo "</p>";
			*/
			echo "</div>";
		
		echo "<div id='iframe'>";
		echo "<table width='100%' border style='border:1px solid #cccccc;' align='center' cellpadding='4' cellspacing='0'>";
		tablaPresidente( $id_sinodal );
		tablaSecretario( $id_sinodal );	
		tablaVocal($id_sinodal);
		tablaSuplente( $id_sinodal );
		echo "</div>";
		echo "</table>";
		
	
	?>
<!--
	</div>
					</div>
				</div>
-->
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
