<?php include 'seguridadadmin.php'; ?>
<?php include 'funciones.php'; ?>

<?php

	function notificarAprobaciones()
{
//obtener cuantas alumnos se les han autorizado el registro

$consulta = sprintf("select Nombre,Apellidos,notAprobReg,notAprobTrab from notificaciones,Estudiante where notificaciones.IdEstudiante = Estudiante.IdEstudiante and notificaciones.notAprobReg = true");
$resultado = conexionMysql($consulta);
$aprobReg = mysql_num_rows($resultado);

$consulta = sprintf("select Nombre,Apellidos,notAprobReg,notAprobTrab from notificaciones,Estudiante where notificaciones.IdEstudiante = Estudiante.IdEstudiante and notificaciones.notAprobTrab = true");
$resultado = conexionMysql($consulta);
$aprobTrab = mysql_num_rows($resultado);


$arrayAprob = array($aprobReg,$aprobTrab);
return $arrayAprob;
}

?>

<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Perfil | adminApoyo</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
	
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="#"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Egresados <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="estudiantesregistrados.php">Egresados registrados</a></li>
							<li><a href="asignarSinodal.php">Asignar Revisores</a></li>
							<li><a href="listaAlumnos.php">Crear Documentos</a></li>
							<li><a href="cambioJurado.php">Cambio de jurado</a></li>
							<li><a href="cambioTema.php">Cambio de tema de tesis</a></li>
							<li><a href="bitacora2.php">Bitácora</a></li>
							</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Profesores <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="consultarFirmas.php">Firmas Registradas</a></li>							
							<li><a href="profesoresregistrados.php">Profesores registrados</a></li>
							<li><a href="firmasOficina.php">Firmas de liberacion</a></li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrador<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="modificacionesAdministrador.php">Modificaciones</a></li>
							<li><a href="actualizarPlantillas.php">Actualizar plantillas</a></li>
							<li><a href="archivosSubidos.php">Ver plantillas actualizadas</a></li>
							<li><a href="descomprimeZip.php">Descomprimir archivos ZIP</a></li>
						</ul>
					</li>
					
					<?php
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAdministrador where visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					?>
					<li class="active3"><a class="btn" href="verMensajesAdmon.php"><?php echo $mensajes ?> Mensaje(s)</a></li>
					<?php
					}
					else
						echo '<li class="active"><a class="btn" href="verMensajesAdmon.php">Mensajeria</a></li>';
						
						//notificar aprobaciones
						$arrayAprob = notificarAprobaciones();
						if( ($arrayAprob[0] > 0 || $arrayAprob[1] > 0) )
						{
							echo '<li class="active2"><a class="btn" href="consultarFirmas.php">HAY APROBACIONES</a></li>';
						}
						
						//NOTIFICAR ALUMNOS REGISTRADOS EN EL SISTEMA
						$consulta = sprintf("select count(*) as reg from notificaciones where notRegSistema = true" );
						$resultado = conexionMysql($consulta);
						$registros = mysql_result($resultado,0,'reg');
						if( $registros > 0 ) 
						{
							echo '<li class="active2"><a class="btn" href="estudiantesregistrados.php">EGRESADOS REGISTRADOS</a></li>';
						}
						
					?>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
					
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">
						<?php
						function replace($cadena) {
							$cadena = str_replace("&AACUTE;", "Á", $cadena);
							$cadena = str_replace("&EACUTE;", "É", $cadena);
							$cadena = str_replace("&IACUTE;", "Í", $cadena);
							$cadena = str_replace("&OACUTE;", "Ó", $cadena);
							$cadena = str_replace("&UACUTE;", "Ú", $cadena);
							$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
							$cadena = str_replace("&aacute;", "á", $cadena);
							$cadena = str_replace("&eacute;", "é", $cadena);
							$cadena = str_replace("&iacute;", "í", $cadena);
							$cadena = str_replace("&oacute;", "ó", $cadena);
							$cadena = str_replace("&uacute;", "ú", $cadena);
							$cadena = str_replace("&ntilde;", "ñ", $cadena);
							return $cadena;
						} 
						session_name("loginUsuario");
						session_start();
						$nombre = $_SESSION["nombre"];
						$nombre = replace($nombre);
						$sexo = $_SESSION["sexo"];
						if (strcmp($sexo, "masculino") == 0) {
							$sexo = "PROFESOR ";
							$saludo = ", BIENVENIDO!";
						}
						else {
							$sexo = "PROFESORA ";
							$saludo = ", BIENVENIDA!";
						}
						echo "HOLA ",$sexo,$nombre,$saludo;
					?>
					</h1>
				</header>
				
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Bienvenido</h3>
							<hr>
							<p class="text-center text-black2">Selecciona una de las diferentes opciones de la parte superior</p>
						</div>
					</div>
				</div>
			</article>
			<!-- /Article -->
		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">
		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
				<br>
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								ALGUNOS DERECHOS RESERVADOS &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
</body>
</html>

