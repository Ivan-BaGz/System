<?php include 'seguridadadmin.php'; ?>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Profesores | registrados</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
	<script type="text/javascript">
		function soloNumeros(e) {
			var entrada = window.event ? window.event.keyCode : e.which;
			if (entrada == 8 || entrada == 9) 
				return true;

			return /\d/.test(String.fromCharCode(entrada));
		}
		function validar(form1) {
			if (document.form1.NumTargeta.value == "") {
				alert("Introduce un número de tarjeta");
				return false;
			}
		}
		function limpiar() {
			document.getElementById("form1").reset();
		}
	</script>
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="#"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Estudiantes <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="estudiantesregistrados.php">Estudiantes registrados</a></li>
							<li><a href="asignarSinodal.php">Asignar Revisores</a></li>
							<li><a href="listaAlumnos.php">Crear Documentos</a></li>
							<li><a href="cambioJurado.php">Cambio de jurado</a></li>
							<li><a href="cambioTema.php">Cambio de tema de tesis</a></li>
							<li><a href="bitacora2.php">Bitácora</a></li>
							</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Profesores <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="consultarFirmas.php">Firmas Registradas</a></li>							
							<li><a href="profesoresregistrados.php">Profesores registrados</a></li>
							<li><a href="firmasOficina.php">Firmas de liberacion</a></li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrador<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="modificacionesAdministrador.php">Modificaciones</a></li>
							<li><a href="actualizarPlantillas.php">Actualizar plantillas</a></li>
							<li><a href="archivosSubidos.php">Ver plantillas actualizadas</a></li>
							<li><a href="descomprimeZip.php">Descomprimir archivos ZIP</a></li>
						</ul>
					</li>
					
					<?php
					include "funciones.php";
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAdministrador where visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					?>
					<li class="active3"><a class="btn" href="verMensajesAdmon.php"><?php echo $mensajes ?> Mensaje(s)</a></li>
					<?php
					}
					else
						echo '<li class="active"><a class="btn" href="verMensajesAdmon.php">Mensajeria</a></li>';
					?>
				
					<li class="active"><a class="btn" href="perfiladministrador.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Profesores registrados</h1>
				</header>
				
				<?php
					echo "<IFRAME NAME='info_profesores' SRC='tablaProfesoresRegistrados.php' WIDTH='740' HEIGHT='200' FRAMEBORDER='1' MARGINWIDTH='3' MARGINHEIGHT='3' SCROLLING='Auto' class='centrar-tabla text-alert'></IFRAME>";
				?>
				<br><br>
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Información del profesor</h3>
							<?php
								function replace($cadena) {
									$cadena = str_replace("&AACUTE;", "Á", $cadena);
									$cadena = str_replace("&EACUTE;", "É", $cadena);
									$cadena = str_replace("&IACUTE;", "Í", $cadena);
									$cadena = str_replace("&OACUTE;", "Ó", $cadena);
									$cadena = str_replace("&UACUTE;", "Ú", $cadena);
									$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
									$cadena = str_replace("&aacute;", "á", $cadena);
									$cadena = str_replace("&eacute;", "é", $cadena);
									$cadena = str_replace("&iacute;", "í", $cadena);
									$cadena = str_replace("&oacute;", "ó", $cadena);
									$cadena = str_replace("&uacute;", "ú", $cadena);
									$cadena = str_replace("&ntilde;", "ñ", $cadena);
									return $cadena;
								}
								if (isset($_POST['ver_info_profesor'])) {
									if (empty($_POST['CedulaB'])) {
										echo "<p class='text-center text-black2'>Introduce un número de tarjeta</p>";
										$error = true;
									}
									else {
										$cedula = $_POST['CedulaB'];
									}
									if ($error != true) {
										openConectionMysql();
										mysql_query("SET NAMES 'utf8'");
										$nueva_cedula = mysql_query("SELECT Cedula FROM Profesor WHERE Cedula = $cedula");
										if (mysql_num_rows($nueva_cedula) > 0) {
											$consulta = sprintf("SELECT * FROM Profesor WHERE Cedula = $cedula");
											$resultado = mysql_query($consulta);
											$fila = mysql_fetch_assoc($resultado);

											$nombre_replace = replace($fila['Nombre']);
											$apellidos_replace = replace($fila['Apellidos']);
											$cedula_replace = replace($fila['Cedula']);
											$grado_academico_replace = replace($fila['NivelAcademico']);
											$siglas_grado_academico_replace = replace($fila['SiglasNivelAcademico']);
											$correo_electronico_replace = replace($fila['CorreoElectronico']);
											$departamento_replace = replace($fila['Departamento']);
										}
										else {
											echo "<p class='text-black2 text-center'>No se encuentra registrado ese número de cédula</p>";
										}
									}
								}
								if (isset($_POST['guardar_cambios'])) {
									if (empty($_POST['NumTarjeta'])) {
										echo "<p class='text-center text-black2'>Imposible guardar cambios<br>No se ha buscado ningún profesor</p>";
										$error = true;
									}
									else {
										$num_targeta_seleccionado = $_POST['NumTarjeta'];
									}
									if ($error != true) {
										$correcciones = $_POST['HacerCorrecciones'];
										$datoscorregidos = "no";
										openConectionMysql();
										$queryupdate = "UPDATE Profesor SET HacerCorrecciones = $correcciones WHERE NumTargeta = '$num_targeta_seleccionado'";
										$queryupdate2 = "UPDATE Profesor SET DatosCorregidos = '$datoscorregidos' WHERE NumTargeta = '$num_targeta_seleccionado'";
										if (mysql_query($queryupdate)) {
											if (mysql_query($queryupdate2)) {
												echo "<p class='text-black2 text-center'>Cambios guardados con éxito</p>";
											}
											else {
												echo "<p class='text-black2 text-center'>Error al guardar<br>Vuelva a intentarlo</p>";
											}
										}
										else {
											echo "<p class='text-black2 text-center'>Error al guardar<br>Vuelva a intentarlo</p>";
										}
									}
								}
								
							?>
							<hr>
							<form name="form1" action="profesoresregistrados.php" method="post" onsubmit="return validar()">
								<div class="row top-margin">
									<div class="col-sm-6">
										<label>Cedula <span class="text-danger">*</span></label>
										<input type="text" name="CedulaB" maxlength="7" onkeypress="return soloNumeros(event);" value="<?php echo $fila['Cedula'];?>" class="form-control-cedula-busquedaProfesor">
									</div>
									<div class="row">
										<div class="col-lg-4 text-right">
											<button class="btn btn-danger boton-buscarprofesor" type="submit" name="ver_info_profesor">Ver información</button>
										</div>
									</div>
									<div class="row">
										<div class="col-lg-4 text-right">
											<button class="btn btn-default boton-limpiar" type="submit" name="limpiar" onclick="limpiar()">Limpiar</button>
										</div>
									</div>
								</div>
								<br>
								<p class="text-muted text-center">
									Introduzca un número de cédula y de clic en el botón<br>
									para mostrar la información del profesor
								</p>
								<hr>
								<div class="top-margin">
									<label>Número de targeta</label>
									<input type="text" name="NumTarjeta" value="<?php echo $fila['NumTargeta']; ?>" class="form-control-numtargeta" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Nombre</label>
									<input type="text" name="Nombre" value="<?php echo $nombre_replace; ?>" class="form-control-nombreestudiante" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Apellidos</label>
									<input type="text" name="Apellidos" value="<?php echo $apellidos_replace;?>" class="form-control-apellidos" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Cedula</label>
									<input type="text" name="Cedula" value="<?php echo $cedula_replace;?>" class="form-control-cedula" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Grado académico</label>
									<input type="text" name="GradoAcademico" value="<?php echo $grado_academico_replace;?>" class="form-control-direccion" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Abreviación del grado académico</label>
									<input type="text" name="SiglasGradoAcademico" value="<?php echo $siglas_grado_academico_replace;?>" class="form-control-abreviaciongradoacademico" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Correo electrónico</label>
									<input type="text" name="CorreoElectronico" value="<?php echo $correo_electronico_replace;?>" class="form-control-correo" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Departamento</label>
									<input type="text" name="Departamento" id="reticula" value="<?php echo $departamento_replace;?>" class="form-control-departamentoprofesor" readonly="readonly">
								</div>
								<div class="row top-margin">
									<div class="col-sm-6">
										<label>Fecha de registro</label>
										<input type="text" name="FechaYHoraDeRegistro" id="fechayhoraderegistro" value="<?php echo $fila['FechaYHoraDeRegistro'];?>" class="form-control-tipodatetime" readonly="readonly">
									</div>
									<div class="col-sm-6">
										<label>Último acceso</label>
										<input type="text" name="UltimoAcceso" id="ultimoacceso" value="<?php echo $fila['UltimoAcceso'];?>" class="form-control-tipodatetime" readonly="readonly">
									</div>
								</div>
								<hr>
								<br>
								<p class="text-muted text-center">Si desea que el profesor haga correcciones<br>seleccione la opción <strong>"Hacer correcciones</strong>"</p>
								
								<div class="top-margin centrar-checks4">
									<label>Hacer correcciones</label>
									<input type="checkbox" name="HacerCorrecciones" id="HacerCorrecciones" value="true" class="checks" onclick="document.form1.guardar_cambios.disabled=!document.form1.guardar_cambios.disabled">
								</div>
								<hr>
								<br>
								<div class="row top-margin">
									<div class="col-lg-4 boton-guardarcambiosprofe">
										<button class="btn btn-danger boton-guardarcambios-profesregistrados" type="submit" name="guardar_cambios" disabled>Guardar cambios</button>
									</div>
									
								</div>
							</form>
						</div>
					</div>
				</div>
			</article>
			<!-- /Article -->
		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">
		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
				<br>
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								ALGUNOS DERECHOS RESERVADOS &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
