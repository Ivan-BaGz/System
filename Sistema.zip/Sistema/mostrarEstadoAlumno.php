
<?php

error_reporting( E_ERROR | E_WARNING );
include 'funciones.php';
	function generaAlumnos() {
			
		//lista muestra los alumnos registrados	
		//echo "<label>SELECCIONA UN ALUMNO PARA CREAR DOCUMENTO<label>";	
		echo "<select onchange='mostrarInfo(this.value)' class='form-control' style='width:350;'>";
		echo "<option value='0'>Selecciona un alumno</option>";
		//Formular la consulta
		$consulta = sprintf("SELECT Nombre,Apellidos,IdEstudiante FROM Estudiante");
		$resultado = conexionMysql($consulta);			
		while($fila = mysql_fetch_assoc($resultado))
		{
			
			$id= $fila['IdEstudiante'];
			echo "<option value=$id ";
				if( $_POST["alumnos"] == $id )
				{ 
				echo "selected='selected'"; 
				}
				echo ">";
			echo $fila['Nombre'] . " " . $fila['Apellidos'];
			echo "</option>";
		}
		echo "</select>";
}

?>


<html>
<head>

<script>

function mostrarInfo(){

if (window.XMLHttpRequest)
{// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else
{// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}

xmlhttp.open("POST","proceso.php");

xmlhttp.onreadystatechange=function()
{
if (xmlhttp.readyState==4 && xmlhttp.status==200)
{
document.getElementById("datos").innerHTML=xmlhttp.responseText;
}else{
document.getElementById("datos").innerHTML='Cargando...';
}
}
//xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
xmlhttp.send(null);

}

</script>

</head>
<body>

<form>
<?php
generaAlumnos();
?>

</form>

<div id="datos"></div>

</body>
</html> 