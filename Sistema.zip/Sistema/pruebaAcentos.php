<?php
	echo "<meta charset='utf-8'>";
	include 'funciones.php';
	$mysqli = new mysqli('localhost','root','samushomysql123');

	# str_replace ("cadena a buscar", "cadena de reemplazo", $variableOFraseOriginal)
	# IVÁN ENCONTRÉ UNA OPCIÓN
	$cadena1 = "IV&AACUTE;N ENCONTR&EACUTE; UNA OPCI&OACUTE;N";
	function replace($cadena) {
		$cadena = str_replace("&AACUTE;", "Á", $cadena);
		$cadena = str_replace("&EACUTE;", "É", $cadena);
		$cadena = str_replace("&IACUTE;", "Í", $cadena);
		$cadena = str_replace("&OACUTE;", "Ó", $cadena);
		$cadena = str_replace("&UACUTE;", "Ú", $cadena);
		return $cadena;
	}
	$cadena_salida = replace($cadena1);
	echo $cadena_salida;

	/*
	if (ctype_upper($cadena) != true) {
			$cadena = strtr(strtoupper($cadena),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
		}
	echo $cadena;
	$cadena = $mysqli->real_escape_string(htmlspecialchars($cadena));
	$cadena = htmlentities($cadena);
	echo $cadena;
	# str_replace ("cadena a buscar", "cadena de reemplazo", $variableOFraseOriginal)
	*/
	$cadena2 = "Á É Í";
	$cadena2 = $mysqli->real_escape_string(htmlspecialchars($cadena2));
	$cadena2 = htmlentities($cadena2);
	openConectionMysql();
	mysql_query("SET NAMES 'utf8'");
	$query = "INSERT INTO Estudiante(Apellidos)values('$cadena2')";
	if (mysql_query($query)) {
		echo "éxito";
	}
	else {
		echo "falló";
	}
	
?>