<?php
	include 'funciones.php';
	//$mysqli = new mysqli('localhost','root','samushomysql123');
	$mysqli = conexionMysqli();
	
	$num_control = $mysqli->real_escape_string(htmlspecialchars($_POST['NumControl']));
	$num_control = htmlentities($num_control);
	$clave_de_acceso = $mysqli->real_escape_string(htmlspecialchars($_POST['ClaveDeAcceso']));
	$clave_de_acceso = htmlentities($clave_de_acceso);

	if ($num_control == "" || $clave_de_acceso == "") {
		header("Location: signin.php?vacio=si");
	}
	else {
		
		openConectionMysql();
		$sentencia = "SELECT * FROM Estudiante WHERE NumControl = '$num_control' AND ClaveDeAcceso = '$clave_de_acceso'";

		$res = mysql_query($sentencia);
		if (mysql_num_rows($res)>0) {
			session_name("loginUsuario"); //Asigno un nombre a la sesión
			session_start(); //Inicio la sesión
			//session_set_cookie_params(0,"/",$HTTP_SERVER_VARS["HTTP_HOST"],0); //Cambiamos la duración a la cookie de la sesión
			$_SESSION["autentificado"]="si"; //Defino la sesión que demuestra que el usuario está autorizado
			$_SESSION["numcontrol"] = $num_control;
			$_SESSION["nombre"] = mysql_result($res,0,'Nombre');
			$_SESSION["sexo"] = mysql_result($res,0,'Sexo');
			$_SESSION["id"] = mysql_result($res, 0, "IdEstudiante");
			$_SESSION["clave"] = mysql_result($res,0,'ClaveDeAcceso');		
			$_SESSION["ultimoAcceso"] = date("Y-n-j H:i:s"); //Defino la fecha y hora de inicio de sesión en formato aaaa-mm-dd hh:mm:ss
			$ultimo_acceso = $_SESSION["ultimoAcceso"];
			mysql_query("UPDATE Estudiante SET UltimoAcceso = '$ultimo_acceso' WHERE NumControl = '$num_control'");
			header("Location: perfilestudiante.php");
		}
		else {
			header("Location: signin.php?errorusuario=si");
		}
	}
	mysqli_free_result($res);
	mysqli_close();
?>
