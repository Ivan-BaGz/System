<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Ingreso | profesor</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
	<script src="md5.js"></script>

	<script type="text/javascript">
		function soloNumeros(e) {
			var entrada = window.event ? window.event.keyCode : e.which;
			if (entrada == 8 || entrada == 9) 
				return true;

				return /\d/.test(String.fromCharCode(entrada));
		}
		function validar(form1) {
			if (document.form1.NumTargeta.value=="" && document.form1.ClaveDeAcceso.value!="") {
				alert("Introduzca su número de targeta");
				return false;
			}
			else if (document.form1.NumTargeta.value!="" && document.form1.ClaveDeAcceso.value=="") {
					alert("Introduzca su contraseña");
					return false;
				}
				else if (document.form1.NumTargeta.value=="" && document.form1.ClaveDeAcceso.value=="") {
						alert("Tiene campos vacíos");
						return false;
					}
					else {
						var md5 = hex_md5(document.form1.ClaveDeAcceso.value);
						document.form1.ClaveDeAcceso.value = md5;			
					}
		}
	</script>
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="#"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="active"><a class="btn" href="ingresoCedula.php">Regresar</a></li>
					<li class="active"><a class="btn" href="index.html">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>
	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="index.html">Inicio</a></li>
			<li class="active">Acceso-profesor</li>
		</ol>
		<div class="row">
			
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Acceso profesor</h1>
				</header>
				
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Ingrese sus datos para acceder al sistema</h3>
							<br>
							<?php
							error_reporting( E_WARNING | E_ERROR );
								
								if ($_GET["datosActualizados"] == "si") {
									echo "<p class='text-center text-black2'>Datos actualizados correctamente</p>";	
								}
								if ($_GET["vacio"] == "si") {
									echo "<p class='text-center text-black2'>Tiene campos vacíos</p>";	
								}
								if ($_GET["errorusuario"] == "si") {
									echo "<p class='text-center text-black2'>Datos erroneos</p>";
								}
								if ($_GET["caducado"] == "si") {
									echo "<p class='text-center text-black2'>Tu seción ha caducado</p>";
								}
							?>
							<hr>
							<form name="form1" action="controlprofesor.php" method="post" onsubmit="return validar()">
								<div class="row top-margin">
									<div class="col-sm-6">
										<label class="centrar-numcontrol-ingresoestudiante">Número de tarjeta <span class="text-danger">*</span></label>
										<input type="text" name="NumTargeta" maxlength="3" 
										onkeypress="return soloNumeros(event);" class="form-control-numtargeta-ingresoprofesor">
									</div>
									<div class="col-sm-6">
										<label class="centrar-claveacceso-ingresoestudiante">Contraseña <span class="text-danger">*</span></label>
										<input type="password" name="ClaveDeAcceso" class="form-control-claveacceso centrar-claveacceso-ingresoestudiante">
									</div>
								</div>
								<hr>
								<div class="row"> <!--
									<div class="col-lg-8">
										<b><a href="">Forgot password?</a></b>
									</div> -->
									<div class="col-lg-4 text-right">
										<button class="btn btn-danger centrar-boton-ingresoestudiante" type="submit" name="ingresar">Ingresar</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</article>
			<!-- /Article -->
		</div>
	</div>	<!-- /container -->
	
	<footer id="footer" class="top-space">
		<div class="footer1">
			<div class="container">
				<div class="row">
					
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					
					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="simplenav">
							</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								ALGUNOS DERECHOS RESERVADOS &copy; 2015	
							</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
