
<?php
	
	include "funciones.php";	
	
	$id = $_POST['id'];
	
	$consulta = "SELECT Proyecto FROM Estudiante WHERE IdEstudiante = $id";
	$resultado = conexionMysql($consulta);
	
	if( mysql_num_rows($resultado) > 0 ) 
	{
		$proyecto = mysql_result($resultado,0,'Proyecto');
		
		echo "<label>ACTUALMENTE EL NOMBRE DEL TEMA ES:</label><br>";
		echo '<input type="text" value="'.$proyecto.'" readonly="readonly" style="width:400;" class="form-control"/><br>';
				
		echo "<label>ESCRIBE EL NOMBRE DEL NUEVO TEMA:</label><br>";
		echo '<input type="text" name="temaNuevo" id="temaNuevo" style="width:400;" class="form-control" /><br>';
		echo "<input type='submit' name='cambiarTema' value='CAMBIAR TEMA' class='btn btn-danger' />";
		
	}	
	
?>
