<?php
	include 'funciones.php';
	error_reporting( E_WARNING | E_ERROR );
	$mysqli = conexionMysqli();

	$cedula = $_POST['Cedula'];

	if (isset($_POST['continuar'])) {
		if (empty($_POST['NumTargeta'])) {
			$error = true;
			header("Location: registroNumTargeta.php?vacio=si");
		}
		else {
			$num_targeta = $_POST['NumTargeta'];
		}
		if (empty($_POST['FirmaD'])) {
			$error = true;
			header("Location: registroNumTargeta.php?vacio=si");
		}
		else {
			$firma_digital = $_POST['FirmaD'];
		}
		if (empty($_POST['CorreoElectronico'])) {
			$error = true;
			header("Location: registroNumTargeta.php?vacio=si");
		}
		else {
			$correo_electronico = $mysqli->real_escape_string(htmlspecialchars($_POST['CorreoElectronico']));
			$correo_electronico = htmlentities($correo_electronico);
		}
		if (empty($_POST['ClaveDeAcceso'])) {
			$error = true;
			header("Location: registroNumTargeta.php?vacio=si");
		}
		else {
			$clave_de_acceso = $_POST['ClaveDeAcceso'];
		}
		if (empty($_POST['ConfClaveDeAcceso'])) {
			$error = true;
			header("Location: registroNumTargeta.php?vacio=si");
		}
		else {
			$conf_clave_de_acceso = $_POST['ConfClaveDeAcceso'];
		}
		/******** VALIDAR CONTRASEÑA ********/
		if (preg_match("/[ ]/", $clave_de_acceso)) {
			$error = true;
			header("Location: registroNumTargeta.php?claveconespacio=si");
		}
		else {
			/******** COMPROBAR SI LA CONTRASEÑA ES CORTA ********/
			if (strlen($clave_de_acceso)<8) {
				$error = true;
				header("Location: registroNumTargeta.php?clavecorta=si");
			}
			else {
				/******** COMPROBAR QUE LA CONTRASEÑA TENGA LOS CARACTERES PERMITIDOS ********/
									
				/******** COMPROBAR QUE AL MENOS TENGA UN NÚMERO ********/
				if (!preg_match("/[0-9]/", $clave_de_acceso)) {
					$error = true;
					header("Location: registroNumTargeta.php?clavesinnum=si");
				}
									
				/****** COMPROBAR QUE AL MENOS TENGA UN CARACTER ESPECIAL ******/
				if (!preg_match("/[@#%-_&*?¿]/", $clave_de_acceso)) {
					$error = true;
					header("Location: registroNumTargeta.php?clavesinespecial=si");
				}								
				/****** COMPROBAR QUE LA CONTRASEÑA COINCIDA ******/
				if (strcmp($clave_de_acceso, $conf_clave_de_acceso)!=0) {
					$error = true;
					header("Location: registroNumTargeta.php?clavesdiferentes=si");
				}
				if ($error != true) { // SI NO EXISTEN ERRORES
					/**************  SE GUARDAN LOS DATOS  *************/
		
					openConectionMysql();	// SE ABRE LA CONEXION A LA BASE DE DATOS CON ESTA FUNCION
					mysql_query("SET NAMES 'utf8'");									
					
					$nuevo_numtargeta = mysql_query("SELECT NumTargeta FROM Profesor WHERE NumTargeta ='$num_targeta'");	//QUERY PARA OBTENER LOS REGISTROS EXISTENTES
					if(mysql_num_rows($nuevo_numtargeta)>0) { // SI YA EXISTE EL NÚMERO DE TARGETA
						header("Location: registroNumTargeta.php?numtargetaexistente=si");
					}
					else { // SI NO EXISTE EL NÚMERO DE TARGETA
						$fecha_hora_registro = date("Y-n-j H:i:s");	
						$queryUpdate = "UPDATE Profesor SET NumTargeta = '$num_targeta', 
						CorreoElectronico = '$correo_electronico', FirmaD = '$firma_digital', 
						ClaveDeAcceso = '$clave_de_acceso', FechaYHoraDeRegistro = '$fecha_hora_registro' 
						WHERE Cedula = '$cedula'";	
						if(mysql_query($queryUpdate)) { //SI SE LOGRÓ LA CONSULTA
							header("Location: ingresoprofesor.php?datosActualizados=si");
						}
						else { //SI NO SE LOGRÓ LA CONSULTA
							header("Location: registroNumTargeta.php?registrofallido=si");
						}	
					}							
				}	
			}
		}
	}
?>