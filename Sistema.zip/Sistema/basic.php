<?php

include 'funciones.php';

function replace($cadena) {
	$cadena = str_replace("&AACUTE;", "Á", $cadena);
	$cadena = str_replace("&EACUTE;", "É", $cadena);
	$cadena = str_replace("&IACUTE;", "Í", $cadena);
	$cadena = str_replace("&OACUTE;", "Ó", $cadena);
	$cadena = str_replace("&UACUTE;", "Ú", $cadena);
	$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
	$cadena = str_replace("&aacute;", "á", $cadena);
	$cadena = str_replace("&eacute;", "é", $cadena);
	$cadena = str_replace("&iacute;", "í", $cadena);
	$cadena = str_replace("&oacute;", "ó", $cadena);
	$cadena = str_replace("&uacute;", "ú", $cadena);
	$cadena = str_replace("&ntilde;", "ñ", $cadena);
	return $cadena;
}
//header('Content-type: application/vnd.ms-word');
 
//header('Content-Disposition: inline; filename=helloWorld.docx');

//obtiene datos de los alumnos

$ids = $_GET['ids'];
$mes = $_GET['mes'];

$consulta = sprintf("select IdEstudiante,Nombre,Apellidos,NumControl,Reticula,CorreoElectronico,ProyectoAutorizado,FechaDeRegistro,FechaDeAutorizacion,FechaDeTitulacion,OpcionDeTitulacion,
Aprobado,AutorizacionDeRegistroTrabajoTitulacion,AutorizacionDeImpresion,LiberacionDeProyectoTitulacionIntegral,FechaYHoraDeRegistro,Observaciones_bitacora,
Portada_bitacora,Trabajo_enviado_bitacora,Liberacion_asigJurado_bitacora from Estudiante where IdEstudiante = $ids");
$resultado = conexionMysql($consulta);


require_once 'PhpWord/Autoloader.php';
\PhpOffice\PhpWord\Autoloader::register();

$phpWord = new \PhpOffice\PhpWord\PhpWord();


$section = $phpWord->addSection(array('orientation' => 'landscape','marginLeft' => 400, 'marginRight' => 300));

$header = array('size' => 16, 'bold' => true);

//borderSize tamaño linea horizontal
$styleTable = array('borderSize' => 10, 'borderColor' => '006699', 'cellMargin' => 50);
//estilo de la primera fila de la tabla
$styleFirstRow = array('borderBottomSize' => 10, 'borderBottomColor' => '0000FF', 'bgColor' => '66BBFF');
//estilo de la linea vertical
$cellStyle = array(
'borderColor' => '006699',
'borderSize' => 10, //tamaño linea vertical
'cellMargin' => 50
);

//estilo de parrafo
$paragraphStyle = array('align' => 'center');
$phpWord->addParagraphStyle('pStyle', $paragraphStyle);

//estilo para la fuente
$fontStyle = array( 'size'=>10,'bold' => true);
$fontStyle2 = array( 'size'=>10);

$phpWord->addTableStyle('Basic table', $styleTable, $styleFirstRow);

$section->addText("Bitácora mes de " . $mes, $header);

$table = $section->addTable('Basic table');

$table->addRow();
//No.
//$table->addCell(500,$cellStyle)->addText("No.",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Nombre
$table->addCell(1800,$cellStyle)->addText("Nombre y correo",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Matricula
$table->addCell(800,$cellStyle)->addText("Matricula",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Fecha de registro
$table->addCell(900,$cellStyle)->addText("Fecha de registro",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Plan de estudios
$table->addCell(1000,$cellStyle)->addText("Plan de estudios",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Opción
$table->addCell(1000,$cellStyle)->addText("Opción",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Asignación de jurado
$table->addCell(1000,$cellStyle)->addText("Asignación de jurado",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Trabajo enviado
$table->addCell(900,$cellStyle)->addText("Trabajo enviado",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Asignación (Revisión).- Interno
$table->addCell(1000,$cellStyle)->addText("Asignación (Revisión).- Interno",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Registro opción
$table->addCell(800,$cellStyle)->addText("Registro opción",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Portada
$table->addCell(700,$cellStyle)->addText("Portada",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Liberación y Asignación de Jurado.
$table->addCell(1000,$cellStyle)->addText("Liberación y Asignación de Jurado.",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Autorización de impresión
$table->addCell(1300,$cellStyle)->addText("Autorización de impresión",$fontStyle,'pStyle'); //addCell(ancho,estilo)
//Observaciones
$table->addCell(2800,$cellStyle)->addText("Observaciones",$fontStyle,'pStyle'); //addCell(ancho,estilo)

while( $fila = mysql_fetch_assoc($resultado) ) 
{
	//consultar si tiene asignado jurado
	$idE = $fila['IdEstudiante'];
	$consulta = sprintf("select * from AsignacionDeSinodal where IdEstudiante = $idE");
	$result = conexionMysql($consulta);
	if( mysql_num_rows($result) > 0 )
		$jurado = true;
	else
		$jurado = false;
	
	
$table->addRow();
//No.
//$table->addCell(500,$cellStyle)->addText("$idE",$fontStyle2,'pStyle');
//Nombre y correo
$table->addCell(1800,$cellStyle)->addText( replace($fila['Nombre']) .' '. replace($fila['Apellidos']).' '.$fila['CorreoElectronico'],$fontStyle2,'pStyle');
//Matricula
$table->addCell(800,$cellStyle)->addText($fila['NumControl'],$fontStyle2,'pStyle');
//Fecha de registro
$table->addCell(900,$cellStyle)->addText($fila['FechaYHoraDeRegistro'],$fontStyle2,'pStyle');
//Plan de estudios
$table->addCell(1000,$cellStyle)->addText($fila['Reticula'],$fontStyle2,'pStyle');
//Opción
$table->addCell(1000,$cellStyle)->addText ( replace($fila['OpcionDeTitulacion']),$fontStyle2,'pStyle');
//Asignación de jurado
if( $jurado == true )
	$table->addCell(1000,$cellStyle)->addText("SI",$fontStyle2,'pStyle');
else
	$table->addCell(1000,$cellStyle)->addText("NO",$fontStyle2,'pStyle');
//Trabajo enviado
if( $fila['Trabajo_enviado_bitacora'] == true )
{
	$table->addCell(900,$cellStyle)->addText("SI",$fontStyle2,'pStyle');
}
if( $fila['Trabajo_enviado_bitacora'] == false )
{
	$table->addCell(900,$cellStyle)->addText("NO",$fontStyle2,'pStyle');
}
//Asignación (Revisión).- Interno
$table->addCell(1000,$cellStyle)->addText("",$fontStyle2,'pStyle'); //addCell(ancho,estilo)
//Registro opción 
if( $fila['AutorizacionDeRegistroTrabajoTitulacion'] == true )
{
	$table->addCell(900,$cellStyle)->addText("SI",$fontStyle2,'pStyle');
}
if( $fila['AutorizacionDeRegistroTrabajoTitulacion'] == false )
{
	$table->addCell(900,$cellStyle)->addText("NO",$fontStyle2,'pStyle');
}
//Portada
if( $fila['Portada_bitacora'] == true )
{
	$table->addCell(700,$cellStyle)->addText("SI",$fontStyle2,'pStyle');
}
if( $fila['Portada_bitacora'] == false )
{
	$table->addCell(700,$cellStyle)->addText("NO",$fontStyle2,'pStyle');
}
//Liberación y Asignación de Jurado. 
if( $fila['Liberacion_asigJurado_bitacora'] == true )
{
	$table->addCell(700,$cellStyle)->addText("SI",$fontStyle2,'pStyle');
}
if( $fila['Liberacion_asigJurado_bitacora'] == false )
{
	$table->addCell(700,$cellStyle)->addText("NO",$fontStyle2,'pStyle');
}
//Autorización de impresión
if ($fila['AutorizacionDeImpresion'] == true)
	$table->addCell(1300,$cellStyle)->addText("SI",$fontStyle2,'pStyle'); //addCell(ancho,estilo)
else 
	$table->addCell(1300,$cellStyle)->addText("NO",$fontStyle2,'pStyle'); //addCell(ancho,estilo)
//Observaciones
if( $fila['Observaciones_bitacora'] == null )
	$table->addCell(2800,$cellStyle)->addText("",$fontStyle2,'pStyle');
else
	{
		$observaciones = $fila['Observaciones_bitacora'];	
		$table->addCell(2800,$cellStyle)->addText("$observaciones",$fontStyle2,'pStyle');
	}

 
}

/*
for($r = 1; $r <= 8; $r++) 
{
	$table->addRow();
  for($c = 1; $c <= 5; $c++) 
  {
		$table->addCell(1300,$cellStyle)->addText("Row $r, Cell $c"); //addCell(ancho,estilo)
	}
}
*/

// Finally, write the document:
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');

$objWriter->save('documentos/bitacora.docx');

header("Location: descargaArchivo.php?doc=bitacora.docx");

//header('Content-Description: File Transfer');
//header('Content-Transfer-Encoding: binary');
//header('Content-Length: '.filesize('helloWorld.docx'));

//readfile('helloWorld.docx');
//unlink('helloWorld.docx');


/*
$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'ODText');
$objWriter->save('helloWorld.odt');

$objWriter = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'RTF');
$objWriter->save('helloWorld.rtf');
*/

// Save file
//	echo write($phpWord, basename(__FILE__, '.php'), $writers);
?>

