<?php
	include "funciones.php";
	
	echo "<link rel='stylesheet' href='/bootstrap.min.css'>";
	echo "<link rel='stylesheet' href='/font-awesome.min.css'>";
	echo "<link rel='stylesheet' href='/bootstrap-theme.css' media='screen' >";
	echo "<link rel='stylesheet' href='/main.css'>";

	function replace($cadena) {
		$cadena = str_replace("&AACUTE;", "Á", $cadena);
		$cadena = str_replace("&EACUTE;", "É", $cadena);
		$cadena = str_replace("&IACUTE;", "Í", $cadena);
		$cadena = str_replace("&OACUTE;", "Ó", $cadena);
		$cadena = str_replace("&UACUTE;", "Ú", $cadena);
		$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
		$cadena = str_replace("&aacute;", "á", $cadena);
		$cadena = str_replace("&eacute;", "é", $cadena);
		$cadena = str_replace("&iacute;", "í", $cadena);
		$cadena = str_replace("&oacute;", "ó", $cadena);
		$cadena = str_replace("&uacute;", "ú", $cadena);
		$cadena = str_replace("&ntilde;", "ñ", $cadena);
		return $cadena;
	}
	function compararFechas($primera, $segunda) { // $primera --> fecha establecida  $segunda --> fecha que transcurre
  		$valoresPrimera = explode ("/", $primera);   
  		$valoresSegunda = explode ("/", $segunda); 
		$anyoPrimera   = $valoresPrimera[0];
  		$mesPrimera  = $valoresPrimera[1]; 
  		$diaPrimera    = $valoresPrimera[2];  
   
  		$anyoSegunda  = $valoresSegunda[0];
  		$mesSegunda = $valoresSegunda[1];  
  		$diaSegunda   = $valoresSegunda[2];  

  		$diasPrimeraJuliano = gregoriantojd($mesPrimera, $diaPrimera, $anyoPrimera);  
  		$diasSegundaJuliano = gregoriantojd($mesSegunda, $diaSegunda, $anyoSegunda);     

    	return $diasPrimeraJuliano - $diasSegundaJuliano;			 
	}
	//tabla que muestra los alumnos autorizados

	//conexion a mysql
	openConectionMysql();
				
	//CONSULTA
	$consulta = sprintf("SELECT firmarAutorizaciones.IdEstudiante,Estudiante.NumControl,Estudiante.Nombre,
		Estudiante.Apellidos FROM firmarAutorizaciones INNER JOIN Estudiante ON 
		firmarAutorizaciones.IdEstudiante = Estudiante.IdEstudiante WHERE AutorizacionDeImpresion = true");
	
	//EJECUTAR LA CONSULTA
	$resultado = mysql_query($consulta);
	
	//COMPROBAR LA CONSULTA
	if(!$resultado)
	{
		$mensaje = "CONSULTA NO VALIDA ".mysql_error(). "<br />";
		$mensaje.= "CONSULTA COMPLETA ".$consulta;
		die($mensaje);
	}		
	
	//TABLA A MOSTRAR DE ESTUDIANTES AUTORIZADOS
	echo "<table border width='700'>";
	echo "<tr>";
		echo "<th class='thin idestudiante text-center'>"; echo "Id"; echo "</th>";
		echo "<th class='thin numcontrol text-center'>"; echo "No. Control"; echo "</th>";
		echo "<th class='thin nombreestudiante text-center'>"; echo "Nombre"; echo "</th>";
		echo "<th class='thin apellidosestudiante text-center'>"; echo "Apellidos"; echo "</th>";
		echo "<th class='thin ceremonia text-center'>"; echo "Ceremonia"; echo "</th>";
	echo "</tr>";

		$idAnterior = 0;
		while($fila = mysql_fetch_assoc($resultado)) 
		{
			$idActual = $fila['IdEstudiante'];
			$consulta2 = sprintf("SELECT count(*) firmas FROM firmarAutorizaciones WHERE IdEstudiante = 
				'$idActual' AND AprobacionTrabajo = true");
			$resultadoNumFirmas = conexionMysql($consulta2);
			$numFirmas = mysql_result($resultadoNumFirmas, 0, 'firmas');
			if ($numFirmas == 4) {
				if ($idActual != $idAnterior) {
					$consulta3 = sprintf("SELECT FechaDeTitulacion,LugarDeCeremoniaDeTitulacion FROM
				  			Estudiante WHERE IdEstudiante = '$idActual'");
				  	$resultadoConsulta3 = conexionMysql($consulta3);
				  	$fechaTitulacion = mysql_result($resultadoConsulta3, 0, 'FechaDeTitulacion');
				  	$lugarTitulacion = mysql_result($resultadoConsulta3, 0, 'LugarDeCeremoniaDeTitulacion'); 
					echo "<tr>";
				  		echo "<td class='text-muted text-center'>"; echo $fila['IdEstudiante']; echo "</td>";
				  		echo "<td class='text-muted text-center'>"; echo $fila['NumControl']; echo "</td>";
				  		echo "<td class='text-muted'>"; echo replace($fila['Nombre']); echo "</td>";
				  		echo "<td class='text-muted'>"; echo replace($fila['Apellidos']); echo "</td>";
				  		echo "<td class='text-muted'>"; 
				  			if ($fechaTitulacion == null && $lugarTitulacion == null) {
				  				echo "Sin asignar";
				  			}
				  			else {
				  				if ($fechaTitulacion == "0000-00-00 00:00:00" && $lugarTitulacion != null) {
				  					echo "Falta asignar fecha";
				  				}
				  				else {
				  					if ($fechaTitulacion != "0000-00-00 00:00:00" && $lugarTitulacion == null) {
				  						echo "Falta asignar lugar";
				  					}
				  					else {
				  						if ($fechaTitulacion != "0000-00-00 00:00:00" && $lugarTitulacion != null) {
				  							$ahora = date("Y-n-j H:i:s");
				  							$ahoraSegundos = strtotime($ahora);
				  							$fechaTitulacionSegundos = strtotime($fechaTitulacion);
				  							$tiempoRestante = $fechaTitulacionSegundos - $ahoraSegundos;
				  							$duracionMaxima = $fechaTitulacionSegundos + 5400;
				  							$diasRestantes = compararFechas($fechaTitulacion, $ahora);
				  							if ($diasRestantes > 0) {
				  								echo "En proceso de realizarse";
				  							}
				  							elseif ($diasRestantes < 0) {
				  								echo "Se ha llevado a cabo";
				  							}
				  							elseif ($diasRestantes == 0 && $tiempoRestante > 0) {
				  								echo "En proceso de realizarse";
				  							}
				  							elseif ($diasRestantes == 0 && ($duracionMaxima - $ahoraSegundos) <= 0) {
				  								echo "Se ha llevado a cabo";
				  							}
				  							elseif ($diasRestantes == 0 && ($ahoraSegundos >= $fechaTitulacionSegundos && $ahoraSegundos <= $duracionMaxima)) {
				  								echo "Llevandose a cabo";
				  							}
				  						}
				  					}
				  				}
				  			}
				  		echo "</td>";
					echo "</tr>";
				}	
			}
			$idAnterior = $idActual;
		}
	echo "</table>"
?>