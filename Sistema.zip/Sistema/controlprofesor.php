<?php
	include 'funciones.php';

	$num_targeta = $_POST['NumTargeta'];
	$clave_de_acceso = $_POST['ClaveDeAcceso'];

	if ($num_targeta == "" || $clave_de_acceso == "") {
		header("Location: ingresoprofesor.php?vacio=si");
	}
	else {
		openConectionMysql();
		$sentencia = "SELECT * FROM Profesor WHERE NumTargeta = '$num_targeta' AND ClaveDeAcceso = '$clave_de_acceso'";
		$res = mysql_query($sentencia);
		if (mysql_num_rows($res)>0) {
			session_name("loginUsuario"); //Asigno un nombre a la sesión
			session_start(); //Inicio la sesión
			$_SESSION["autentificado"]="si"; //Defino la sesión que demuestra que el usuario está autorizado
			$_SESSION["numtargeta"] = $num_targeta;
			$_SESSION["nombre"] = mysql_result($res,0,'Nombre');
			$_SESSION["sexo"] = mysql_result($res,0,'Sexo');
			$_SESSION["id"] = mysql_result($res,0, "IdProfesor");
			$_SESSION["ultimoAcceso"] = date("Y-n-j H:i:s"); //Defino la fecha y hora de inicio de sesión en formato aaaa-mm-dd hh:mm:ss
			$ultimo_acceso = $_SESSION["ultimoAcceso"];
			mysql_query("UPDATE Profesor SET UltimoAcceso = '$ultimo_acceso' WHERE NumTargeta = '$num_targeta'");
			header("Location: perfilprofesor.php");
		}
		else {
			header("Location: ingresoprofesor.php?errorusuario=si");
		}
	}
	mysqli_free_result($res);
	mysqli_close();
?>