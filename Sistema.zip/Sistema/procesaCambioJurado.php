

<?php

include "funciones.php";

function replace($cadena) {
	$cadena = str_replace("&AACUTE;", "Á", $cadena);
	$cadena = str_replace("&EACUTE;", "É", $cadena);
	$cadena = str_replace("&IACUTE;", "Í", $cadena);
	$cadena = str_replace("&OACUTE;", "Ó", $cadena);
	$cadena = str_replace("&UACUTE;", "Ú", $cadena);
	$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
	$cadena = str_replace("&aacute;", "á", $cadena);
	$cadena = str_replace("&eacute;", "é", $cadena);
	$cadena = str_replace("&iacute;", "í", $cadena);
	$cadena = str_replace("&oacute;", "ó", $cadena);
	$cadena = str_replace("&uacute;", "ú", $cadena);
	$cadena = str_replace("&ntilde;", "ñ", $cadena);
	return $cadena;
}

error_reporting( E_ERROR | E_WARNING );
	$idAlumno = $_POST['id'];
	
	function generaProfesores($sinodal,$puesto,$IdAlum) 
	{
		//suplente 1, 2 y 3
		$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor,AsignacionDeSinodal WHERE AsignacionDeSinodal.IdEstudiante = '$IdAlum' and AsignacionDeSinodal.Suplente1 = Profesor.IdProfesor;");
		$resultado =conexionMysql($consulta);
		$fila = mysql_fetch_assoc($resultado);
		$idSup1= $fila['IdProfesor'];
					
		$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor,AsignacionDeSinodal WHERE AsignacionDeSinodal.IdEstudiante = '$IdAlum' and AsignacionDeSinodal.Suplente2 = Profesor.IdProfesor;");
		$resultado =conexionMysql($consulta);
		$fila = mysql_fetch_assoc($resultado);
		$idSup2= $fila['IdProfesor'];
		
		$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor,AsignacionDeSinodal WHERE AsignacionDeSinodal.IdEstudiante = '$IdAlum' and AsignacionDeSinodal.Suplente3 = Profesor.IdProfesor;");
		$resultado =conexionMysql($consulta);
		$fila = mysql_fetch_assoc($resultado);
		$idSup3= $fila['IdProfesor'];
			
		echo "<select name='$puesto' id='$puesto' class='form-control' style='width:300;' disabled='disabled'>";
		//Formular la consulta
		$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor");
		$resultado =conexionMysql($consulta);
		
		while($fila = mysql_fetch_assoc($resultado))
		{
			$id= $fila['IdProfesor'];
			
			if($sinodal == $id) //aparece seleccionado el sinodal del alumno actualmente
			{
				echo "<option value=$id selected='selected'>";
				echo replace($fila['Nombre'])." ". replace($fila['Apellidos']);echo"</option>";
			}
			else if( $id == $idSup1 )
			{
				echo "<option value=$id>";echo replace($fila['Nombre'])." ". replace($fila['Apellidos']) . "(Suplente 1)";echo"</option>";
			}
			else if( $id == $idSup2 )	
			{
				echo "<option value=$id>";echo replace($fila['Nombre'])." ". replace($fila['Apellidos']) . "(Suplente 2)";echo"</option>";
			}
			else if( $id == $idSup3 )	
			{
				echo "<option value=$id>";echo replace($fila['Nombre'])." ". replace($fila['Apellidos']) . "(Suplente 3)";echo"</option>";
			}
			else
				echo "<option value=$id>";echo replace($fila['Nombre'])." ". replace($fila['Apellidos']);echo"</option>";
		}
		echo "</select>";
	}	
	
	function obtenerSinodal($id,$campo)
	{
		$consulta = "select $campo from AsignacionDeSinodal WHERE AsignacionDeSinodal.IdEstudiante = $id;";
		$resultado = conexionMysql($consulta);
	
		if( mysql_num_rows($resultado) > 0 ) 
		{	
			return mysql_result($resultado,0,$campo); 
		}
	}	
	
	if( $idAlumno > 0 ) 
	{
		$bgcolorVisto = "'#d0e7ff' style='border-right:1px solid #cccccc;'";
		$bgcolorNoVisto =	"'#FFFF99' style='border-right:1px solid #cccccc;'";		
		
		$presidente = obtenerSinodal($idAlumno,'Presidente');
		$secretario = obtenerSinodal($idAlumno,'Secretario');
		$vocal = obtenerSinodal($idAlumno,'Vocal');
		$suplente = obtenerSinodal($idAlumno,'Suplente'); 
		//echo "<form name='cambio' action='cambioJurado.php' method='post'>";
		echo "<label><h3>SOLO HABILITE LOS JURADOS A CAMBIAR</h3></label>";
		echo "<div id='iframe'>";
		echo "<table>";
			echo "<tr>";
				echo "<td><br></td>";
				echo "<th bgcolor=".$bgcolorVisto.">"; echo "PUESTO"; echo "</th>"; 
				echo "<th bgcolor=".$bgcolorVisto.">"; echo "NOMBRE"; echo "</th>";
			echo "</tr>";
					
			echo "<tr>";
				echo "<td bgcolor=".$bgcolorVisto.">"; echo" <input type='checkbox' name='cambia_presidente' id='cambia_presidente' onclick='Block()'> "; echo "</td>"; 
				echo "<th bgcolor=".$bgcolorVisto.">"; echo "PRESIDENTE"; echo "</th>";
				echo "<td bgcolor=".$bgcolorVisto.">"; generaProfesores($presidente,'presidente',$idAlumno);echo "</td>";				
			echo "</tr>";
			
			echo "<tr>"; 
				echo "<td bgcolor=".$bgcolorVisto.">"; echo" <input type='checkbox' name='cambia_secretario' id='cambia_secretario' onclick='Block()'> "; echo "</td>";	
				echo "<th bgcolor=".$bgcolorVisto.">";  echo "SECRETARIO"; echo "</th>";
				echo "<td bgcolor=".$bgcolorVisto.">"; generaProfesores($secretario,'secretario',$idAlumno); echo "</td>";
			echo "</tr>";
			
			echo "<tr>";
				echo "<td bgcolor=".$bgcolorVisto.">"; echo" <input type='checkbox' name='cambia_vocal' id='cambia_vocal' onclick='Block()'> "; echo "</td>";
				echo "<th bgcolor=".$bgcolorVisto.">";  echo "VOCAL"; echo "</th>";
				echo "<td bgcolor=".$bgcolorVisto.">"; generaProfesores($vocal,'vocal',$idAlumno); echo "</td>";
			echo "</tr>";
			
			echo "<tr>";
				echo "<td bgcolor=".$bgcolorVisto.">"; echo" <input type='checkbox' name='cambia_suplente' id='cambia_suplente' onclick='Block()'> "; echo "</td>"; 
				echo "<th bgcolor=".$bgcolorVisto.">"; echo "SUPLENTE"; echo "</th>";
				echo "<td bgcolor=".$bgcolorVisto.">"; generaProfesores($suplente,'suplente',$idAlumno); echo "</td>";
				echo "</tr>";		
		echo "</table>"; echo "<br>";
		echo "</div>";
		echo "<label>Motivo del cambio de jurado:</label>";echo "<br>";
		echo "<input type='text' name='motivo' id='motivo' placeholder='Ejemplo: estará(n) de COMISIÓN' style='width:400;' class='form-control' />";
		echo "<br>";
		echo "<br>";
		
		echo "<input type='submit' name='cambio_jurado' value='CAMBIO JURADO' class='btn btn-danger' />";
		 
		//echo "</form>";
		 
	}
	else 
	{
		echo "<label>Selecciona un alumno.</label>";
	}
	
	
	
?>
