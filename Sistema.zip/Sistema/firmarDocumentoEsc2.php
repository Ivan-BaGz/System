
<?php

//funciones
include "funciones.php";

error_reporting( E_WARNING | E_ERROR);

session_name("loginUsuario");
session_start();			
	
$id_sinodal = $_SESSION["id"];	
	
/************************************************************************
**************   RUTINA PARA COMPROBAR SI MD5_C ES IGUAL A MD5_S  *******
************************************************************************/

	function autoriza() 
	{		
		//se reanuda la sesión
		session_name("loginUsuario");
		session_start();

		$t = md5( $_SESSION["t_parcial"] . getenv("REMOTE_ADDR") );							
		
		//consulta para obtener la información del usuario
				
		$user = $_POST['usuario'];
		$id_estudiante = $_GET["user"];
		$campo = $_GET["firma"];
		$fecha = $_GET["fecha"];
		
		//consulta para obtener la información del usuario		
		
		$consulta = sprintf("SELECT IdProfesor,NumTargeta,FirmaD FROM Profesor WHERE NumTargeta = '$user'");
		
		//realizar el query
		$usuario = conexionMysql($consulta);
	
		
		//if( mysql_num_rows($usuario) > 0 && $user == $_SESSION["numtargeta"] )
		//¿existe el usuario en la base de datos?
		if( mysql_num_rows($usuario) > 0 )  
		{
			//obtener id del profesor
			$id_profesor = mysql_result($usuario, 0, 'IdProfesor');
	
			//obtener la fecha y hora de la aprobacion de la firma
			$fecha_hora = date("Y-m-d H:i:s");
			
			//echo mysql_result($usuario, 0, 'FirmaD'). "  Firma del usuario en la base de datos ";
			echo "<br>";	
			echo $_POST["pass"]. "  Firma robada";
			echo "<br>";											
			echo md5( mysql_result($usuario, 0, 'FirmaD') . $t). "  Firma creada con el algoritmo OTP";			
			
			if( $_POST["pass"] == md5( mysql_result($usuario, 0, 'FirmaD') . $t))
			{
				$insercion = sprintf("UPDATE firmarAutorizaciones SET $campo = true , $fecha = '$fecha_hora' where IdProfesor = $id_profesor and IdEstudiante = $id_estudiante");
						
				
				//abrimos conexion a la base de datos
				openConectionMysql();
				mysql_query($insercion);				
				
				unset( $_SESSION["t_parcial"] ); //se destruye la variable
				header ("Location: estadoFirma.php");
			}
			else 
			{
				unset( $_SESSION["t_parcial"] ); //se destruye la variable
				//session_unset();
				//session_destroy();
				header("Location: estadoFirma.php?error=no_valida");
			}
			
		}
		else
		{
			unset( $_SESSION["t_parcial"] ); //se destruye la variable
			//session_unset();
			//session_destroy();
			header("Location: estadoFirma.php?error=user_incorrecto");
		}
	} 
			
function muestraForm() 
{		
	
	// Establecer la zona horaria predeterminada a usar. Disponible desde PHP 5.1
	//date_default_timezone_set('America/Mexico_City');
	session_name("loginUsuario");
	session_start();

	$_SESSION["t_parcial"]=md5(date("l dS of F Y h:i:s A"));	
	
?>


<html lang="es">
<head>

		<!-- proporciona hex_md5 -->
<script src="md5.js"></script>
<script language="JavaScript">

	function encrypt() 
	{
		var md5_pre=hex_md5(document.signature.pass.value);
		/* t = t_parcial + IP cliente */
		var md5=hex_md5(md5_pre+"<? echo md5($_SESSION["t_parcial"] .getenv("REMOTE_ADDR")); ?>");
		/* md5 es MD5_C */
		document.signature.pass.value=md5;
		alert(document.signature.pass.value);
	}
		
	</script>
                 		


	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Firmas | documentos</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8" />	
		
		<link rel="stylesheet" type="text/css" href="select_dependientes.css">
		<script type="text/javascript" src="select_dependientesFirmarDocumentos.js"></script>
		
	<script type="text/javascript" src="select_dependientesListaAlumnos.js"></script>

	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
	
	<style type="text/css">
		#iframe
    	{
    		overflow:auto;
    		width:700px;
    		height:300px;
    	}
   </style> 		
		
	</head>
	
	<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href=""><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li><a href="datospersonalesprofesor.php">Datos personales</a></li>
					<li class="dropdown">	
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Estudiantes <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="firmarDocumento.php">Firmar Documento</a></li>
						</ul>
					</li>
					
					<?php
					/*
					session_name('loginUsuario');
					session_start();
					
					$id = $_SESSION["id"];					
					
					$consulta = "select count(*) as MensajesNuevos from MensajesProfesor where IdProfesor = $id and visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					*/
					?>
					<li class="active"><a class="btn" href="verMensajesProfesor.php"><label><?php echo $mensajes ?> mensaje(s)</label></a></li>
					<?php
					/*
					}
					*/
					?>
					
					<li class="active"><a class="btn" href="perfilprofesor.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Profesor</a></li>
			<li class="active">Firmar documentos</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Firmar documentos</h1>
				</header>
				
				<div class="col-md-8 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
			
			<?php
				
			$user = $_GET["user"];
			$firma = $_GET["firma"];
			$fecha = $_GET["fecha"];
			echo "<form name='signature' action='firmarDocumentoEsc2.php?accion=auth&user=$user&firma=$firma&fecha=$fecha' method='post' >";
			
			?>
			
				<label>Numero de Tarjeta</label>										
				<input type="text" name="usuario" /><br/>
				<label>Firma</label>
				<input type="password" name="pass" /><br/><br>
				<input type="submit" name="enviar_datos" id="enviar_datos" value="FIRMAR" class="btn btn-danger centrar-boton"/>
			</form>
			
			<?php
			}
			if( $_GET["accion"] == "auth" ) 
			{
				autoriza();
			}
			else 
			{
				muestraForm();
			}

?>
			
			
		

</div>
					</div>
				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title"></h3>
						<div class="widget-body">	
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>
</body>
</html>
