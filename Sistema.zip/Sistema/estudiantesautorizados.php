<?php include 'seguridadCoordTitulacion.php'; ?>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Estudiantes | autorizados</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
	<script type="text/javascript">
		function soloNumeros(e) {
			var entrada = window.event ? window.event.keyCode : e.which;
			if (entrada == 8 || entrada == 9 || entrada == 189 || entrada == 32) {
				return true;
			}
			if (e.shiftKey && entrada==189) {
				return true;
			}

			return /\d/.test(String.fromCharCode(entrada));
		}
		function fecha(e) {
			tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==32) { // espacio
				return true; 
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (tecla==189) { // guion
				return true;
			}
			if (tecla==190) {
				return true;
			}
			if (e.shiftKey && tecla==186) {
				return true;
			}
			if (tecla==188) { // coma
				return false;
			}
			if (e.shiftKey && tecla==189) { // guion bajo
				return false;
			}
			if (e.shiftKey && tecla==49 || e.shiftKey && tecla==50 || e.shiftKey && tecla==51 || 
				e.shiftKey && tecla==52 || e.shiftKey && tecla==53 || e.shiftKey && tecla==54 || 
				e.shiftKey && tecla==55 || e.shiftKey && tecla==56 || e.shiftKey && tecla==57 || 
				e.shiftKey && tecla==48 || e.shiftKey && tecla==187 || 
				e.shiftKey && tecla==191 || e.shiftKey && tecla==192 || e.shiftKey && tecla==219 || 
				e.shiftKey && tecla==220 || e.shiftKey && tecla==221 || e.shiftKey && tecla==222) {
				return false;
			}
			if (tecla==187 || tecla==191 || tecla==192 || tecla==219 || tecla==220 || tecla==221 || tecla==222) {
				return false;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[0-9\W]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function validar(form1) {
			if (document.form1.NumControl.value == "") {
				alert("Operación imposible. No se ha seleccionado ningún estudiante");
				return false;
			}
		}
		function validar2() {
			if (document.getElementById('ModificarProceso').checked==false) {
    			alert("Imposible guardar. No se ha realizado ningún cambio");
    			return false;
  			}
		}
		function limpiar() {
			document.getElementById("form1").reset();
		}
		function habilitar() {
			document.form1.FechaDeTitulacion.disabled=!document.form1.FechaDeTitulacion.disabled; 
			document.form1.LugarDeCeremoniaDeTitulacion.disabled=!document.form1.LugarDeCeremoniaDeTitulacion.disabled;
		}
	</script>
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="#"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Estudiantes <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="estudiantesautorizados.php">Estudiantes autorizados</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrador <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="modificacionesAdminCoordTitulacion.php">Modificaciones</a></li>
						</ul>
					</li>
					
					<?php
					include "funciones.php";
					
					$consulta = "select count(*) as MensajesNuevos from MensajesCoordTitulacion where visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					?>
						<li class="active3"><a class="btn" href="verMensajesCoordTitulacion.php"><?php echo $mensajes ?> Mensaje(s)</a></li>
					<?php
					}
					else
						echo '<li class="active"><a class="btn" href="verMensajesCoordTitulacion.php">Mensajeria</a></li>';
					?>
					<li class="active"><a class="btn" href="perfilCoordTitulacion.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Estudiantes autorizados</h1>
				</header>
				
				<?php
					echo "<IFRAME NAME='estudiantes_autorizados' SRC='tablaEstudiantesAutorizados.php' WIDTH='700' HEIGHT='200' FRAMEBORDER='1' MARGINWIDTH='3' MARGINHEIGHT='3' SCROLLING='Auto' class='centrar-tabla-estudiantesautorizados'></IFRAME>";

				?>
				<br><br>
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Información del estudiante</h3>

							<?php
								function replace($cadena) {
									$cadena = str_replace("&AACUTE;", "Á", $cadena);
									$cadena = str_replace("&EACUTE;", "É", $cadena);
									$cadena = str_replace("&IACUTE;", "Í", $cadena);
									$cadena = str_replace("&OACUTE;", "Ó", $cadena);
									$cadena = str_replace("&UACUTE;", "Ú", $cadena);
									$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
									$cadena = str_replace("&aacute;", "á", $cadena);
									$cadena = str_replace("&eacute;", "é", $cadena);
									$cadena = str_replace("&iacute;", "í", $cadena);
									$cadena = str_replace("&oacute;", "ó", $cadena);
									$cadena = str_replace("&uacute;", "ú", $cadena);
									$cadena = str_replace("&ntilde;", "ñ", $cadena);
									return $cadena;
								}
								if (isset($_POST['ver_info_estudiante'])) {
									$num_control = $_POST['NumControl'];
									$verAutorizaciones = "SELECT AutorizacionDeImpresion,LiberacionDeProyectoTitulacionIntegral FROM Estudiante WHERE NumControl = $num_control";
										$resultado = conexionMysql($verAutorizaciones);


										$autorizacionimpresion = mysql_result($resultado,0,'AutorizacionDeImpresion');
										$liberacionproyecto = mysql_result($resultado,0,'LiberacionDeProyectoTitulacionIntegral');
										
									if (empty($_POST['NumControl'])) {
										echo "<p class='text-center text-black2'>Introduce un número de tarjeta</p>";
										$error = true;
									}
									else {
										$num_control = $_POST['NumControl'];
									}
									if ($error != true) {
										openConectionMysql();
										mysql_query("SET NAMES 'utf8'");
										$nuevo_numcontrol = mysql_query("SELECT NumControl FROM Estudiante WHERE NumControl = $num_control");
										if (mysql_num_rows($nuevo_numcontrol) > 0) {
											$consulta = sprintf("SELECT * FROM Estudiante WHERE NumControl = $num_control");
											$resultado = mysql_query($consulta);
											$fila = mysql_fetch_assoc($resultado);

											$nombre_replace = replace($fila['Nombre']);
											$apellidos_replace = replace($fila['Apellidos']);
											$correo_electronico_replace = replace($fila['CorreoElectronico']);
											$carrera_replace = replace($fila['Carrera']);
											$reticula_replace = replace($fila['Reticula']);
											$opcion_titulacion_replace = replace($fila['OpcionDeTitulacion']);
											$proyecto_replace = replace($fila['Proyecto']);
											$lugar_titulacion_replace = replace($fila['LugarDeCeremoniaDeTitulacion']);
										}
										else {
											echo "<p class='text-black2 text-center'>No se encuentra registrado ese número de tarjeta</p>";
										}
									}
								}
								if (isset($_POST['guardar_cambios'])) {
									if (empty($_POST['NumControl2'])) {
										echo "<p class='text-center text-black2'>Imposible guardar cambios<br>No se ha buscado ningún estudiante</p>";
										$error = true;
									}
									else {
										$num_control_seleccionado = $_POST['NumControl2'];
									}
									
									$modificarProceso = $_POST['ModificarProceso'];

									if ($modificarProceso != true) {
										echo "<p class='text-center text-black2'>Imposible guardar<br>No se ha realizado ningún cambio</p>";
										$error = true;
									}
									
									if ($error != true) {
										openConectionMysql();
										mysql_query("SET NAMES 'utf8'");
										if ($modificarProceso == true) {
											$fechaDeTitulacion = $_POST['FechaDeTitulacion'];
											
											$mysqli = conexionMysqli();
											
											$lugarTitulacion = $mysqli->real_escape_string(htmlspecialchars($_POST['LugarDeCeremoniaDeTitulacion']));
											$lugarTitulacion = htmlentities($lugarTitulacion);
											
											$queryupdate2 = "UPDATE Estudiante SET FechaDeTitulacion = '$fechaDeTitulacion', AutorizacionDeImpresion = '$autorizacionDeImpresion', LiberacionDeProyectoTitulacionIntegral = '$liberacionTitulacionIntegral', LugarDeCeremoniaDeTitulacion = '$lugarTitulacion' WHERE NumControl = '$num_control_seleccionado'";
											if (mysql_query($queryupdate2)) {
												echo "<p class='text-black2 text-center'>Acción realizada con éxito<br>Se han guardado los cambios en el proceso del estudiante</p>";
											}
											else {
												echo "<p class='text-black2 text-center'>Error al guardar<br>Vuelva a hacer modificaciones en el proceso del estudiante</p>";
											}
										}
									}
								}
								if (isset($_POST['borrar_estudiante'])) {
									if (empty($_POST['NumControl2'])) {
										echo "<p class='text-center text-black2'>Imposible guardar cambios<br>No se ha buscado ningún estudiante</p>";
										$error = true;
									}
									else {
										$num_control_a_borrar = $_POST['NumControl2'];
									}
									if ($error != true) {
										openConectionMysql();
									
										$query2 = sprintf("SELECT IdEstudiante FROM Estudiante WHERE NumControl = $num_control_a_borrar");
										$resultado = conexionMysql($query2);
										$id = mysql_result($resultado, 0, 'IdEstudiante');
									
										$query = "DELETE FROM AsignacionDeSinodal WHERE IdEstudiante = '$id'";
										$query4 = "DELETE FROM cambioJurado WHERE IdEstudiante = '$id'";
										$query5 = "DELETE FROM firmarAutorizaciones WHERE IdEstudiante = '$id'";
										$query6 = "DELETE FROM MensajesAlumno WHERE IdEstudiante = '$id'";
										$query7 = "DELETE FROM MensajesProfesor WHERE IdEstudiante = '$id'";
										$query8 = "DELETE FROM MensajesAdministrador WHERE IdEstudiante = '$id'";
										$query9 = "DELETE FROM MensajesCoordTitulacion WHERE IdEstudiante = '$id'";
										$query10 = "DELETE FROM cambioTema WHERE IdEstudiante = '$id'";
										$query11 = "DELETE FROM notificaciones WHERE IdEstudiante = '$id'";
										$query3 = "DELETE FROM Estudiante WHERE IdEstudiante = '$id'";
										if (mysql_query($query) && mysql_query($query11) && mysql_query($query4) && mysql_query($query5) && 
											mysql_query($query6) && mysql_query($query7) && mysql_query($query8) && mysql_query($query9) && 
											mysql_query($query10) && mysql_query($query3)) {
											echo "<p class='text-black2 text-center'>Registro borrado exitosamente</p>";
										}
										else {
											echo "<p class='text-black2 text-center'>La operación no tuvo éxito<br>Vuelva a intentarlo</p>";
										}
									}
									
								}
							?>

							<hr>
							<form name="form1" action="estudiantesautorizados.php" method="post" onsubmit="return validar()">
								<div class="row top-margin">
									<div class="col-sm-6">
										<label class="etiqueta-numcontrol-verinfoestudiante">Número de control <span class="text-danger">*</span> </label>
										<input type="text" name="NumControl" maxlength="8" onkeypress="return soloNumeros(event);" value="<?php echo $fila['NumControl'];?>" class="form-control-numcontrolverinfoestudiante">
									</div>
									<div class="row">
										<div class="col-lg-4 text-right">
											<button class="btn btn-danger boton-buscarestudiante" type="submit" name="ver_info_estudiante">Ver información</button>
										</div>
										<div class="row">
											<div class="col-lg-4 text-right">
												<button class="btn btn-default boton-limpiar" type="submit" name="limpiar" onclick="limpiar()">Limpiar</button>
											</div>
										</div>
									</div>
								</div>
								<br>
								<p class="text-muted text-center">
									Introduce un número de control y da clic en el botón<br>
									para mostrar la información del estudiante
								</p>
								<hr>
								<div class="top-margin">
									<label>Número de control</label>
									<input type="text" name="NumControl2" value="<?php echo $fila['NumControl'];?>" class="form-control-numcontrol2" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Nombre</label>
									<input type="text" name="Nombre" value="<?php echo $nombre_replace;?>" class="form-control-nombreestudiante" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Apellidos</label>
									<input type="text" name="Apellidos" value="<?php echo $apellidos_replace;?>" class="form-control-apellidos" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Correo electrónico</label>
									<input type="text" name="CorreoElectronico" value="<?php echo $correo_electronico_replace;?>" class="form-control-correo" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Carrera</label>
									<input type="text" name="Carrera" value="<?php echo $carrera_replace;?>" class="form-control-carrera" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Reticula</label>
									<input type="text" name="Reticula" id="reticula" value="<?php echo $reticula_replace;?>" class="form-control-reticula" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Opción de titulación</label>
									<input type="text" name="OpcionDeTitulacion" id="opciondetitulacion" value="<?php echo $opcion_titulacion_replace;?>" class="form-control-opciontitulacion" readonly="readonly">
								</div>
								<div class="top-margin">
									<label>Nombre del proyecto</label>
									<textarea name="Proyecto" cols="55" rows="5" class="form-control-proyecto" readonly="readonly"><?php echo $proyecto_replace;?></textarea>
								</div>
								<hr>
								<p class="text-black text-center">Si desea asignar fecha, hora y lugar para la ceremonia de<br>titulación del estudiante seleccione la opción <strong>"Hacer<br>asignaciones"</strong> y de clic en el botón<br><strong>"Guardar cambios"</strong></p>
								<br>
								<div class="top-margin modificar-procesotitulacion">
									<label>Hacer asignaciones</label>
									<input type="checkbox" name="ModificarProceso" id="ModificarProceso" value="true" class="centrar-checks8" onclick="habilitar()">
								</div>
								
								<hr>
								<p class="text-muted text-center">Proporcione fecha y lugar de titulación<br>para el estudiante</p>
								<div class="row top-margin">
									<div class="col-sm-6">
										<label>Fecha de titulación</label>
										<input type="text" name="FechaDeTitulacion" id="FechaDeTitulacion" value="<?php echo $fila['FechaDeTitulacion'];?>" class="form-control-fechatitulacion" onkeydown="return fecha(event);" placeholder="aaaa-mm-dd hh:mm" disabled>
									</div>
									<div class="col-sm-6">
										<label class='formato-fecha'>Formato de fecha: aaaa-mm-dd hh:mm</label>
									</div>
								</div>
								<div class="top-margin">
									<label>Lugar de la ceremonía de titulación</label>
									<textarea name="LugarDeCeremoniaDeTitulacion" id="LugarDeCeremoniaDeTitulacion" cols="40" rows="2" class="form-control-lugartitulacion" disabled><?php echo $lugar_titulacion_replace;?></textarea>
								</div>
								<br>
								<div class="row top-margin">
									<div class="col-lg-4 boton-guardarcambiosprofe">
										<button class="btn btn-default" type="submit" name="guardar_cambios" onclick="validar2()">Guardar cambios</button>
									</div>
									<div class="col-lg-4 boton-borrarprofesor">
										<button class="btn btn-danger" type="submit" name="borrar_estudiante">Borrar estudiante</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</article>
			<!-- /Article -->
		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">
		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
				<br>
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								ALGUNOS DERECHOS RESERVADOS &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
