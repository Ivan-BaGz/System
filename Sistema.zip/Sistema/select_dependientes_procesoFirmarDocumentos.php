<?php

include 'funciones.php';

// Array que vincula los IDs de los selects declarados en el HTML con el nombre de la tabla donde se encuentra su contenido
$listadoSelects=array(
"puestos"=>"puestos",
"Estudiantes"=>"Estudiante"
);

function validaSelect($selectDestino)
{
	// Se valida que el select enviado via GET exista
	global $listadoSelects;
	if(isset($listadoSelects[$selectDestino])) return true;
	else return false;
}

function validaOpcion($opcionSeleccionada)
{
	// Se valida que la opcion seleccionada por el usuario en el select tenga un valor de cadena de texto
	if(is_string($opcionSeleccionada)) return true;
	else return false;
}

$selectDestino=$_GET["select"]; $opcionSeleccionada=$_GET["opcion"];

if(validaSelect($selectDestino) && validaOpcion($opcionSeleccionada))
{
	session_name("loginUsuario");
	session_start();			
	
	$id_sinodal = $_SESSION["id"];	
	
	if( $opcionSeleccionada != "admons" ) 
	{	
	
	$consulta = "SELECT Nombre,Apellidos ,Estudiante.IdEstudiante FROM AsignacionDeSinodal,Estudiante WHERE AsignacionDeSinodal.$opcionSeleccionada = '$id_sinodal' AND Estudiante.IdEstudiante=AsignacionDeSinodal.IdEstudiante";																		
	$resultado = conexionMysql($consulta);
	
	if( mysql_num_rows($resultado) ) 
	{			
	echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
 		while( $fila = mysql_fetch_assoc($resultado)) 
		{
			echo "<option value=".$fila['IdEstudiante'].">"; echo $fila['Nombre']." ".$fila['Apellidos']; echo "</option>";
		}
	echo "</SELECT>";
	//echo '<input type="submit" name="enviar_datos" id="enviar_datos" value="FIRMAR" class="form-control btn-action "/>';
	}
	else 
	{
		echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
		echo "<option value='0'>No hay alumnos asignados</option>";
		echo "</SELECT>";
	}	
	
	}
	else 
	{
		$consulta = "SELECT * from Administrador";																		
		$resultado = conexionMysql($consulta);
		
		if( mysql_num_rows($resultado) ) 
		{			
			echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
 				echo "<option value='admon1'>".mysql_result($resultado,0,'Nombre')."(Administrador)</option>";
 				echo "<option value='admon2'>".mysql_result($resultado,1,'Nombre')."(Coordinacion titulación)</option>";
			echo "</SELECT>";
			//echo '<input type="submit" name="enviar_datos" id="enviar_datos" value="FIRMAR" class="form-control btn-action "/>';
		}
	}

	
					
}
?>