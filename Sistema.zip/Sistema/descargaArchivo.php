
<?php
	
$doc = $_GET['doc'];

    $basefichero = basename("documentos/$doc");
    header( "Content-Type: application/octet-stream");
    header( "Content-Length: ".filesize("documentos/$doc"));
    header( "Content-Disposition: attachment; filename=".$basefichero."");
    readfile("documentos/$doc");
	
?>