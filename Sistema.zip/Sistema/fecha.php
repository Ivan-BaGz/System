<?php

include'funciones.php';

	function fecha()
	{
		$consulta = "SELECT DATE_FORMAT(FechaDeTitulacion,'%d') as dia from Estudiante where IdEstudiante = 1";
		$resultado = conexionMysql($consulta);
		$dia = mysql_result($resultado,0,'dia');
	
		$consulta = "SELECT DATE_FORMAT(FechaDeTitulacion,'%m') as mes from Estudiante where IdEstudiante = 1";
		$resultado = conexionMysql($consulta);
		$m= mysql_result($resultado,0,'mes');
		
		if( $m == 1)
			$mes = "Enero";
		else if( $m == 2)
			$mes = "Febrero";
		else if( $m == 3)
			$mes = "Marzo";
		else if( $m == 4)
			$mes = "Abril";
		else if( $m == 5)
			$mes = "Mayo";
		else if( $m == 6)
			$mes = "Junio";
		else if( $m == 7)
			$mes = "Julio";
		else if( $m == 8)
			$mes = "Agosto";
		else if( $m == 9)
			$mes = "Septiembre";
		else if( $m == 10)
			$mes = "Octubre";
		else if( $m == 11)
			$mes = "Noviembre";
		else if( $m == 12)
			$mes = "Diciembre";
			
		return $fecha = $dia." de ".$mes;
	}
	
	echo fecha();

?>
