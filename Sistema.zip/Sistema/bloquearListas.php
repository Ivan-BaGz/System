<html>
<head>
 
 <script type="text/javascript">
 
	function mostrarInfo(id){
			
			if (window.XMLHttpRequest)
			{// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
			}
			else
			{// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function()
			{
			if (xmlhttp.readyState==4 && xmlhttp.status==200)
			{
			document.getElementById("datos").innerHTML=xmlhttp.responseText;
			}else{
			document.getElementById("datos").innerHTML='Cargando...';
			}
			}
			xmlhttp.open("POST","procesaBloqueo.php",true);
			xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
			xmlhttp.send("id="+id);
			
			} 
  
  function Block(esto,id)
   {
    if(esto.checked==true)
     {
		id=document.getElementById(id);
		id.disabled=false;		
	 }	
	else
	 {
		id=document.getElementById(id);
		id.disabled=true;				
	 }
   }
 </script>
</head>
<body>

<select name='alumnos' id='alumnos' onchange='mostrarInfo(this.value)' style='width:300;'>
<option value='0'>Selecciona un alumno</option>
<option value='1'>Osvaldo</option>
</select>


<div id="datos">
	<input type="checkbox" id="txek" onclick="Block(this,'Aukera')"/>
<select id="Aukera">
 <option value="1">Uno</option>
 <option value="2">Dos</option>
</select>
</div>

</body>
</html> 