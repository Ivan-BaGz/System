<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Asignar | sinodal</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8" />	
		
		<style tyep="text/css">
		div.mensaje
    	{
    		position:absolute; top:1px; left:230px;
			width: 300px;
			padding: 5px;
			border: solid 2px red;;
			color: red;	
		}	
		</style>
		
	</head>
	
	<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="#"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Egresados <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="estudiantesregistrados.php">Egresados registrados</a></li>
							<li><a href="asignarSinodal.php">Asignar Revisores</a></li>
							<li><a href="listaAlumnos.php">Crear Documentos</a></li>
							<li><a href="cambioJurado.php">Cambio de jurado</a></li>
							<li><a href="cambioTema.php">Cambio de tema de tesis</a></li>
							<li><a href="bitacora2.php">Bitácora</a></li>
							</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Profesores <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="consultarFirmas.php">Firmas Registradas</a></li>							
							<li><a href="profesoresregistrados.php">Profesores registrados</a></li>
							<li><a href="firmasOficina.php">Firmas de liberacion</a></li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrador<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="modificacionesAdministrador.php">Modificaciones</a></li>
							<li><a href="actualizarPlantillas.php">Actualizar plantillas</a></li>
							<li><a href="archivosSubidos.php">Ver plantillas actualizadas</a></li>
							<li><a href="descomprimeZip.php">Descomprimir archivos ZIP</a></li>
						</ul>
					</li>
					
					<?php
					include "funciones.php";
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAdministrador where visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					?>
					<li class="active3"><a class="btn" href="verMensajesAdmon.php"><?php echo $mensajes ?> Mensaje(s)</a></li>
					<?php
					}
					else
						echo '<li class="active"><a class="btn" href="verMensajesAdmon.php">Mensajeria</a></li>';
					?>
				
					<li class="active"><a class="btn" href="perfiladministrador.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Administrador</a></li>
			<li class="active">Asignar sinodal</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Asignar revisores</h1>
				</header>
				
				<div class="col-md-8 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">				
		<?php
		function replace($cadena) {
			$cadena = str_replace("&AACUTE;", "Á", $cadena);
			$cadena = str_replace("&EACUTE;", "É", $cadena);
			$cadena = str_replace("&IACUTE;", "Í", $cadena);
			$cadena = str_replace("&OACUTE;", "Ó", $cadena);
			$cadena = str_replace("&UACUTE;", "Ú", $cadena);
			$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
			$cadena = str_replace("&aacute;", "á", $cadena);
			$cadena = str_replace("&eacute;", "é", $cadena);
			$cadena = str_replace("&iacute;", "í", $cadena);
			$cadena = str_replace("&oacute;", "ó", $cadena);
			$cadena = str_replace("&uacute;", "ú", $cadena);
			$cadena = str_replace("&ntilde;", "ñ", $cadena);
			return $cadena;
		}
		error_reporting( E_WARNING | E_ERROR );		
		
		echo "<form action='asignarSinodal.php' method='post' />";
			
			openConectionMysql();			
			
			//Formular la consulta
			$consulta = sprintf("SELECT Nombre,Apellidos,IdEstudiante FROM Estudiante");
			$resultado =conexionMysql($consulta);
			//comprobar la conexion
			if($resultado) {
			
			echo "<br>";
			echo "<br>";
			echo "<br>";
			echo "<br>";
			echo "<br>";
			
			echo "<center>";
			
			echo "<label>SELECCIONA UN ALUMNO PARA ASIGNAR SINODAL</label>";
			echo "<select name='alumnos_encontrados' class='form-control' style='width:300;'>";		
			while($fila = mysql_fetch_assoc($resultado))
			{
				$id= $fila['IdEstudiante'];
				
				$consulta = sprintf("select IdEstudiante from AsignacionDeSinodal WHERE IdEstudiante = $id");
				$comprobarSinodal = conexionMysql($consulta); 				
				
				if( mysql_num_rows($comprobarSinodal) == 0 ) 
				{
					echo "<option value=$id ";
					if( $_POST["alumnos_encontrados"] == $id )
					{	 
					echo "selected='selected'"; 
					}
					echo ">";
					echo replace($fila['Nombre'])." ".replace($fila['Apellidos']);
					echo "</option>";
				}
			}
			echo "</select>";
			echo "<br />";
			}
		
			else {
				echo "<div class='mensaje'>";
				echo "Error";
				echo "</div>";	
				
		}
		//LISTAS DE SINODALES
		
		//ASIGNACION DE PRESIDENTE
		echo "<label>PRESIDENTE</label>";
		echo "<select name='presidente' class='form-control' style='width:300;'>";
			//Formular la consulta
			$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor");
			$resultado =conexionMysql($consulta);
			while($fila = mysql_fetch_assoc($resultado))
			{
				$id= $fila['IdProfesor'];
				echo "<option value=$id ";if($_POST["presidente"]==$id){echo"selected='selected'";}echo">";echo replace($fila['Nombre'])." ".replace($fila['Apellidos']);echo"</option>";
			}
		echo "</select>";							
		echo "<br />";
		
		//ASIGNACION DE SECRETARIO
		echo "<label>SECRETARIO</label>";
		echo "<select name='secretario' class='form-control' style='width:300;'>";
			//Formular la consulta
			$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor");
			$resultado =conexionMysql($consulta);
			while($fila = mysql_fetch_assoc($resultado))
			{
				$id= $fila['IdProfesor'];
				echo "<option value=$id ";if($_POST["secretario"]==$id){echo"selected='selected'";}echo">";echo replace($fila['Nombre'])." ".replace($fila['Apellidos']);echo"</option>";
			}
		echo "</select>";							
		echo "<br />";
		
		//ASIGNACION DE VOCAL
		echo "<label>VOCAL</label>";
		echo "<select name='vocal' class='form-control' style='width:300;'>";
			//Formular la consulta
			$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor");
			$resultado =conexionMysql($consulta);
			while($fila = mysql_fetch_assoc($resultado))
			{
				$id= $fila['IdProfesor'];
				echo "<option value=$id ";if($_POST["vocal"]==$id){echo"selected='selected'";}echo">";echo replace($fila['Nombre'])." ".replace($fila['Apellidos']);echo"</option>";
			}
		echo "</select>";							
		echo "<br />";
		
		//ASIGNACION DE SUPLENTE
		echo "<label>SUPLENTE</label>";
		echo "<select name='suplente' class='form-control' style='width:300;'>";
			//Formular la consulta
			$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor");
			$resultado =conexionMysql($consulta);
			while($fila = mysql_fetch_assoc($resultado))
			{
				$id= $fila['IdProfesor'];
				echo "<option value=$id ";if($_POST["suplente"]==$id){echo"selected='selected'";}echo">";echo replace($fila['Nombre'])." ".replace($fila['Apellidos']);echo"</option>";
			}
		echo "</select>";							
		echo "<br />";
		
		//ASIGNACION DE SUPLENTE1
		echo "<label>SUPLENTE 1</label>";
		echo "<select name='suplente1' class='form-control' style='width:300;'>";
			//Formular la consulta
			$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor");
			$resultado =conexionMysql($consulta);
			while($fila = mysql_fetch_assoc($resultado))
			{
				$id= $fila['IdProfesor'];
				echo "<option value=$id ";if($_POST["suplente1"]==$id){echo"selected='selected'";}echo">";echo replace($fila['Nombre'])." ".replace($fila['Apellidos']);echo"</option>";
			}
		echo "</select>";							
		echo "<br />";
		
		//ASIGNACION DE SUPLENTE2	
		echo "<label>SUPLENTE 2</label>";
		echo "<select name='suplente2' class='form-control' style='width:300;'>";
			//Formular la consulta
			$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor");
			$resultado =conexionMysql($consulta);
			while($fila = mysql_fetch_assoc($resultado))
			{
				$id= $fila['IdProfesor'];
				echo "<option value=$id ";if($_POST["suplente2"]==$id){echo"selected='selected'";}echo">";echo replace($fila['Nombre'])." ".replace($fila['Apellidos']);echo"</option>";
			}
		echo "</select>";							
		echo "<br />";
		
		//ASIGNACION DE SUPLENTE3	
		echo "<label>SUPLENTE 3</label>";
		echo "<select name='suplente3' class='form-control' style='width:300;'>";
			//Formular la consulta
			$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor");
			$resultado =conexionMysql($consulta);
			while($fila = mysql_fetch_assoc($resultado))
			{
				$id= $fila['IdProfesor'];
				echo "<option value=$id ";if($_POST["suplente3"]==$id){echo"selected='selected'";}echo">";echo replace($fila['Nombre'])." ".replace($fila['Apellidos']);echo"</option>";
			}
		echo "</select>";							
		echo "<br />";
		
		echo "<center>";
		echo "<input type='submit' name='asignar_sinodal' value='Asignar' class='btn btn-danger' />";
		 
		echo "</form>";
		
		//si el formulario ha sido enviado procesa los datos enviados
		if (isset($_POST['asignar_sinodal'])) 
		{
			//se obtiene el 'id' del alumno seleccionado
			$id_alumno=$_POST['alumnos_encontrados'];					
			
			$id_presidente=$_POST['presidente'];
			$id_secretario=$_POST['secretario'];
			$id_vocal=$_POST['vocal'];
			$id_suplente=$_POST['suplente'];
			$id_suplente1 = $_POST['suplente1'];
			$id_suplente2 = $_POST['suplente2'];
			$id_suplente3 = $_POST['suplente3'];
			
 			if( $id_alumno > 0 && $id_presidente > 0 && $id_secretario > 0 &&	$id_vocal > 0 &&	$id_suplente > 0 && $id_suplente1 > 0 && $id_suplente2 > 0 && $id_suplente3 > 0 ) 
			{ 		
				
				$consulta = sprintf("SELECT IdEstudiante FROM AsignacionDeSinodal WHERE IdEstudiante = $id_alumno");
				$resultado = conexionMysql($consulta);			
				
				//COMPROBAR SI YA SE HA ASIGNADO REVISORES AL ALUMNO
				if( mysql_num_rows($resultado) > 0 )
				{
					
					echo "<div class='mensaje'>";
						echo "<p class='text-black3 text-center'>Ya se han asignado revisores a este alumno</p>";
					echo "</div>";
				}
				else 
				{	
					//COMPROBAR QUE NO SEAN LOS MISMOS PROFESORES PARA LOS PUESTOS
					
					$revisores = array( $id_presidente,$id_secretario,$id_vocal,$id_suplente,$id_suplente1,$id_suplente2,$id_suplente3 );
					$igual = false;					
															
					for( $i = 0 ; $i < count($revisores) ; $i++ ) 
					{
						for( $j = 1 ; $j < count($revisores) ; $j++ ) 
						{
							if( $i != $j ) 
							{
								if( $revisores[$i] == $revisores[$j] )
								{
									//echo $i. "," . $j;
									  $igual = true;
									//echo "<br/>";
								}
							} 
						}
					} 					
					
					if( $igual == true ) 
					{
						echo "<div class='mensaje'>";
							echo "<p class='text-black3 text-center'>Hay profesores repetidos en la asignación<br>Vuelve a intentarlo</p>";
						echo "</div>";
					}
					else 
					{
						$insertar = sprintf("insert into AsignacionDeSinodal (IdEstudiante,Presidente,Secretario,Vocal,Suplente,Suplente1,Suplente2,Suplente3) values ('$id_alumno','$id_presidente','$id_secretario','$id_vocal','$id_suplente','$id_suplente1','$id_suplente2','$id_suplente3')");
						
						$aprobPresidente = sprintf("insert into firmarAutorizaciones(IdProfesor,IdEstudiante,
AprobacionRegistro,AprobacionTrabajo)values('$id_presidente','$id_alumno',false,false)"); 
						$aprobSecretario = sprintf("insert into firmarAutorizaciones(IdProfesor,IdEstudiante,
AprobacionRegistro,AprobacionTrabajo)values('$id_secretario','$id_alumno',false,false)");
						$aprobVocal = sprintf("insert into firmarAutorizaciones(IdProfesor,IdEstudiante,
AprobacionRegistro,AprobacionTrabajo)values('$id_vocal','$id_alumno',false,false)");
						$aprobSuplente = sprintf("insert into firmarAutorizaciones(IdProfesor,IdEstudiante,
AprobacionRegistro,AprobacionTrabajo)values('$id_suplente','$id_alumno',false,false)");
					//se llama a la función para procesar la inserción
					conexionMysql($insertar);
					conexionMysql($aprobPresidente);
					conexionMysql($aprobSecretario);
					conexionMysql($aprobVocal);
					conexionMysql($aprobSuplente);
					
					//enviar un mensaje al alumno notificando su asignación de sinodales
					$fecha_hora = date("Y-m-d H:i:s");
					$mensaje = 'Ingresa a tu proceso de titulación para que conozcas tus sinodales asignados.';
					$asunto = 'YA SE TE HAN ASIGNADO SINODALES';					
					//notificar al alumno
					$notificacion = sprintf("INSERT INTO MensajesAlumno(IdAdmon,IdEstudiante,mensaje,asunto,visto,fechaHora)values(1,'$id_alumno','$mensaje','$asunto',false,'$fecha_hora')");
					mysql_query($notificacion);
					
					//enviar un mensaje a los profesores de su asignacin de alumno
					$fecha_hora = date("Y-m-d H:i:s");
					$mensaje = 'Ingresa a Firmar documentos para aprobar documentos de tus alumnos asignados.';
					$asunto = 'YA SE TE HAN ASIGNADO ALUMNOS';					
					
					//notificar al presidente
					$notificacion = sprintf("INSERT INTO MensajesProfesor(IdProfesor,IdAdmon,mensaje,asunto,visto,fechaHora)values('$id_presidente',1,'$mensaje','$asunto',false,'$fecha_hora')");
					mysql_query($notificacion);
					//notificar al secretario
					$notificacion = sprintf("INSERT INTO MensajesProfesor(IdProfesor,IdAdmon,mensaje,asunto,visto,fechaHora)values('$id_secretario',1,'$mensaje','$asunto',false,'$fecha_hora')");
					mysql_query($notificacion);
					//notificar al vocal
					$notificacion = sprintf("INSERT INTO MensajesProfesor(IdProfesor,IdAdmon,mensaje,asunto,visto,fechaHora)values('$id_vocal',1,'$mensaje','$asunto',false,'$fecha_hora')");
					mysql_query($notificacion);
					//notificar al suplente
					$notificacion = sprintf("INSERT INTO MensajesProfesor(IdProfesor,IdAdmon,mensaje,asunto,visto,fechaHora)values('$id_suplente',1,'$mensaje','$asunto',false,'$fecha_hora')");
					mysql_query($notificacion);
					
					//$insertar = sprintf("insert into alumnos (sinodal) values ('$id_alumno')");
					echo "<div class='mensaje'>";
					echo "<p class='text-black3 text-center'>Asignación exitosa</p>";
					echo "</div>";
					}					
				}
			}
			else 
			{
				echo "<div class='mensaje'>";
					echo "<p class='text-black3 text-center'>Aun no hay alumnos o sinodales registrados</p>";
				echo "</div>";
			}						
		}
							
?>								  
	</div>
			</div>
				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
