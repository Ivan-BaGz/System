<?php
	$var = get_magic_quotes_gpc();
	echo get_magic_quotes_gpc();
?>