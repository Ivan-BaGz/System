<?php include 'seguridadestudiante.php'; ?>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Datos | alumno</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
	<script src="md5.js"></script>
	<script type="text/javascript">
		function soloNumeros(e) {
			var entrada = window.event ? window.event.keyCode : e.which;
			if (entrada == 8 || entrada == 9) 
				return true;

			return /\d/.test(String.fromCharCode(entrada));
		}
		function soloLetras(e) {
    		tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==32) { // espacio
				return true; 
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[a-zA-Z]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function correoElectronico(e) {
			tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==190) { //punto
				return true;
			}
			if (tecla==32) { // espacio
				return false; 
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==189) { // -
				return true;
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (e.shiftKey && tecla==189) {
				return true;
			}
			if (e.shiftKey && tecla==49 || e.shiftKey && tecla==50 || e.shiftKey && tecla==51 || 
				e.shiftKey && tecla==52 || e.shiftKey && tecla==53 || e.shiftKey && tecla==54 || 
				e.shiftKey && tecla==55 || e.shiftKey && tecla==56 || e.shiftKey && tecla==57 || 
				e.shiftKey && tecla==48 || e.shiftKey && tecla==186 || e.shiftKey && tecla==187 || 
				e.shiftKey && tecla==191 || e.shiftKey && tecla==192 || e.shiftKey && tecla==219 || 
				e.shiftKey && tecla==220 || e.shiftKey && tecla==221 || e.shiftKey && tecla==222) {
				return false;
			}
			if (tecla==187 || tecla==188 || tecla==191 || tecla==192 || tecla==219 || tecla==220 || tecla==221 || tecla==222) {
				return false;
			}
			if (e.altGraphKey && tecla==81) { // @
				return true;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[0-9a-zA-Z\W]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function claveDeAcceso(e) {
			tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==190) { //punto
				return false;
			}
			if (tecla==32) { // espacio
				return false; 
			}
			if (tecla==60) { // <
				return false;
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==189) { // guión
				return true;
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (tecla==0) { // ¿
				return false;
			}
			if (e.shiftKey && tecla==49 /* ! */ || e.shiftKey && tecla==50 /* "" */ ||  
				e.shiftKey && tecla==54 /* & */ || e.shiftKey && tecla==55 /* / */ || 
				e.shiftKey && tecla==56 /* ( */ || e.shiftKey && tecla==57 /* ) */ || 
				e.shiftKey && tecla==48 /* = */ || e.shiftKey && tecla==186 /* ; */ || 
				e.shiftKey && tecla==191 /* ? */ || e.shiftKey && tecla==192 /* ¨ */ || 
				e.shiftKey && tecla==219 /* [ */ || e.shiftKey && tecla==220 /* | */ || 
				e.shiftKey && tecla==221 /* ] */ || e.shiftKey && tecla==222 /* '' */ || 
				e.shiftKey && tecla==187 /* * */ || e.shiftKey && tecla==60 /* > */ ||
				e.shiftKey && tecla==0 /* ¡ */ || e.shiftKey && tecla==171 /* * */ ||
				e.shiftKey && tecla==174 /* [ */ || e.shiftKey && tecla==175 /* ] */) {
				return false;
			} 
			if (e.shiftKey && tecla==51 /* # */ || e.shiftKey && tecla==52 /* $ */ ||
				e.shiftKey && tecla==53 /* % */ || e.shiftKey && tecla==189 /* _ */ ) {
				return true;
			}
			if (tecla==187 || tecla==188 || tecla==191 || tecla==192 || tecla==219 || tecla==220 || 
				tecla==221 || tecla==222 || tecla==171 /* + */ || tecla==174 /* { */ || tecla==175 /* } */) {
				return false;
			}
			if (e.altGraphKey && tecla==81) { // @
				return true;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[0-9a-zA-Z\W]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function validar(form1) {
			if (document.form1.HacerCorrecciones.checked != true && document.form1.ModificarClaveDeAcceso.checked != true) {
				alert("Imposible guardar cambios. No se ha habilitado la opción 'Modificar datos' o la opción 'Modificar contraseña'");
				return false;
			}
			else {
				if (document.form1.HacerCorrecciones.checked == true) {
					if (document.form1.NumControl.value=="") {
						alert("Tienes campos vacíos");
						return false;
					}
					else if (document.form1.Nombre.value=="") {
							alert("Tienes campos vacíos");
							return false;
							}
					else if (document.form1.Apellidos.value=="") {
							alert("Tienes campos vacíos");
							return false;
							}
					else if (document.form1.Direccion.value=="") {
							alert("Tienes campos vacíos");
							return false;
							}
					else if (document.form1.TelefonoCelular.value=="" && document.form1.TelefonoDeCasa.value=="") {
							alert("Tienes campos vacíos");
							return false;
							}
					else if (document.form1.CorreoElectronico.value=="") {
							alert("Tienes campos vacíos");
							return false;
							}
						else {
							//SE VALIDA CORREO ELECTRÓNICO
							var correo = document.form1.CorreoElectronico.value;
							expr = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
							//expr = /^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,3})$/;
    						if ( !expr.test(correo) ) {
        						alert("Error: La dirección de correo " + correo + " es incorrecta.");
        						return false;
        					}
						}
				}
				if (document.form1.ModificarClaveDeAcceso.checked == true) {
					if (document.form1.ClaveDeAccesoActual.value == "" || document.form1.ClaveDeAccesoNueva.value == "") {
						alert("Imposible guardar. Tiene campos vacíos");
						return false;
					}
					else {
						//SE VALIDA LA CONTRASEÑA
						var cadena = document.form1.ClaveDeAccesoNueva.value;
						var numcaracteres = cadena.length;
						var espacio = " ";
						if (cadena.indexOf(espacio) > -1) {
							alert("La contraseña no debe contener espacios en blanco");
							return false;
						}
						else {
							if (numcaracteres < 8) {
								alert("La contraseña es corta");
								return false;
							}
							else {
								if (!(cadena.match(/\d/))) {
     								alert("La contraseña debe contener al menos un número");
     								return false;
								}
								if (!(cadena.match(/\W+/))) {
									alert("La contraseña debe de contener al menos un caracter especial");
									return false;
								}
								var md5_clave_actual = hex_md5(document.form1.ClaveDeAccesoActual.value);
								document.form1.ClaveDeAccesoActual.value = md5_clave_actual;
								var md5_clave_nueva = hex_md5(document.form1.ClaveDeAccesoNueva.value);
								document.form1.ClaveDeAccesoNueva.value = md5_clave_nueva;
							}
						}
					}
				}
			}
		}
		function habilitar() {
			document.form1.NumControl.disabled=!document.form1.NumControl.disabled;
			document.form1.Nombre.disabled=!document.form1.Nombre.disabled;
			document.form1.Apellidos.disabled=!document.form1.Apellidos.disabled;
			document.form1.Direccion.disabled=!document.form1.Direccion.disabled;
			document.form1.TelefonoCelular.disabled=!document.form1.TelefonoCelular.disabled;
			document.form1.TelefonoDeCasa.disabled=!document.form1.TelefonoDeCasa.disabled;
			document.form1.CorreoElectronico.disabled=!document.form1.CorreoElectronico.disabled;
			}
		function habilitar2() {
			document.form1.ClaveDeAccesoActual.disabled=!document.form1.ClaveDeAccesoActual.disabled;
			document.form1.ClaveDeAccesoNueva.disabled=!document.form1.ClaveDeAccesoNueva.disabled;
		}
	</script>
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="#"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">	
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Tu información <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="datosPersonalesEstudiante.php">Información personal</a></li>
							<li><a href="datosEscolaresEstudiante.php">Información general</a></li>
						</ul>
					</li>
					<li><a href="procesoTitulacionEstudiante.php">Proceso de titulación</a></li>
					<?php
					include "funciones.php";
					
					session_name('loginUsuario');
					session_start();
					
					$id = $_SESSION["id"];					
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAlumno where IdEstudiante = $id and visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');

					$consulta2 = "select HacerCorrecciones,DatosCorregidos from Estudiante where IdEstudiante = $id";
					$resultado2 = conexionMysql($consulta2);
					$hacerCorrecciones = mysql_result($resultado2, 0, 'HacerCorrecciones');
					$datosCorregidos = mysql_result($resultado2, 0, 'DatosCorregidos');

					if( $mensajes > 0 ) {
				
					?>

					<li class='active3'><a class='btn' href='verMensajesAlumno.php'><?php echo $mensajes ?> Mensaje(s)</a></li>
		            <?php
					}
					else {
						echo "<li class='active'><a class='btn' href='verMensajesAlumno.php'>Mensajeria</a></li>";
					}
					if ($hacerCorrecciones == 1 && $datosCorregidos == "no") {
						echo "<li class='active2'><a class='btn' href=''>Corrige tus datos</a></li>";
					}
					?>
					<li class="active"><a class="btn" href="perfilestudiante.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Información personal del egresado</h1>
				</header>
				<?php
					echo "<IFRAME NAME='observaciones_profesor' SRC='tablaObservacionesEstudiante.php' 
					WIDTH='540' HEIGHT='80' FRAMEBORDER='1' MARGINWIDTH='3' MARGINHEIGHT='3' SCROLLING='Auto' 
					class='tabla-observacionesprofesor text-alert'></IFRAME>";
				?>
				<br><br>
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Información</h3>
							<br>
							<?php
								function replace($cadena) {
									$cadena = str_replace("&AACUTE;", "Á", $cadena);
									$cadena = str_replace("&EACUTE;", "É", $cadena);
									$cadena = str_replace("&IACUTE;", "Í", $cadena);
									$cadena = str_replace("&OACUTE;", "Ó", $cadena);
									$cadena = str_replace("&UACUTE;", "Ú", $cadena);
									$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
									$cadena = str_replace("&aacute;", "á", $cadena);
									$cadena = str_replace("&eacute;", "é", $cadena);
									$cadena = str_replace("&iacute;", "í", $cadena);
									$cadena = str_replace("&oacute;", "ó", $cadena);
									$cadena = str_replace("&uacute;", "ú", $cadena);
									$cadena = str_replace("&ntilde;", "ñ", $cadena);
									return $cadena;
								}
								session_name("loginUsuario");
								session_start();
								$numControl = $_SESSION["numcontrol"];
								$id = $_SESSION["id"];
								
								//$mysqli = new mysqli('localhost','root','samushomysql123');
								$mysqli = conexionMysqli();
								openConectionMysql();
								mysql_query("SET NAMES 'utf8'");
								$consulta = sprintf("SELECT * FROM Estudiante WHERE NumControl = $numControl");
								$resultado = mysql_query($consulta);
								$fila = mysql_fetch_assoc($resultado);

								$nombre_replace = $fila['Nombre'];
								$nombre_replace = replace($nombre_replace);
								$apellidos_replace = $fila['Apellidos'];
								$apellidos_replace = replace($apellidos_replace);
								$direccion_replace = $fila['Direccion'];
								$direccion_replace = replace($direccion_replace);
								$telefono_celular_replace = $fila['TelefonoCelular'];
								$telefono_celular_replace = replace($telefono_celular_replace);
								$telefono_de_casa_replace = $fila['TelefonoDeCasa'];
								$telefono_de_casa_replace = replace($telefono_de_casa_replace);
								$correo_electronico_replace = $fila['CorreoElectronico'];
								$correo_electronico_replace = replace($correo_electronico_replace);
								$proyecto_replace = $fila['Proyecto'];
								$proyecto_replace = replace($proyecto_replace);
								
								if (isset($_POST['guardar_cambios'])) {
									$hacer_correcciones = $_POST['HacerCorrecciones'];
									$modificar_clave = $_POST['ModificarClaveDeAcceso'];

									if ($hacer_correcciones == true) {
										if (empty($_POST['NumControl'])) {
											echo "<p class='text-center text-black2'>Tiene campos vacíos</p>";
											$error = true;
										}
										else {
											$num_control = $_POST['NumControl'];
										}
										if (empty($_POST['Nombre'])) {
											echo "<p class='text-center text-black2'>Tiene campos vacíos</p>";
											$error = true;
										}
										else {
											$nombre = $mysqli->real_escape_string(htmlspecialchars($_POST['Nombre']));
											$nombre = htmlentities($nombre);
											if (ctype_upper($nombre) != true) {
												$nombre = strtr(strtoupper($nombre),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
											}
										}
										if (empty($_POST['Apellidos'])) {
											echo "<p class='text-center text-black2'>Tiene campos vacíos</p>";
											$error = true;
										}
										else {
											$apellidos = $mysqli->real_escape_string(htmlspecialchars($_POST['Apellidos']));
											$apellidos = htmlentities($apellidos);
											if (ctype_upper($apellidos) != true) {
												$apellidos = strtr(strtoupper($apellidos),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
											}
										}
										if (empty($_POST['Direccion'])) {
											echo "<p class='text-center text-black2'>Tiene campos vacíos</p>";
											$error = true;
										}
										else {
											$direccion = $mysqli->real_escape_string(htmlspecialchars($_POST['Direccion']));
											$direccion = htmlentities($direccion);
											if (ctype_upper($direccion) != true) {
												$direccion = strtr(strtoupper($direccion),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
											}
										}
										if (empty($_POST['TelefonoCelular']) && empty($_POST['TelefonoDeCasa'])) {
											echo "<p class='text-center text-black2'>Proporciona al menos un número telefónico</p>";
											$error = true;
										}
										else {
											$telefono_celular = $mysqli->real_escape_string(htmlspecialchars($_POST['TelefonoCelular']));
											$telefono_celular = htmlentities($telefono_celular);
											$telefono_de_casa = $mysqli->real_escape_string(htmlspecialchars($_POST['TelefonoDeCasa']));
											$telefono_de_casa = htmlentities($telefono_de_casa);
										}
										if (empty($_POST['CorreoElectronico'])) {
											echo "<p class='text-center text-black2'>Tiene campos vacíos</p>";
											$error = true;
										}
										else {
											$correo_electronico = $mysqli->real_escape_string(htmlspecialchars($_POST['CorreoElectronico']));
											$correo_electronico = htmlentities($correo_electronico);
										}
										if ($error != true) {
											$datoscorregidos = "si";
											openConectionMysql();
											mysql_query("SET NAMES 'utf8'");
										
											$queryupdateDatosEstudiante = "UPDATE Estudiante SET NumControl = '$num_control',Nombre = '$nombre',
											Apellidos = '$apellidos', Direccion = '$direccion', TelefonoCelular = '$telefono_celular', 
											TelefonoDeCasa = '$telefono_de_casa', CorreoElectronico = '$correo_electronico',
											DatosCorregidos = '$datoscorregidos' WHERE NumControl = '$numControl'";

											if (mysql_query($queryupdateDatosEstudiante)) {
												echo "<p class='text-black2 text-center'>Datos guardados exitosamente</p>";
												//mysqli_free_result($queryupdateDatosEstudiante);
												//mysqli_close();
											}
											else {
												echo "<p class='text-black2 text-center'>Error al guardar<br>Vuelva a intentarlo</p>";
											}
										}
									}
									if ($modificar_clave == true) {
										if (empty($_POST['ClaveDeAccesoActual']) || empty($_POST['ClaveDeAccesoNueva'])) {
												echo "<p class='text-center text-black2'>Imposible guardar.<br>Tiene campos vacíos al actualizar contraseña</p>";
										}
										else {
											$clave_actual = $_POST['ClaveDeAccesoActual'];
											$clave_nueva = $_POST['ClaveDeAccesoNueva'];
											$consultaClaveAcceso = "SELECT ClaveDeAcceso FROM Estudiante WHERE NumControl = '$numControl' AND IdEstudiante = '$id'";
											$resultadoClaveAcceso = conexionMysql($consultaClaveAcceso);
											$clave = mysql_result($resultadoClaveAcceso,0,'ClaveDeAcceso');

											if (strcmp($clave_actual, $clave) != 0) {
												$error = true;
												echo "<p class='text-center text-black2'>La contraseña actual no es correcta</p>";
											}
											else {
												if (strcmp($clave_actual, $clave_nueva) == 0) {
													$error = true;
													echo "<p class='text-center text-black2'>No puedes proporcionar la misma contraseña</p>";
												}
												else {
													if ($error != true) {
														openConectionMysql();
														mysql_query("SET NAMES 'utf8'");
														$queryUpdateClave = "UPDATE Estudiante SET ClaveDeAcceso = '$clave_nueva' WHERE IdEstudiante = '$id' AND ClaveDeAcceso = '$clave'";
														if (mysql_query($queryUpdateClave)) {
															echo "<p class='text-center text-black2'>Se ha modificado correctamente la contraseña</p>";
														}
														else {
															echo "<p class='text-center text-black2'>Error al guardar<br>Vuelva a intentarlo</p>";
														}
													}
												}
											}
										}
									}
								}
							?>
							
							<hr>
							<form name="form1" action="datosPersonalesEstudiante.php" method="post" onsubmit="return validar()">
								<div class="top-margin">
									<label>Número de control</label>
									<input type="text" name="NumControl" value="<?php echo $fila['NumControl'];?>" 
									onkeypress="return soloNumeros(event);" class="form-control-numcontrol2" disabled>
								</div>
								<div class="top-margin">
									<label>Nombre</label>
									<input type="text" name="Nombre" value="<?php echo $nombre_replace;?>" 
									onkeypress="return soloLetras(event);" class="form-control-nombreestudiante" disabled>
								</div>
								<div class="top-margin">
									<label>Apellidos</label>
									<input type="text" name="Apellidos" value="<?php echo $apellidos_replace;?>" 
									onkeypress="return soloLetras(event);" class="form-control-apellidos" disabled>
								</div>
								<div class="top-margin">
									<label>Dirección</label>
									<input type="text" name="Direccion" value="<?php echo $direccion_replace;?>" 
									class="form-control-direccion" disabled>
								</div>
								<div class="row top-margin">
									<div class="col-sm-6">
										<label class="centrar">Telefono celular</label>
										<input type="text" name="TelefonoCelular" value="<?php echo $telefono_celular_replace;?>" 
										onkeypress="return soloNumeros(event);" class="form-control-telcelular centrar" disabled>
									</div>
									<div class="col-sm-6">
										<label class="ajustar-telcasa">Telefono de casa</label>
										<input type="text" name="TelefonoDeCasa" value="<?php echo $telefono_de_casa_replace;?>" 
										onkeypress="return soloNumeros(event);" class="form-control-telcasa ajustar-telcasa" disabled>
									</div>
								</div>
								<div class="top-margin">
									<label>Correo electrónico</label>
									<input type="text" name="CorreoElectronico" value="<?php echo $correo_electronico_replace;?>" 
									onkeydown="return correoElectronico(event);" class="form-control-correo" disabled>
								</div>
								<br>
								<br>
								<p class="text-muted text-center">Si desea modificar su información habilite la opción <strong>"Modificar datos"</strong></p>
								
								<div class="top-margin centrar-checks">
									<label>Modificar datos</label>
									<input type="checkbox" name="HacerCorrecciones" id="HacerCorrecciones" 
									value="true" class="checks" onclick="habilitar()">
								</div>
								<hr>
								<h3 class="thin text-center">Contraseña</h3>
								<br>
								<p class="text-center text-muted">Si desea cambiar la contraseña seleccione la opción<br><strong>"Modificar contraseña"</strong>, después proporcione<br>la contraseña actual y la nueva y de clic<br><strong>en "Guardar cambios"</strong></p>
								<br>
								<div class="top-margin centrar-checks3">
									<label>Modificar contraseña</label>
										<input type="checkbox" name="ModificarClaveDeAcceso" id="ModificarClaveDeAcceso" value="1" onclick="habilitar2()" class="checks centrar-checks3">
								</div>
								<br>
								<div class="row top-margin">
									<div class="col-sm-6">
										<label class="etiqueta-claveacceso-actual">Contraseña actual <span class="text-danger">*</span></label>
										<input type="password" name="ClaveDeAccesoActual" value="" class="form-control-claveaccesoadmin-actual" onkeydown="return claveDeAcceso(event);" disabled>
									</div>
									<div class="col-sm-6">
										<label class="etiqueta-claveacceso-nueva">Contraseña nueva <span class="text-danger">*</span></label>
										<input type="password" name="ClaveDeAccesoNueva" value="" class="form-control-claveaccesoadmin-nueva" onkeydown="return claveDeAcceso(event);" disabled>
									</div>
								</div>
								<hr>
								<div class="row top-margin">
									<div class="col-lg-4 boton-borrarprofesor">
										<button class="btn btn-danger boton-guardarcambiosestudiante" type="submit" name="guardar_cambios">GUARDAR CAMBIOS</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</article>
			<!-- /Article -->
		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">
		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
				<br>
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								ALGUNOS DERECHOS RESERVADOS &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
