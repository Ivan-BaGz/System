<?php

	include "funciones.php";
	
	echo "<link rel='stylesheet' href='/bootstrap.min.css'>";
	echo "<link rel='stylesheet' href='/font-awesome.min.css'>";
	echo "<link rel='stylesheet' href='/bootstrap-theme.css' media='screen' >";
	echo "<link rel='stylesheet' href='/main.css'>"; 

	function replace($cadena) {
		$cadena = str_replace("&AACUTE;", "Á", $cadena);
		$cadena = str_replace("&EACUTE;", "É", $cadena);
		$cadena = str_replace("&IACUTE;", "Í", $cadena);
		$cadena = str_replace("&OACUTE;", "Ó", $cadena);
		$cadena = str_replace("&UACUTE;", "Ú", $cadena);
		$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
		$cadena = str_replace("&aacute;", "á", $cadena);
		$cadena = str_replace("&eacute;", "é", $cadena);
		$cadena = str_replace("&iacute;", "í", $cadena);
		$cadena = str_replace("&oacute;", "ó", $cadena);
		$cadena = str_replace("&uacute;", "ú", $cadena);
		$cadena = str_replace("&ntilde;", "ñ", $cadena);
		return $cadena;
	}
	//tabla que muestra los alumnos registrados

	//conexion a mysql
	openConectionMysql();
	
	//CONSULTA
	$consulta = sprintf("SELECT * FROM Profesor");
	
	//EJECUTAR LA CONSULTA
	$resultado = mysql_query($consulta);
	
	//COMPROBAR LA CONSULTA
	if(!$resultado)
	{
		$mensaje = "CONSULTA NO VALIDA ".mysql_error(). "<br />";
		$mensaje.= "CONSULTA COMPLETA ".$consulta;
		die($mensaje);
	}		
	
	//TABLA A MOSTRAR DE ALUMNOS
	echo "<table border width='740'>";
	echo "<tr>";
		echo "<th class='thin idprofesor text-center'>"; echo "Id"; echo "</th>";
		echo "<th class='thin numtargeta text-center'>"; echo "Cédula"; echo "</th>";
		echo "<th class='thin nombreprofesor text-center'>"; echo "Nombre"; echo "</th>";
		echo "<th class='thin apellidosprofesor text-center'>"; echo "Apellidos"; echo "</th>";
		echo "<th class='thin corregirdatosprofe text-center'>";  echo "Corregir datos"; echo "</th>";
		echo "<th class='thin datoscorregidosprofesor text-center'>";  echo "Datos corregidos"; echo "</th>";
	echo "</tr>";
	
		while($fila = mysql_fetch_assoc($resultado)) 
		{
			
			echo "<tr>";
				  echo "<td class='text-muted text-center'>"; echo $fila['IdProfesor']; echo "</td>";
				  echo "<td class='text-muted text-center'>"; echo $fila['Cedula']; echo "</td>";
				  echo "<td class='text-muted'>"; echo replace($fila['Nombre']); echo "</td>";
				  echo "<td class='text-muted'>"; echo replace($fila['Apellidos']); echo "</td>";
				  echo "<td class='text-black text-center'>"; if($fila['HacerCorrecciones'] == false) {echo "No";} else {echo "Si";} echo "</td>";
				  echo "<td class='text-black text-center'>"; if($fila['HacerCorrecciones'] == false) {
				  									echo "";
				  									}
				  								else {
				  									if ($fila['HacerCorrecciones'] != false && $fila['DatosCorregidos'] == "no") {
				  										echo "No corregidos";
				  									}
				  									else {
				  										if ($fila['HacerCorrecciones'] != false && $fila['DatosCorregidos'] == "si") {
				  											echo "Corregidos";
				  										}
				  									}
				  								} echo "</td>";
			echo "</tr>";
		}
	echo "</table>";
?>
