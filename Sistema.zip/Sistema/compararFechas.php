<?php
	function compararFechas($primera, $segunda) {
      $valoresPrimera = explode ("/", $primera);   
      $valoresSegunda = explode ("/", $segunda); 
    $anyoPrimera   = $valoresPrimera[0];
      $mesPrimera  = $valoresPrimera[1]; 
      $diaPrimera    = $valoresPrimera[2];  
   
      $anyoSegunda  = $valoresSegunda[0];
      $mesSegunda = $valoresSegunda[1];  
      $diaSegunda   = $valoresSegunda[2];  

      $diasPrimeraJuliano = gregoriantojd($mesPrimera, $diaPrimera, $anyoPrimera);  
      $diasSegundaJuliano = gregoriantojd($mesSegunda, $diaSegunda, $anyoSegunda);     

      if(!checkdate($mesPrimera, $diaPrimera, $anyoPrimera)){
        echo "La fecha ".$primera." no es válida";
        return 0;
      } elseif(!checkdate($mesSegunda, $diaSegunda, $anyoSegunda)){
          echo "La fecha ".$segunda." no es válida";
          return 0;
          } else {
            return $diasPrimeraJuliano - $diasSegundaJuliano;
            } 
  }

$primera = "2016/03/01";
$segunda = "2016/02/28";

//echo compararFechas ($primera,$segunda);
// 2015-3-22 17:58:56
$ayer = "2015-3-21 17:58:56";
$ahora = date("Y-n-j H:i:s");
$horaYMedia = strtotime($ahora) + 5400;
echo $ahora,"  ";
echo strtotime($ahora),"  ";
echo $horaYMedia,"  ";
echo strtotime($ayer);
?>