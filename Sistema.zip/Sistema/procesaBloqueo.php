<?php

include "funciones.php";

error_reporting( E_ERROR | E_WARNING );


echo $bloqueo = $_POST['id'];
$idAlumno = 1;

	//$idAlumno = $_POST['id'];
	
	function generaProfesores($sinodal,$puesto,$block) 
	{
		echo "<select name='$puesto' id='$puesto' class='form-control' style='width:300;' ";
		if( !strcmp($block, $puesto) ) 
		{
			echo "disabled='disabled'";
		}
		echo  ">";
			//Formular la consulta
			$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor");
			$resultado =conexionMysql($consulta);
			while($fila = mysql_fetch_assoc($resultado))
			{
				$id= $fila['IdProfesor'];
				echo "<option value=$id ";if($sinodal == $id){echo"selected='selected'";}echo">";echo$fila['Nombre']." ".$fila['Apellidos'];echo"</option>";
			}
		echo "</select>";
	}	
	
	function obtenerSinodal($id,$campo)
	{
		$consulta = "select $campo from AsignacionDeSinodal WHERE AsignacionDeSinodal.IdEstudiante = $id;";
		$resultado = conexionMysql($consulta);
	
		if( mysql_num_rows($resultado) > 0 ) 
		{	
			return mysql_result($resultado,0,$campo); 
		}
	}	
	
	if( $idAlumno > 0 ) 
	{
		$presidente = obtenerSinodal($idAlumno,'Presidente');
		$secretario = obtenerSinodal($idAlumno,'Secretario');
		$vocal = obtenerSinodal($idAlumno,'Vocal');
		$suplente = obtenerSinodal($idAlumno,'Suplente'); 
		echo "<form action='cambioJurado.php' method='post'>";
		echo "<label>JURADO ACTUAL</label>";
		echo "<table border>";
			echo "<tr>";
				echo "<td><br></td>"; 
				echo "<th>"; echo "NOMBRE"; echo "</th>";
			echo "</tr>";
					
			echo "<tr>";
				echo "<td>"; echo" <input type='checkbox' name='presi' id='presi' value='presidente' onclick='Block()'> "; echo "</td>"; 
				echo "<th>"; echo "PRESIDENTE"; echo "</th>";
				echo "<td>"; generaProfesores($presidente,'presidente',$bloqueo);echo "</td>";				
			echo "</tr>";
			
			echo "<tr>"; echo "<th>";  echo "SECRETARIO"; echo "</th>";
				echo "<td>"; generaProfesores($secretario,'secretario',$bloqueo); echo "</td>";
			echo "</tr>";
			
			echo "<tr>"; 
				echo "<th>";  echo "VOCAL"; echo "</th>";
				echo "<td>"; generaProfesores($vocal,'vocal',$bloqueo); echo "</td>";
			echo "</tr>";
			
			echo "<tr>"; 
				echo "<th>"; echo "SUPLENTE"; echo "</th>";
				echo "<td>"; generaProfesores($suplente,'suplente',$bloqueo); echo "</td>";
				echo "</tr>";		
		echo "</table>"; echo "<br>";
		
		echo "<input type='submit' name='cambio_jurado' value='CAMBIO JURADO' class='btn btn-action' />";
		 
		echo "</form>";
		 
	}
	else 
	{
		echo "<label>Selecciona un alumno.</label>";
	}
	
	
	
?>