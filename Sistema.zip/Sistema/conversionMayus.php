<?php
	$cadena = "HOLA";
	$cadena2 = "evAluAcIón";
	if (ctype_upper($cadena2) == true) {
		echo "todas mayusculas\n";
	}
	else {
		echo "no todas mayusculas\n";
		//$cadena2 = strtoupper($cadena2);
		$salida = strtr(strtoupper($cadena2),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
	}
	echo "Cadena de entrada: ",$cadena2,"\n";
	echo "Cadena de salida: ",$salida;
?>