<?php

	$selectDestino=$_GET["select"]; 
	$opcionSeleccionada=$_GET["opcion"];
			 
		/**************************************************************************************
		*****************   OPCIONES DE TITULACIÓN RETICULA ISIC-2010-224   *******************
		**************************************************************************************/
										
		if( $opcionSeleccionada == "ISIC-2010-224" ) 
		{
				// Comienzo a imprimir el select
			echo "<label>Opción de titulación</label>";
			echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
				echo "<option value='(INFORME TÉCNICO DE RESIDENCIA PROFESIONAL)'>"; echo "INFORME TÉCNICO DE RESIDENCIA PROFESIONAL"; echo "</option>";
				echo "<option value='(PROYECTO DE INNOVACIÓN TECNOLÓGICA)'>"; echo "PROYECTO DE INNOVACIÓN TECNOLÓGICA"; echo "</option>";
				echo "<option value='(PROYECTO DE INVESTIGACIÓN)'>"; echo "PROYECTO DE INVESTIGACIÓN"; echo "</option>";
			   echo "<option value='(INFORME DE ESTANCIA)'>"; echo "INFORME DE ESTANCIA"; echo "</option>";
				echo "<option value='(TESIS)'>"; echo "TESIS"; echo "</option>";
				echo "<option value='(TESINA)'>"; echo "TESINA"; echo "</option>";
			echo "</select>";				
		}
		
		/**************************************************************************************
		***********************   OPCIONES DE TITULACIÓN RETICULA ISIC-2004-296  **************
		**************************************************************************************/
						
		elseif( $opcionSeleccionada == "ISIC-2004-296" ) 
		{
			// Comienzo a imprimir el select
			echo "<label>Opción de titulación</label>";
			echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
				echo "<option value='I (TESIS PROFESIONAL)'>"; echo "I. TESIS PROFESIONAL."; echo "</option>";
				echo "<option value='II (LIBROS DE TEXTO O PROTOTIPOS DIDÁCTICOS)'>"; echo "II. LIBROS DE TEXTO O PROTOTIPOS DIDÁCTICOS."; echo "</option>";
				echo "<option value='III (PROYECTO DE INVESTIGACIÓN)'>"; echo "III. PROYECTO DE INVESTIGACIÓN."; echo "</option>";
				echo "<option value='IV (DISEÑO O REDISEÑO DE EQUIPO, APARATO O MAQUINARIA)'>"; echo "IV. DISEÑO O REDISEÑO DE EQUIPO, APARATO O MAQUINARIA."; echo "</option>";
				echo "<option value='V (CURSOS ESPECIALES DE TITULACIÓN)'>"; echo "V. CURSOS ESPECIALES DE TITULACIÓN."; echo "</option>";
				echo "<option value='VI (EXAMEN GLOBAL POR ÁREAS DEL CONOCIMIENTO)'>"; echo "VI. EXAMEN GLOBAL POR ÁREAS DEL CONOCIMIENTO."; echo "</option>";
				echo "<option value='VII (MEMORIA DE EXPERIENCIA PROFESIONAL)'>"; echo " VII. MEMORIA DE EXPERIENCIA PROFESIONAL."; echo "</option>";
				echo "<option value='VIII (ESCOLARIDAD POR PROMEDIO)'>"; echo "VIII. ESCOLARIDAD POR PROMEDIO."; echo "</option>";
				echo "<option value='IX (ESCOLARIRAD POR ESTUDIOS DE POSGRADO)'>"; echo "IX. ESCOLARIRAD POR ESTUDIOS DE POSGRADO."; echo "</option>";
				echo "<option value='X (INFORME DE RESIDENCIA PROFESIONAL)'>"; echo "X. INFORME DE RESIDENCIA PROFESIONAL."; echo "</option>";
			echo "</select>";			
		}
		
		/***************************************************************************************************
		********************************   OPCIONES DE TITULACIÓN RETICULA ISIC-1993-296  ******************
		****************************************************************************************************/
						
		elseif( $opcionSeleccionada == "ISIC-1993-296" ) 
		{
			// Comienzo a imprimir el select
			echo "<label>Opción de titulación</label>";
			echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
				echo "<option value='I (TESIS PROFESIONAL)'>"; echo "I. TESIS PROFESIONAL."; echo "</option>";
				echo "<option value='II (LIBROS DE TEXTO O PROTOTIPOS DIDÁCTICOS)'>"; echo "II. LIBROS DE TEXTO O PROTOTIPOS DIDÁCTICOS."; echo "</option>";
				echo "<option value='III (PROYECTO DE INVESTIGACIÓN)'>"; echo "III. PROYECTO DE INVESTIGACIÓN."; echo "</option>";
				echo "<option value='IV (DISEÑO O REDISEÑO DE EQUIPO, APARATO O MAQUINARIA)'>"; echo "IV. DISEÑO O REDISEÑO DE EQUIPO, APARATO O MAQUINARIA."; echo "</option>";
				echo "<option value='V (CURSOS ESPECIALES DE TITULACIÓN)'>"; echo "V. CURSOS ESPECIALES DE TITULACIÓN."; echo "</option>";
				echo "<option value='VI (EXAMEN GLOBAL POR ÁREAS DEL CONOCIMIENTO)'>"; echo "VI. EXAMEN GLOBAL POR ÁREAS DEL CONOCIMIENTO."; echo "</option>";
				echo "<option value='VII (MEMORIA DE EXPERIENCIA PROFESIONAL)'>"; echo " VII. MEMORIA DE EXPERIENCIA PROFESIONAL."; echo "</option>";
				echo "<option value='VIII (ESCOLARIDAD POR PROMEDIO)'>"; echo "VIII. ESCOLARIDAD POR PROMEDIO."; echo "</option>";
				echo "<option value='IX (ESCOLARIRAD POR ESTUDIOS DE POSGRADO)'>"; echo "IX. ESCOLARIRAD POR ESTUDIOS DE POSGRADO."; echo "</option>";
				echo "<option value='X (INFORME DE RESIDENCIA PROFESIONAL)'>"; echo "X. INFORME DE RESIDENCIA PROFESIONAL."; echo "</option>";
			echo "</select>";				
		}
?>
