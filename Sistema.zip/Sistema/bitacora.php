
<?php
include 'funciones.php';

function replace($cadena) {
	$cadena = str_replace("&AACUTE;", "Á", $cadena);
	$cadena = str_replace("&EACUTE;", "É", $cadena);
	$cadena = str_replace("&IACUTE;", "Í", $cadena);
	$cadena = str_replace("&OACUTE;", "Ó", $cadena);
	$cadena = str_replace("&UACUTE;", "Ú", $cadena);
	$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
	$cadena = str_replace("&aacute;", "á", $cadena);
	$cadena = str_replace("&eacute;", "é", $cadena);
	$cadena = str_replace("&iacute;", "í", $cadena);
	$cadena = str_replace("&oacute;", "ó", $cadena);
	$cadena = str_replace("&uacute;", "ú", $cadena);
	$cadena = str_replace("&ntilde;", "ñ", $cadena);
	return $cadena;
}
	
if( isset($_POST['actualizar_datos'])) 
{
	$id = $_POST['id'];	
	$portada = $_POST['portada'];
	$observaciones = $_POST['observaciones'];
	$trabajo_enviado = $_POST['trabajo_enviado'];
	$Liberacion_asigJurado = $_POST['liberacion_asigJurado'];
	$AutorizacionDeImpresion = $_POST['AutorizacionDeImpresion'];	
	
	$update = sprintf("update Estudiante set Observaciones_bitacora='$observaciones',Portada_bitacora= $portada ,Trabajo_enviado_bitacora= $trabajo_enviado ,Liberacion_asigJurado_bitacora= $Liberacion_asigJurado ,LiberacionDeProyectoTitulacionIntegral = $AutorizacionDeImpresion ,AutorizacionDeImpresion= $AutorizacionDeImpresion  where IdEstudiante = $id");
	openConectionMysql();
	mysql_query($update);
}					
?>

<html lang="es">
<head>

	<!--hoja de estilo para un iframe-->
	
	<style type="text/css">
			#iframe
    	{
    		overflow:auto;
    		width:890px;
    		height:250px;
    	}
    	
    	div.mensaje
    	{
    		position:absolute; top:10px; left:30px;
			width: 1080px;
			padding: 5px;
			border: solid 4px red;;
			color: red;		
    	}
	</style>
	<script type="text/javascript">
			
		function validaForm()
		{	
			//
			if( document.getElementById('motivo').value.length > 0  )
			{
				var expresion = /^[a-zñáéíóú]*(\s*[a-zñáéíóú]*)*[a-zñáéíóú]*$/i;
				//var expresion = /^([a-z ñáéíóú]{2,60})$/i;
				var campo = document.getElementById('motivo').value;
				if( !expresion.test(campo) )
				{
					alert('Contiene caracteres no validos.');
					document.cambio.motivo.focus();
					return false;
				}
			}
			else
			{
				alert('El campo motivo esta vacio.');
				document.cambio.motivo.focus();
				return false;
			}
			
			return true;			
		}

	</script>
	
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Alumnos Bitácora</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
		  	
			
			</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Estudiantes <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="estudiantesregistrados.php">Estudiantes registrados</a></li>
							<li><a href="asignarSinodal.php">Asignar Revisores</a></li>
							<li><a href="listaAlumnos.php">Crear Documentos</a></li>
							<li><a href="cambioJurado.php">Cambio de jurado</a></li>
							<li><a href="cambioTema.php">Cambio de tema de tesis</a></li>
							<li><a href="bitacora2.php">Bitácora</a></li>
							</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Profesores <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="consultarFirmas.php">Firmas Registradas</a></li>							
							<li><a href="profesoresregistrados.php">Profesores registrados</a></li>
							<li><a href="firmasOficina.php">Firmas de liberacion</a></li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrador<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="modificacionesAdministrador.php">Modificaciones</a></li>
							<li><a href="actualizarPlantillas.php">Actualizar plantillas</a></li>
							<li><a href="archivosSubidos.php">Ver plantillas actualizadas</a></li>
							<li><a href="descomprimeZip.php">Descomprimir archivos ZIP</a></li>
						</ul>
					</li>
					
					<?php
					//include "funciones.php";
					
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAdministrador where visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					?>
					<li class="active3"><a class="btn" href="verMensajesAdmon.php"><?php echo $mensajes ?> Mensaje(s)</a></li>
					<?php
					}
					else
						echo '<li class="active"><a class="btn" href="verMensajesAdmon.php">Mensajeria</a></li>';
					?>
				
					<li class="active"><a class="btn" href="perfiladministrador.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Administrador</a></li>
			<li class="active">Alumnos Bitácora</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Alumnos Bitácora</h1>
				</header>
				
				<div class="col-md-10 col-md-offset-1 col-sm-10 col-sm-offset-10">
					<div class="panel panel-default">
						<div class="panel-body">
	
		<form action='bitacora.php' method='post' />
		<div id="iframe">	
			<table border="" cellpadding="10" cellspacing="10">
			
				<tr bgcolor="#d0e7ff">
					<!--Nombre-->
					<td><label>Nombre y correo</label></td>
					<!--//Matricula-->
					<td><label>Matrícula</label></td>
					<!--Fecha de registro-->
					<td><label>Fecha de registro</label></td>
					<!--Plan de estudios-->
					<td><label>Plan de estudios</label></td>
					<!--Opción-->
					<td><label>Opción</label></td>
					<!--Asignación de jurado-->
					<td><label>Asignación de jurado</label></td>
					<!--Trabajo enviado-->
					<td><label>Trabajo enviado</label></td>
					<!--Asignación (Revisión).- Interno-->
					<td><label>Asignación (Revisión).- Interno</label></td>
					<!--Registro opción-->
					<td><label>Registro opción</label></td>
					<!--Portada-->
					<td><label>Portada</label></td>
					<!--Liberación y Asignación de Jurado.-->
					<td><label>Liberación y Asignación de Jurado.</label></td>
					<!--Autorización de impresión-->
					<td><label>Autorización de impresión</label></td>
					<!--Observaciones-->
					<td><label>Observaciones</label></td>
				</tr>
				<tr>
					<!--Consulta a la base de datos-->
					<?php
					//include 'funciones.php';
					
					//obtiene datos del alumno
					if( !empty($_GET['IdE']) ) 
						$id = $_GET['IdE'];
					if( !empty($_POST['id']) )
						$id = $_POST['id'];
					
					$consulta = sprintf("select IdEstudiante,Nombre,Apellidos,NumControl,Reticula,CorreoElectronico,ProyectoAutorizado,FechaDeRegistro,FechaDeAutorizacion,FechaDeTitulacion,OpcionDeTitulacion,
Aprobado,AutorizacionDeRegistroTrabajoTitulacion,AutorizacionDeImpresion,LiberacionDeProyectoTitulacionIntegral,FechaYHoraDeRegistro,Observaciones_bitacora,
Portada_bitacora,Trabajo_enviado_bitacora,Liberacion_asigJurado_bitacora from Estudiante WHERE IdEstudiante = $id");
					$resultado = conexionMysql($consulta);
					
					
					//campo oculto para el ID
					echo '<input type="hidden" name="id" id="id" value="'. $id . '"';
					
					//obtiene datos del alumno
										
					while( $fila = mysql_fetch_assoc($resultado) ) 
					{//inicio del ciclo
					
					//consultar si tiene asignado jurado
					$idE = $fila['IdEstudiante'];
					$consulta = sprintf("select * from AsignacionDeSinodal where IdEstudiante = $idE");
					$result = conexionMysql($consulta);
					if( mysql_num_rows($result) > 0 )
						$jurado = true;
					else
						$jurado = false;
					?>
												
					<tr>
						<!--Nombre-->
						<td><label><?php echo replace($fila['Nombre']) .' '. replace($fila['Apellidos']).' '.$fila['CorreoElectronico']; ?></label></td>
						<!--//Matricula-->
						<td><label><?php echo $fila['NumControl']; ?></label></td>
						<!--Fecha de registro-->
						<td><label><?php echo $fila['FechaYHoraDeRegistro']; ?></label></td>
						<!--Plan de estudios-->
						<td><label><?php echo $fila['Reticula']; ?></label></td>
						<!--Opción-->
						<td><label><?php echo replace($fila['OpcionDeTitulacion']); ?></label></td>
						<!--Asignación de jurado-->
						<td>
						<label>
						<?php 
						if( $jurado == true )
							echo "SI";
						else
						echo "NO";
						?>
						</label>
						</td>
						<!--Trabajo enviado-->
						<td>
						<?php
							if( $fila['Trabajo_enviado_bitacora'] == true )
							{
								echo '<label>Si&nbsp</label><input type="radio" checked="checked" name="trabajo_enviado" id="trabajo_enviado" value="true" /><br>';
						 		echo '<label>No</label><input type="radio" name="trabajo_enviado" id="trabajo_enviado" value="false" />'; 
							}//fin if portada 
							if( $fila['Trabajo_enviado_bitacora'] == false )
							{
								echo '<label>Si&nbsp</label><input type="radio" name="trabajo_enviado" id="trabajo_enviado" value="true" /><br>';
						 		echo '<label>No</label><input type="radio" checked="checked" name="trabajo_enviado" id="trabajo_enviado" value="false" />';
						 	}//fin if portada
						 ?>	
						</td>
						<!--Asignación (Revisión).- Interno-->
						<td>&#160</td>
						<!--Registro opción-->
						<td>
						<label>
						<?php
						 if( $fila['AutorizacionDeRegistroTrabajoTitulacion'] == true )
						 	echo "SI";
						 else 
						 	echo "NO"; 
						?>
						</label>
						</td>
						<!--Portada-->
						<td>
						<?php
						if( $fila['Portada_bitacora'] == true )
						{
							echo '<label>Si&nbsp</label><input type="radio" checked="checked" name="portada" id="portada" value="true" /><br>';
						 	echo '<label>No</label><input type="radio" name="portada" id="portada" value="false" />';		
						}
						if( $fila['Portada_bitacora'] == false )
						{
							echo '<label>Si&nbsp</label><input type="radio" name="portada" id="portada" value="true" /><br>';
						 	echo '<label>No</label><input type="radio" checked="checked" name="portada" id="portada" value="false" />';
						}
						?>
						</td>
						<!--Liberación y Asignación de Jurado.-->
						<td>
						<?php
							if( $fila['Liberacion_asigJurado_bitacora'] == true )
							{
								echo '<label>Si&nbsp</label><input type="radio" checked="checked" name="liberacion_asigJurado" id="liberacion_asigJurado" value="true" /><br>';
						 		echo '<label>No</label><input type="radio" name="liberacion_asigJurado" id="liberacion_asigJurado" value="false" />'; 
							}//fin if portada 
							if( $fila['Liberacion_asigJurado_bitacora'] == false )
							{
								echo '<label>Si&nbsp</label><input type="radio" name="liberacion_asigJurado" id="liberacion_asigJurado" value="true" /><br>';
						 		echo '<label>No</label><input type="radio" checked="checked" name="liberacion_asigJurado" id="liberacion_asigJurado" value="false" />';
						 	}//fin if portada
						 ?>
						</td>
						<!--Autorización de impresión-->
						<td>
						<?php
							if( $fila['AutorizacionDeImpresion'] == true )
							{
								echo '<label>Si&nbsp</label><input type="radio" checked="checked" name="AutorizacionDeImpresion" id="AutorizacionDeImpresion" value="true" /><br>';
						 		echo '<label>No</label><input type="radio" name="AutorizacionDeImpresion" id="AutorizacionDeImpresion" value="false" />'; 
							}//fin if portada 
							if( $fila['AutorizacionDeImpresion'] == false )
							{
								echo '<label>Si&nbsp</label><input type="radio" name="AutorizacionDeImpresion" id="AutorizacionDeImpresion" value="true" /><br>';
						 		echo '<label>No</label><input type="radio" checked="checked" name="AutorizacionDeImpresion" id="AutorizacionDeImpresion" value="false" />';
						 	}//fin if portada
						?>
						</td>
						<!--Observaciones-->
						<td>
						<?php
						if( $fila['Observaciones_bitacora'] == null )
							echo '<input type="text" name="observaciones" id="observaciones" />';
						else
							echo '<input type="text" name="observaciones" id="observaciones" value="'. $fila['Observaciones_bitacora'] . '"/>';
						?>  
						</td>
				</tr>
				<?php
				} //fin del ciclo while() 
				?>
			</table>
		</div>
		<br>
		<center>
		<input type="submit" name="actualizar_datos" value="Actualizar datos" class="btn btn-danger" />
		</center>
		</form>	
</div>
					</div>
				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>