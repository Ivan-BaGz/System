<?php 
	include 'funciones.php';

	$cedula = $_POST['Cedula'];

	if ($cedula == "") {
		header("Location: ingresoCedula.php?vacio=si");
	}
	else {
		openConectionMysql();
		$sentencia = "SELECT * FROM Profesor WHERE Cedula = '$cedula'";
		$res = mysql_query($sentencia);
		if (mysql_num_rows($res)>0) {
			$num_targeta = mysql_result($res, 0, 'NumTargeta');
			if ($num_targeta != 000) {
				header("Location: ingresoprofesor.php");
			}
			else {
				header("Location: registroNumTargeta.php?var=$cedula");
			}
		}
		else {
			header("Location: ingresoCedula.php?error=si");
		}
	}
	mysqli_free_result($res);
	mysqli_close();
?>