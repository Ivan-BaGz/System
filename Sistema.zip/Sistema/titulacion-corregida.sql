drop database Titulacion;
create database Titulacion;
use Titulacion;

create table Estudiante(
IdEstudiante int not null auto_increment,
Nombre varchar(25), 
Apellidos varchar(45),
Sexo varchar(15), 
NumControl int(8) zerofill, 
Carrera varchar(56), 
Reticula varchar(13), 
Direccion varchar(80), 
TelefonoCelular varchar(10), 
TelefonoDeCasa varchar(10), 
CorreoElectronico varchar(50), 
Proyecto varchar(200), 
ProyectoAutorizado bool,
FechaDeRegistro date,
FechaDeAutorizacion date, 
FechaDeTitulacion datetime, 
OpcionDeTitulacion varchar(55), 
Aprobado bool, 
AutorizacionDeRegistroTrabajoTitulacion bool, 
AutorizacionDeImpresion bool,
LiberacionDeProyectoTitulacionIntegral bool,
Observaciones bool,
LugarDeCeremoniaDeTitulacion varchar(80),
ClaveDeAcceso varchar(100),
FechaYHoraDeRegistro datetime,
UltimoAcceso datetime,
HacerCorrecciones bool,
DatosCorregidos varchar(2),
Observaciones_bitacora varchar(300),
Portada_bitacora bool default false,
Trabajo_enviado_bitacora bool default false,
Liberacion_asigJurado_bitacora bool default false,
primary key(IdEstudiante)
);

create table Carrera(
IdCarrera int not null auto_increment,
Carrera varchar(61),
primary key(IdCarrera));

create table Reticula(
IdReticula int not null auto_increment,
Reticula varchar(13),
primary key(IdReticula));

create table OpcionDeTitulacion(
IdOpcion int not null auto_increment,
Opcion varchar(55),
primary key(IdOpcion));

create table Profesor(
IdProfesor int not null auto_increment,
Nombre varchar(25),
Apellidos varchar(45),
Sexo varchar(15), 
NumTargeta int(3) zerofill,
Cedula varchar(7),
SiglasNivelAcademico varchar(20), 
NivelAcademico varchar(100),
CorreoElectronico varchar(50), 
Departamento varchar(60), 
FirmaD varchar(200),
ClaveDeAcceso varchar(100),
FechaYHoraDeRegistro datetime,
UltimoAcceso datetime,
HacerCorrecciones bool,
DatosCorregidos varchar(2),
primary key(IdProfesor));

create table Proyecto(
IdProyecto int not null auto_increment,
Nombre varchar(200),
NumeroDeEstudiantes int(1),
NombreDeEstudiantes varchar(430),
primary key(IdProyecto));

create table AsignacionDeSinodal(
IdAsignacionDeSinodal int not null auto_increment,
IdEstudiante int not null,
Presidente int not null,
Secretario int not null,
Vocal int not null,
Suplente int not null,
Suplente1 int not null,
Suplente2 int not null,
Suplente3 int not null,
primary key(IdAsignacionDeSinodal),
foreign key(IdEstudiante) references Estudiante(IdEstudiante),
foreign key(Presidente) references Profesor(IdProfesor),
foreign key(Secretario) references Profesor(IdProfesor),
foreign key(Vocal) references Profesor(IdProfesor),
foreign key(Suplente) references Profesor(IdProfesor),
foreign key(Suplente1) references Profesor(IdProfesor),
foreign key(Suplente2) references Profesor(IdProfesor),
foreign key(Suplente3) references Profesor(IdProfesor)
);

create table tempAsignacionDeSinodal(
IdTemp int not null auto_increment,
Presidente int not null,
Secretario int not null,
Vocal int not null,
Suplente int not null,
primary key(IdTemp)
);

create table cambioJurado(
IdCambioJurado int not null auto_increment,
IdEstudiante int not null,
Presidente int not null,
Secretario int not null,
Vocal int not null,
Suplente int not null,
motivo varchar(200),
fecha_hora datetime,
primary key(IdCambioJurado),
foreign key(IdEstudiante) references Estudiante(IdEstudiante),
foreign key(Presidente) references Profesor(IdProfesor),
foreign key(Secretario) references Profesor(IdProfesor),
foreign key(Vocal) references Profesor(IdProfesor),
foreign key(Suplente) references Profesor(IdProfesor)
);

create table Administrador(
IdAdministrador int not null auto_increment,
Nombre varchar(70),
Apellidos varchar(120),
Sexo varchar(15),
ClaveDeAcceso varchar(100),
primary key(IdAdministrador));

create table firmarAutorizaciones(
IdFirma int not null auto_increment,
IdProfesor int not null,
IdEstudiante int not null,
AprobacionRegistro bool,
AprobacionTrabajo bool,
FechaHoraAprobacionRegistro DATETIME,
FechaHoraAprobacionTrabajo DATETIME,
firmaLiberacionOficina bool default false,
primary key(IdFirma),
foreign key(IdProfesor) references Profesor(IdProfesor),
foreign key(IdEstudiante)references Estudiante(IdEstudiante)
);

create table MensajesAlumno(
IdMensaje int not null auto_increment,
IdProfesor int,
IdEstudiante int,
IdAdmon int,
IdCoordTitulacion int,
mensaje varchar(1000),
asunto varchar(200),
visto bool,
fechaHora datetime,
primary key(IdMensaje),
foreign key(IdProfesor) references Profesor(IdProfesor),
foreign key(IdEstudiante) references Estudiante(IdEstudiante),
foreign key(IdAdmon) references Administrador(IdAdministrador),
foreign key(IdCoordTitulacion) references Administrador(IdAdministrador)
);

create table MensajesProfesor(
IdMensaje int not null auto_increment,
IdProfesor int,
IdEstudiante int,
IdAdmon int,
IdCoordTitulacion int,
mensaje varchar(1000),
asunto varchar(200),
visto bool,
fechaHora datetime,
primary key(IdMensaje),
foreign key(IdProfesor) references Profesor(IdProfesor),
foreign key(IdEstudiante) references Estudiante(IdEstudiante),
foreign key(IdAdmon) references Administrador(IdAdministrador),
foreign key(IdCoordTitulacion) references Administrador(IdAdministrador)
);

create table MensajesAdministrador(
IdMensaje int not null auto_increment,
IdProfesor int,
IdEstudiante int,
IdAdmon int,
IdCoordTitulacion int,
mensaje varchar(1000),
asunto varchar(200),
visto bool,
fechaHora datetime,
primary key(IdMensaje),
foreign key(IdProfesor) references Profesor(IdProfesor),
foreign key(IdEstudiante) references Estudiante(IdEstudiante),
foreign key(IdAdmon) references Administrador(IdAdministrador),
foreign key(IdCoordTitulacion) references Administrador(IdAdministrador)
);

create table MensajesCoordTitulacion(
IdMensaje int not null auto_increment,
IdProfesor int,
IdEstudiante int,
IdAdmon int,
IdCoordTitulacion int,
mensaje varchar(1000),
asunto varchar(200),
visto bool,
fechaHora datetime,
primary key(IdMensaje),
foreign key(IdProfesor) references Profesor(IdProfesor),
foreign key(IdEstudiante) references Estudiante(IdEstudiante),
foreign key(IdAdmon) references Administrador(IdAdministrador),
foreign key(IdCoordTitulacion) references Administrador(IdAdministrador)
);

create table cambioTema(
IdCambioTema int not null auto_increment,
IdEstudiante int not null,
temaAnterior varchar(200),
nuevoTema varchar(200),
fecha_hora datetime,
primary key(IdCambioTema),
foreign key(IdEstudiante) references Estudiante(IdEstudiante)
);

create table notificaciones(
IdNotificacion int not null auto_increment,
IdEstudiante int not null,
notAprobReg bool,
notAprobTrab bool,
notRegSistema bool,
primary key(IdNotificacion),
foreign key(IdEstudiante) references Estudiante(IdEstudiante)
);

insert into Administrador(Nombre,Apellidos,ClaveDeAcceso)values('ALEJANDRA CALYPSO','SANTA OLALLA SALGADO','8c7604d2111af5b99cbb532be438974f');
insert into Administrador(Nombre,Apellidos,ClaveDeAcceso)values('MARÍA ISABEL','VÁSQUEZ OCAMPO','8c7604d2111af5b99cbb532be438974f');

insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Adriana Ivett','De la Roca Chiapas','femenino','','5774355','M.T.I.','Maestría en tecnologías de la información','',
'sistemas y computación','adb4ca9492c55c660de0cf17beef66d3','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Alejandra Calypso','Santa Olalla Salgado','femenino','','3242430','I.S.C.','Ingeniería en sistemas computacionales','','sistemas y computación','ca8e23da1d3191325c5ef1854a45c13e','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Alejandro','Morales Lizama','masculino','','1846373','L.I.','Licenciatura en informática','',
'sistemas y computación','5d8268fdfaf97ba97cd9ca423c367b66','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Ana Celia','Campos Hernández','femenino','','8536129','ING.','Ingeniería eléctrica','',
'sistemas y computación','53cbc3852304ab427890259035b33f3e','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Boris Antonio','Aranda Benítez','masculino','','5915824','M.C.','Maestría en ciencias de la computación','',
'sistemas y computación','d49f7aea67273db17f6fb3a8ad8c7e12','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Carlos','Estrada Abad','masculino','','1222475','ING.','Ingeniería en comunicaciones y electrónica','',
'sistemas y computación','f904190fd6569abbe7954e6dc8bd73f7','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Claudia Gabriela','Bustillos Gaytán','femenino','','4524274','M.T.I.','Maestría en tecnologías de la información','',
'sistemas y computación','d95bee733040eff8c86291f4006296a6','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Claudia','Noguerón González','femenino','','2767239','M.C.','Maestría en ciencias de la computación','',
'sistemas y computación','7bd7448664b7e44fd6fb9d0255c4e735','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Daniel','Mulato Agüero','masculino','','3071658','L.I.','Licenciatura en informática','',
'sistemas y computación','98575b5e7ec37402443de35b7181b4f2','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Enrique','López Duran','masculino','','4962695','M.T.I.','Maestría en tecnologías de la información','',
'sistemas y computación','6d4f2b658da6fa94166f12c420a3f48f','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Estela','Rodríguez Zavaleta','femenino','','2333868','L.I.','Licenciatura en informática','',
'sistemas y computación','3f89827ae34c52ba2916415e4d702f71','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Francisco Javier','Cartujano Escobar','masculino','','2620347','M.C.','Maestría en ciencias de la computación','',
'sistemas y computación','b131c0ce20da8ecbd96137c395fd9eb6','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Gonzalo','Rodríguez Mora','masculino','','2307287','L.I.','Licenciatura en informática','',
'sistemas y computación','82e2c9be996658fc32cc47986ed11a3a','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Héctor Guadalupe','Calderón Hernández','masculino','','3071657','I.S.C.','Ingeniería en sistemas computacionales','',
'sistemas y computación','8bf835a3367096454db2f56def8b78b6','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Héctor','Ordoñez Silva','masculino','','3608507','L.I.','Licenciatura en informática','',
'sistemas y computación','53494b401d9ba65458827de1645731b1','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Jairo','Avendaño Malvaez','masculino','','5583923','M.T.I.','Maestría en tecnologías de la información','',
'sistemas y computación','337fd88e3a031dea4d1b6f96f4d3f416','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Jarek Antonio','Tafolla Santana','masculino','','5826267','I.S.C.','Ingeniería en sistemas computacionales','',
'sistemas y computación','d9f5563ca42db4d546810f90d78cee3d','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Jesús Ángel','Peña Ramírez','masculino','','5502384','M.T.I.','Maestría en tecnologías de la información','',
'sistemas y computación','a206ce9e2be26e5a8bbe9ab8eec1413a','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('José Antonio','Velázquez Santana','masculino','','4524254','M.T.I.','Maestría en tecnologías de la información','',
'sistemas y computación','6bf2324b4b098f0870989673908c9675','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('José Francisco','Carpio Tovilla','masculino','','2746813','M.C.','Maestría en ciencias de la computación','',
'sistemas y computación','a1ac56c75d84a1c612a2438c21716625','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('José Luis','Pérez Estudillo','masculino','','3749622','I.S.C.','Ingeniería en sistemas computacionales','',
'sistemas y computación','5cdc3c46cf65f86d9a91ca50d311dc67','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('José Pedro','Aragón Hernández','masculino','','4067171','I.S.C.','Ingeniería en sistemas computacionales','',
'sistemas y computación','77c48b23b9b0f2bd17a822474ed8174c','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Josefina','Sámano Galindo','femenino','','6160941','DRA.','Doctorado en ciencias computacionales','',
'sistemas y computación','86a83b661d5d767bacd1a41f5f5d7d1c','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Laura','Villavicencio Gómez','femenino','','4872644','M.T.I.','Maestría en tecnologías de la información','',
'sistemas y computación','59e91194ab63966ba386f5b5a94ffcc6','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Leticia','Santa Olalla Ocampo','femenino','','3115569','M.C.','Maestría en ciencias de la computación','',
'sistemas y computación','13bd9e47933e366d86896400cfe0ce76','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Liliana','Villegas Sámano','femenino','','3890403','M.A.R.H.','Maestría en administración de recursos humanos','',
'sistemas y computación','9bf284c627063531498f3b7a7516adda','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Madaí','Ménez Esquivel','femenino','','4370472','M.T.I.','Maestría en tecnologías de la información','',
'sistemas y computación','fbb9097c7668f4c97397cfeefb4d4ecb','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Marco Aurelio','Velázquez Velazco','masculino','','2022990','L.I.','Licenciatura en informática','',
'sistemas y computación','7d0228467b06af3f89354b596583581e','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('María Isabel','Vásquez Ocampo','femenino','','4370495','M.T.I.','Maestría en tecnologías de la información','',
'sistemas y computación','5b708455dbc90a73fc2e09be23dfa55d','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Mario Alberto','Hernández Mandujano','masculino','','4004837','L.I.','Licenciatura en informática','',
'sistemas y computación','71d6fddba899c8279fd11ea7ff020af9','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Mario Humberto','Tiburcio Zuñiga','masculino','','3487236','M.C.','Maestría en ciencias de la computación','',
'sistemas y computación','eae6598dea53f5ce1afe833163b0c9c0','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Maritza','Ciprian Rosario','femenino','','3890404','M.A.R.H.','Maestría en administración de recursos humanos','',
'sistemas y computación','f1f65045bc4a781bb7d9da70406da320','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Noemí','Lara Acono','femenino','','2022143','M.A.R.H.','Licenciatura en informática','',
'sistemas y computación','f93b1e416e561fde9071f3325f65f0f3','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Norma Josefina','Ontiveros Hernández','femenino','','2493372','M.C.','Maestría en ciencias de la computación','',
'sistemas y computación','5982925d3725b231ab6b906ef4fc088b','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Norma Rocío','Gómez Rivera','femenino','','3299685','M.C.','Maestría en ciencias de la computación','',
'sistemas y computación','6c72c3e4a1db5d1e3d5854aa56ff6a16','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Ofelia','Espinosa Baca','femenino','','1540681','L.I.','Licenciatura en informática','',
'sistemas y computación','ca9ba34838557184b5fac1d7478fdfbc','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Patricia Adriana','Guadarrama Lozada','femenino','','5933255','L.I.','Licenciatura en informática','',
'sistemas y computación','f12734b17fbd6ba65b3886cff63e4344','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Raymundo','Real Palencia','masculino','','3488175','I.S.C.','Ingeniería en sistemas computacionales','',
'sistemas y computación','c0321966a6a582923a9cd13d6d7d1e75','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Rene','Rosales Vidal','masculino','','5016623','I.S.C.','Ingeniería en sistemas computacionales','',
'sistemas y computación','0fc3df3b2489ea9b3ab51725476f8398','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Sandra','Martínez Moreno','femenino','','4797151','I.S.C.','Maestría en mercadotecnia','',
'sistemas y computación','28c85a7375ae2dbd8ca1c7206337c864','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Sócrates','Espinoza Salgado','masculino','','5881108','DR.','Doctorado en ciencias en polímeros','',
'sistemas y computación','ddde623f0006b569469a1194b2ca0b61','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Tomás Emmanuel','Higareda Pliego','masculino','','4962680','M.T.I.','Maestría en tecnologías de la información','',
'sistemas y computación','0c0db9b3f12fa9a8d72344778171c31f','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Venancio','Bárcenas Martínez','masculino','','2537727','L.I.','Licenciatura en informática','',
'sistemas y computación','1b61ea7ff24bf91b95095d29242caaf5','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Víctor','Hernández Rodríguez','masculino','','2292529','L.I.','Licenciatura en informática','',
'sistemas y computación','cfbd14d7e9cf98f682fd33185271bf1d','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Víctor Hugo','Rangel Salinas','masculino','','6849845','I.S.C.','Ingeniería en sistemas computacionales','',
'sistemas y computación','19e7762d0bad1f2784f95145472aa989','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');
insert into Profesor
(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,HacerCorrecciones,DatosCorregidos)values('Yanet','Castrejón Hernández','femenino','','5396095','I.S.C.','Ingeniería en sistemas computacionales','',
'sistemas y computación','bab088642e0c6f603d5e9d49b2918b9e','de2f15d014d40b93578d255e6221fd60','2015-04-28 12:00:00',false,'no');

insert into Estudiante(Nombre,Apellidos,Sexo,NumControl,Carrera,Reticula,Direccion,TelefonoCelular,TelefonoDeCasa,CorreoElectronico,Proyecto,ProyectoAutorizado,
OpcionDeTitulacion,AutorizacionDeRegistroTrabajoTitulacion,AutorizacionDeImpresion,
LiberacionDeProyectoTitulacionIntegral,Observaciones,ClaveDeAcceso,FechaYHoraDeRegistro,
HacerCorrecciones,DatosCorregidos)values('Ivan','Barrientos González','masculino','09090359',
'INGENIERÍA EN SISTEMAS COMPUTACIONALES','ISIC-2004-296','Vicente Guerrero #20','7341279492','3435597',
'i.barrientos.gonzalez@hotmail.com','Página web',false,'X (INFORME DE RESIDENCIA PROFESIONAL)',false,false,false,false,
'd2e098e2b1313e1d6e6de3f78da7cecd','2015-04-21 12:00:00',false,'no');
insert into Estudiante(Nombre,Apellidos,Sexo,NumControl,Carrera,Reticula,Direccion,TelefonoCelular,TelefonoDeCasa,CorreoElectronico,Proyecto,ProyectoAutorizado,
OpcionDeTitulacion,AutorizacionDeRegistroTrabajoTitulacion,AutorizacionDeImpresion,
LiberacionDeProyectoTitulacionIntegral,Observaciones,ClaveDeAcceso,FechaYHoraDeRegistro,
HacerCorrecciones,DatosCorregidos)values('Osvaldo','Muñoz Vences','masculino','09090478',
'INGENIERÍA EN SISTEMAS COMPUTACIONALES','ISIC-2004-296','Boca del río #20','7341279492','3435597',
'munoz.vences@hotmail.com','Página web',false,'I (TESIS PROFESIONAL)',false,false,false,false,
'd2e098e2b1313e1d6e6de3f78da7cecd','2015-04-21 12:00:00',false,'no');
insert into Estudiante(Nombre,Apellidos,Sexo,NumControl,Carrera,Reticula,Direccion,TelefonoCelular,TelefonoDeCasa,CorreoElectronico,Proyecto,ProyectoAutorizado,
OpcionDeTitulacion,AutorizacionDeRegistroTrabajoTitulacion,AutorizacionDeImpresion,
LiberacionDeProyectoTitulacionIntegral,Observaciones,ClaveDeAcceso,FechaYHoraDeRegistro,
HacerCorrecciones,DatosCorregidos)values('Manuela','Colin Colin','femenino','09090354',
'INGENIERÍA EN SISTEMAS COMPUTACIONALES','ISIC-2004-296','Vicente Guerrero #20','7341279492','3435597',
'i.barrientos.gonzalez@hotmail.com','Página web',false,'VI (EXAMEN GLOBAL POR ÁREAS DEL CONOCIMIENTO)',false,false,false,false,
'd2e098e2b1313e1d6e6de3f78da7cecd','2015-04-21 12:00:00',false,'no');
insert into Estudiante(Nombre,Apellidos,Sexo,NumControl,Carrera,Reticula,Direccion,TelefonoCelular,TelefonoDeCasa,CorreoElectronico,Proyecto,ProyectoAutorizado,
OpcionDeTitulacion,AutorizacionDeRegistroTrabajoTitulacion,AutorizacionDeImpresion,
LiberacionDeProyectoTitulacionIntegral,Observaciones,ClaveDeAcceso,FechaYHoraDeRegistro,
HacerCorrecciones,DatosCorregidos)values('Gustavo','Adolfo Adolfo','masculino','09090353',
'INGENIERÍA EN SISTEMAS COMPUTACIONALES','ISIC-2004-296','Vicente Guerrero #20','7341279492','3435597',
'i.barrientos.gonzalez@hotmail.com','Página web',false,'VII (MEMORIA DE EXPERIENCIA PROFESIONAL)',false,false,false,false,
'd2e098e2b1313e1d6e6de3f78da7cecd','2015-04-21 12:00:00',false,'no');
insert into Estudiante(Nombre,Apellidos,Sexo,NumControl,Carrera,Reticula,Direccion,TelefonoCelular,TelefonoDeCasa,CorreoElectronico,Proyecto,ProyectoAutorizado,
OpcionDeTitulacion,AutorizacionDeRegistroTrabajoTitulacion,AutorizacionDeImpresion,
LiberacionDeProyectoTitulacionIntegral,Observaciones,ClaveDeAcceso,FechaYHoraDeRegistro,
HacerCorrecciones,DatosCorregidos)values('Sara','Colín Díaz','femenino','09090352',
'INGENIERÍA EN SISTEMAS COMPUTACIONALES','ISIC-2004-296','Vicente Guerrero #20','7341279492','3435597',
'i.barrientos.gonzalez@hotmail.com','Página web',false,'VIII (ESCOLARIDAD POR PROMEDIO)',false,false,false,false,
'd2e098e2b1313e1d6e6de3f78da7cecd','2015-04-21 12:00:00',false,'no');
insert into Estudiante(Nombre,Apellidos,Sexo,NumControl,Carrera,Reticula,Direccion,TelefonoCelular,TelefonoDeCasa,CorreoElectronico,Proyecto,ProyectoAutorizado,
OpcionDeTitulacion,AutorizacionDeRegistroTrabajoTitulacion,AutorizacionDeImpresion,
LiberacionDeProyectoTitulacionIntegral,Observaciones,ClaveDeAcceso,FechaYHoraDeRegistro,
HacerCorrecciones,DatosCorregidos)values('Sirilo','Gómez Gómez','masculino','09090351',
'INGENIERÍA EN SISTEMAS COMPUTACIONALES','ISIC-2004-296','Vicente Guerrero #20','7341279492','3435597',
'i.barrientos.gonzalez@hotmail.com','Página web',false,'IX (ESCOLARIRAD POR ESTUDIOS DE POSGRADO)',false,false,false,false,
'd2e098e2b1313e1d6e6de3f78da7cecd','2015-04-21 12:00:00',false,'no');
insert into Estudiante(Nombre,Apellidos,Sexo,NumControl,Carrera,Reticula,Direccion,TelefonoCelular,TelefonoDeCasa,CorreoElectronico,Proyecto,ProyectoAutorizado,
OpcionDeTitulacion,AutorizacionDeRegistroTrabajoTitulacion,AutorizacionDeImpresion,
LiberacionDeProyectoTitulacionIntegral,Observaciones,ClaveDeAcceso,FechaYHoraDeRegistro,
HacerCorrecciones,DatosCorregidos)values('Jorge','Vadillo Vadillo','masculino','09090350',
'INGENIERÍA EN SISTEMAS COMPUTACIONALES','ISIC-2004-296','Vicente Guerrero #20','7341279492','3435597',
'i.barrientos.gonzalez@hotmail.com','Página web',false,'(INFORME TÉCNICO DE RESIDENCIA PROFESIONAL)',false,false,false,false,
'd2e098e2b1313e1d6e6de3f78da7cecd','2015-04-21 12:00:00',false,'no');