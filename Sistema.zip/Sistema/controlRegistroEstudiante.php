<?php
	error_reporting( E_WARNING | E_ERROR );
							
	//funciones
	include 'funciones.php';
	//$mysqli = new mysqli('localhost','root','samushomysql123');
	$mysqli = conexionMysqli();
						
	if (empty($_POST['NumControl'])) {
		$error = true;
		header("Location: signup.php?vacio=si");
	}
	else {
		$num_control = $_POST['NumControl'];
	}
	if (empty($_POST['Nombre'])) {
		$error = true;
		header("Location: signup.php?vacio=si");
	}
	else {
		$nombre = $mysqli->real_escape_string(htmlspecialchars($_POST['Nombre']));
		$nombre = htmlentities($nombre);
		if (ctype_upper($nombre) != true) {
			$nombre = strtr(strtoupper($nombre),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
		}
	}
	if (empty($_POST['Apellidos'])) {
		$error = true;
		header("Location: signup.php?vacio=si");
	}
	else {
		$apellidos = $mysqli->real_escape_string(htmlspecialchars($_POST['Apellidos']));
		$apellidos = htmlentities($apellidos);
		if (ctype_upper($apellidos) != true) {
			$apellidos = strtr(strtoupper($apellidos),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
		}
	}
	$sexo = $mysqli->real_escape_string(htmlspecialchars($_POST['Sexo']));
	$sexo = htmlentities($sexo);
	if (empty($_POST['Direccion'])) {
		$error = true;
		header("Location: signup.php?vacio=si");
	}
	else {
		$direccion = $mysqli->real_escape_string(htmlspecialchars($_POST['Direccion']));
		$direccion = htmlentities($direccion);
		if (ctype_upper($direccion) != true) {
			$direccion = strtr(strtoupper($direccion),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
		}
	}
	if (empty($_POST['TelefonoCelular']) && empty($_POST['TelefonoDeCasa'])) {
		$error = true;
		header("Location: signup.php?sinnumtel=si");
	}
	else {
		$telefono_celular = $mysqli->real_escape_string(htmlspecialchars($_POST['TelefonoCelular']));
		$telefono_celular = htmlentities($telefono_celular);
		$telefono_de_casa = $mysqli->real_escape_string(htmlspecialchars($_POST['TelefonoDeCasa']));
		$telefono_de_casa = htmlentities($telefono_de_casa);
	}
	if (empty($_POST['CorreoElectronico'])) {
		$error = true;
		header("Location: signup.php?vacio=si");
	}
	else {
		$correo_electronico = $mysqli->real_escape_string(htmlspecialchars($_POST['CorreoElectronico']));
		$correo_electronico = htmlentities($correo_electronico);
	}
	$carrera = $mysqli->real_escape_string(htmlspecialchars($_POST['Carrera']));
	$carrera = htmlentities($carrera);
	$reticula = $mysqli->real_escape_string(htmlspecialchars($_POST['Reticula']));
	$reticula = htmlentities($reticula);
	$opcion_de_titulacion = $mysqli->real_escape_string(htmlspecialchars($_POST['OpcionDeTitulacion']));
	$opcion_de_titulacion = htmlentities($opcion_de_titulacion);
	$proyecto = $mysqli->real_escape_string(htmlspecialchars($_POST['Proyecto']));
	$proyecto = htmlentities($proyecto);

	if (ctype_upper($proyecto) != true) {
		$proyecto = strtr(strtoupper($proyecto),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
	}

	if (empty($_POST['ClaveDeAcceso'])) {
		$error = true;
		header("Location: signup.php?vacio=si");
	}
	else {
		$clave_de_acceso = $_POST['ClaveDeAcceso'];
	}
	if (empty($_POST['ConfClaveDeAcceso'])) {
		$error = true;
		header("Location: signup.php?vacio=si");
	}
	else {
		$conf_clave_de_acceso = $_POST['ConfClaveDeAcceso'];
	}

	/******** VALIDAR CONTRASEÑA ********/

	if (preg_match("/[ ]/", $clave_de_acceso)) {
		$error = true;
		header("Location: signup.php?espacioenblanco=si");
	}
	else {
		/******** COMPROBAR SI LA CONTRASEÑA ES CORTA ********/
		if (strlen($clave_de_acceso)<8) {
			$error = true;
			header("Location: signup.php?clavecorta=si");
		}
		else {

			/******** COMPROBAR QUE LA CONTRASEÑA TENGA LOS CARACTERES PERMITIDOS ********/
									
			/******** COMPROBAR QUE AL MENOS TENGA UN NÚMERO ********/
			if (!preg_match("/[0-9]/", $clave_de_acceso)) {
				$error = true;
				header("Location: signup.php?clavesinnumero=si");
			}
			
			/****** COMPROBAR QUE LA CONTRASEÑA NO CONTENGA CARACTERES NO VÁLIDOS ******/
			if (preg_match("/[{}''´¨¿¡]/", $clave_de_acceso)) {
				$error = true;
				header("Location: signup.php?novalidos=si");
			}

			/****** COMPROBAR QUE AL MENOS TENGA UN CARACTER ESPECIAL ******/
			if (!preg_match("/[@#$%-_]/", $clave_de_acceso)) {
				$error = true;
				header("Location: signup.php?clavesinespecial=si");
			}
												
			/****** COMPROBAR QUE LA CONTRASEÑA COINCIDA ******/
			if (strcmp($clave_de_acceso, $conf_clave_de_acceso)!=0) {
				$error = true;
				header("Location: signup.php?clavesdiferentes=si");																				
			}
			if ($error != true) {
				/**************  COMPROBAR LA EXISTENCIA DEL ESTUDIANTE  *************/
		
				//BUSCA SI EXISTE EL NÚMERO DE CONTROL
		
				openConectionMysql();	// SE ABRE LA CONEXION A LA BASE DE DATOS CON ESTA FUNCION	
				mysql_query("SET NAMES 'utf8'");	
				$nuevo_numcontrol = mysql_query("SELECT NumControl FROM Estudiante WHERE 
				NumControl ='$num_control'");	//QUERY PARA OBTENER LOS REGISTROS EXISTENTES
		
				//SI HAY MAS DE UN REGISTRO		
				if(mysql_num_rows($nuevo_numcontrol)>0) {
					header("Location: signup.php?numcontrolexistente=si");
				}
		
				//SI NO HAY UN REGISTRO CON ESE NÚMERO DE CONTROL SE GUARDAN LOS DATOS EN LA BASE DE DATOS
				else {
					$fecha_hora_registro = date("Y-n-j H:i:s");	
					$query="INSERT INTO Estudiante(Nombre,Apellidos,Sexo,NumControl,Carrera,Reticula,
					Direccion,TelefonoCelular,TelefonoDeCasa,CorreoElectronico,Proyecto,ProyectoAutorizado,
					OpcionDeTitulacion,AutorizacionDeRegistroTrabajoTitulacion,AutorizacionDeImpresion,
					LiberacionDeProyectoTitulacionIntegral,Observaciones,ClaveDeAcceso,FechaYHoraDeRegistro,
					HacerCorrecciones,DatosCorregidos)values('$nombre','$apellidos','$sexo','$num_control',
					'$carrera','$reticula','$direccion','$telefono_celular','$telefono_de_casa',
					'$correo_electronico','$proyecto',false,'$opcion_de_titulacion',false,false,false,false,
					'$clave_de_acceso','$fecha_hora_registro',false,'no')";
					if(mysql_query($query)) { //SI SE LOGRÓ LA CONSULTA		
						header("Location: registroEstudianteExitoso.php");
						
						//OBTENER EL ID DEL ESTUDIANTE ANTERIORMENTE REGISTRADO
						$consulta = sprintf("SELECT IdEstudiante FROM Estudiante WHERE NumControl ='$num_control'");
						$resultado = conexionMysql($consulta);
						$id = mysql_result($resultado,0,'IdEstudiante');
													
						//NOTIFICAR EL REGISTRO DE UN ALUMNO AL SISTEMA
						$notificar = "insert into notificaciones(IdEstudiante,notAprobReg,notAprobTrab,notRegSistema)values($id,false,false,true)";
						mysql_query($notificar);
					}
					else { //SI NO SE LOGRÓ LA CONSULTA
						header("Location: signup.php?registrofallido=si");		
					}
				}
			}	
		}
	}						
?>
