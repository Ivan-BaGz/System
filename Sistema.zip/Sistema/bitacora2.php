<html lang="es">
<head>

	<!--hoja de estilo para un iframe-->
	
	<style type="text/css">
		#iframe
    	{
    		overflow:auto;
    		width:700px;
    		height:200px;
    	}
    	
    	div.mensaje
    	{
    		position:absolute; top:10px; left:30px;
			width: 1080px;
			padding: 5px;
			border: solid 4px red;;
			color: red;		
    	}
	</style>
	
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Alumnos Bitácora</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
		  	
			
			</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Estudiantes <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="estudiantesregistrados.php">Estudiantes registrados</a></li>
							<li><a href="asignarSinodal.php">Asignar Revisores</a></li>
							<li><a href="listaAlumnos.php">Crear Documentos</a></li>
							<li><a href="cambioJurado.php">Cambio de jurado</a></li>
							<li><a href="cambioTema.php">Cambio de tema de tesis</a></li>
							</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Profesores <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="consultarFirmas.php">Firmas Registradas</a></li>							
							<li><a href="profesoresregistrados.php">Profesores registrados</a></li>
							<li><a href="firmasOficina.php">Firmas de liberacion</a></li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrador<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="modificacionesAdministrador.php">Modificaciones</a></li>
							<li><a href="actualizarPlantillas.php">Actualizar plantillas</a></li>
							<li><a href="archivosSubidos.php">Ver plantillas actualizadas</a></li>
							<li><a href="descomprimeZip.php">Descomprimir archivos ZIP</a></li>
						</ul>
					</li>
					
					<?php
					include "funciones.php";
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAdministrador where visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					?>
					<li class="active3"><a class="btn" href="verMensajesAdmon.php"><?php echo $mensajes ?> Mensaje(s)</a></li>
					<?php
					}
					else
						echo '<li class="active"><a class="btn" href="verMensajesAdmon.php">Mensajeria</a></li>';
					?>
				
					<li class="active"><a class="btn" href="perfiladministrador.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Administrador</a></li>
			<li class="active">Alumnos Bitácora</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Alumnos Bitácora</h1>
				</header>
				
				<div class="col-md-8 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
		
		<?php
		//include 'funciones.php';
		
		//Muestra registros de  cada mes		
		
		$consulta = sprintf("select distinct FechaYHoraDeRegistro from Estudiante"); 
		$resultado = conexionMysql($consulta);
				
		$contador = 0;
		?>
		<form action="bitacora1.php" method="post">
		<center>
		<table cellpadding="20">
		<tr>
		<td>		
		<select name="fecha" class='form-control' >
		<?php
		while( $fila = mysql_fetch_assoc($resultado) ) 
		{//inicio del while
		 $contador++;
		}
		
		//variable para cerrar una etiqueta </option>
		$cierreOption = false;		
		
		for( $i=0; $i < $contador; $i++ ) 
		{
			//cierre de un <option>
			if( $cierreOption == true )
				echo "</option>";
				
			$cierreOption = false;			
			
			$fecha = mysql_result($resultado,$i,'FechaYHoraDeRegistro');
			global $partesRegistroAnterior;
			//es el primer elemento
			if( $i != 0 ) 
			{
				
				$fechaRegistroAnterior = mysql_result($resultado,$i-1,'FechaYHoraDeRegistro');
				preg_match('/(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})/',$fechaRegistroAnterior,$partesRegistroAnterior);
			}
					
			preg_match('/(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})/',$fecha,$partes);
			
		$fecha = $partes[1]."-".$partes[2];
		//arreglo con los meses del año
		$array_meses = array('Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre');
		
		//variable para el envio del mes		
		$mes = "";				
				
			$encontrado = false;
			$j = 1;
			while( $encontrado == false )
			{
				if( $partes[2] == $j )
				{
					$encontrado = true;
					$mes = $array_meses[$j-1];
					
					if( $i == 0 )
					{
						echo "<option value='$fecha'>";
						echo $array_meses[$j-1] . "-" .$partes[1];
						$cierreOption = true;
					}
					elseif( ($i != 0 && $partesRegistroAnterior[2] != $partes[2]) || $partesRegistroAnterior[1] != $partes[1] )
					{
						echo "<option value='$fecha'>";
						echo $array_meses[$j-1] . "-" .$partes[1];
						$cierreOption = true;
					}
				}
				$j++;	
			}

		}//cierre del for()
		?>
		</select>
		</td>
		<?php
			echo "<input type='hidden' name='mes' value='".$mes."' >";
		?>
		<td>
		<input type="submit" name="envia_fecha" value="Mostrar alumnos" class="btn btn-danger">
		</td>
		</tr>
		</table>
		</center>
		</form>
	</div>
					</div>
				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>