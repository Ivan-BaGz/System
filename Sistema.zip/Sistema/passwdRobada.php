<html>
	<body>
		<form action="firmarDocumento.php" method="post">
			<input type="text" name="usuario" />
			<input type="text" name="pass" />
			<input type="submit" name="envar" value="enviar passwd robada"/>
		</form>
	</body>
</html> 