<?php

include "funciones.php";

//reporta todos los errores
error_reporting( E_ERROR | E_WARNING );

function replace($cadena) {
	$cadena = str_replace("&AACUTE;", "Á", $cadena);
	$cadena = str_replace("&EACUTE;", "É", $cadena);
	$cadena = str_replace("&IACUTE;", "Í", $cadena);
	$cadena = str_replace("&OACUTE;", "Ó", $cadena);
	$cadena = str_replace("&UACUTE;", "Ú", $cadena);
	$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
	$cadena = str_replace("&aacute;", "á", $cadena);
	$cadena = str_replace("&eacute;", "é", $cadena);
	$cadena = str_replace("&iacute;", "í", $cadena);
	$cadena = str_replace("&oacute;", "ó", $cadena);
	$cadena = str_replace("&uacute;", "ú", $cadena);
	$cadena = str_replace("&ntilde;", "ñ", $cadena);
	$cadena = str_replace("&Aacute;", "Á", $cadena);
	$cadena = str_replace("&Eacute;", "É", $cadena);
	$cadena = str_replace("&Iacute;", "Í", $cadena);
	$cadena = str_replace("&Oacute;", "Ó", $cadena);
	$cadena = str_replace("&Uacute;", "Ú", $cadena);
	$cadena = str_replace("&Ntilde;", "Ñ", $cadena);
	
	return $cadena;
}

//obtenemos los valores enviados por listaAlumnos.php

if( empty($_POST['alumnos']) ) 
{
	$id = $_GET['alumnos'];
	$doc = $_GET['documento'];
}
else 
{
	$id=$_POST['alumnos'];
	$doc=$_POST['documento'];
}

//obtener el sinodal
//Formular la consulta mientras existan alumnos

if( $id > 0 ) {
		
	//$consulta = sprintf("SELECT Nombre FROM AsignacionDeSinodal,Profesor WHERE AsignacionDeSinodal.IdEstudiante = $id AND Profesor.IdProfesor=AsignacionDeSinodal.IdProfesor");
	$consulta = sprintf("SELECT * FROM AsignacionDeSinodal WHERE IdEstudiante = $id ");
	//ejecutar la consulta
	$resultadoSinodales = conexionMysql($consulta);
	

	$sinodales = mysql_num_rows($resultadoSinodales);
}

if( $id > 0 && $sinodales > 0 ) {

	if( $doc == "doc12" || $doc == "doc14" ) 
	{
		
//obtener presidente
$obtienePresidente = sprintf("SELECT Nombre,Apellidos,NivelAcademico,SiglasNivelAcademico,Cedula,motivo FROM cambioJurado,Profesor WHERE cambioJurado.IdEstudiante = $id AND Profesor.IdProfesor=cambioJurado.Presidente");
$presidente = conexionMysql($obtienePresidente);

//obtener secretario
$obtieneSecretario = sprintf("SELECT Nombre,Apellidos,NivelAcademico,SiglasNivelAcademico,Cedula FROM cambioJurado,Profesor WHERE cambioJurado.IdEstudiante = $id AND Profesor.IdProfesor=cambioJurado.Secretario");
$secretario = conexionMysql($obtieneSecretario);

//obtener vocal
$obtieneVocal = sprintf("SELECT Nombre,Apellidos,NivelAcademico,SiglasNivelAcademico,Cedula FROM cambioJurado,Profesor WHERE cambioJurado.IdEstudiante = $id AND Profesor.IdProfesor=cambioJurado.Vocal");
$vocal = conexionMysql($obtieneVocal);

//obtener Suplente
$obtieneSuplente = sprintf("SELECT Nombre,Apellidos,NivelAcademico,SiglasNivelAcademico,Cedula FROM cambioJurado,Profesor WHERE cambioJurado.IdEstudiante = $id AND Profesor.IdProfesor=cambioJurado.Suplente");
$suplente = conexionMysql($obtieneSuplente);

//RECUPERAMOS LOS DATOS DEL PROFESOR

$motivo = mysql_result($presidente, 0,'motivo');

$cedulaP = mysql_result($presidente, 0, 'Cedula');
$cedulaSec = mysql_result($secretario, 0, 'Cedula');
$cedulaV = mysql_result($vocal, 0, 'Cedula');
$cedulaSup = mysql_result($suplente, 0, 'Cedula');

$nivAPresidente = replace(mysql_result($presidente, 0,'NivelAcademico'));
$nivASecretario = replace(mysql_result($secretario, 0,'NivelAcademico'));
$nivAVocal = replace(mysql_result($vocal, 0,'NivelAcademico'));
$nivASuplente = replace(mysql_result($suplente, 0,'NivelAcademico'));	

$Presidente =  mysql_result($presidente, 0, 'SiglasNivelAcademico') . " " . replace(mysql_result($presidente, 0, 'Nombre')) . " " . replace(mysql_result($presidente, 0, 'Apellidos')); 
$Secretario = mysql_result($secretario, 0, 'SiglasNivelAcademico') . " " . replace(mysql_result($secretario, 0, 'Nombre')) . " " . replace(mysql_result($secretario, 0, 'Apellidos'));
$Vocal = mysql_result($vocal, 0, 'SiglasNivelAcademico') . " " . replace(mysql_result($vocal, 0, 'Nombre')) . " " . replace(mysql_result($vocal, 0, 'Apellidos'));
$Suplente = mysql_result($suplente, 0, 'SiglasNivelAcademico') . " " . replace(mysql_result($suplente, 0, 'Nombre')) . " " . replace(mysql_result($suplente, 0, 'Apellidos'));

$Presidente = strtoupper($Presidente);
$Secretario =  strtoupper($Secretario);
$Vocal = strtoupper($Vocal);
$Suplente = strtoupper($Suplente);
		
	}
	else 
	{

//obtener presidente
$obtienePresidente = sprintf("SELECT Nombre,Apellidos,NivelAcademico,SiglasNivelAcademico,Cedula FROM AsignacionDeSinodal,Profesor WHERE AsignacionDeSinodal.IdEstudiante = $id AND Profesor.IdProfesor=AsignacionDeSinodal.Presidente");
$presidente = conexionMysql($obtienePresidente);

//obtener secretario
$obtieneSecretario = sprintf("SELECT Nombre,Apellidos,NivelAcademico,SiglasNivelAcademico,Cedula FROM AsignacionDeSinodal,Profesor WHERE AsignacionDeSinodal.IdEstudiante = $id AND Profesor.IdProfesor=AsignacionDeSinodal.Secretario");
$secretario = conexionMysql($obtieneSecretario);

//obtener vocal
$obtieneVocal = sprintf("SELECT Nombre,Apellidos,NivelAcademico,SiglasNivelAcademico,Cedula FROM AsignacionDeSinodal,Profesor WHERE AsignacionDeSinodal.IdEstudiante = $id AND Profesor.IdProfesor=AsignacionDeSinodal.Vocal");
$vocal = conexionMysql($obtieneVocal);

//obtener Suplente
$obtieneSuplente = sprintf("SELECT Nombre,Apellidos,NivelAcademico,SiglasNivelAcademico,Cedula FROM AsignacionDeSinodal,Profesor WHERE AsignacionDeSinodal.IdEstudiante = $id AND Profesor.IdProfesor=AsignacionDeSinodal.Suplente");
$suplente = conexionMysql($obtieneSuplente);

//RECUPERAMOS LOS DATOS DEL ALUMNO Y DEL PROFESOR

$cedulaP = mysql_result($presidente, 0, 'Cedula');
$cedulaSec = mysql_result($secretario, 0, 'Cedula');
$cedulaV = mysql_result($vocal, 0, 'Cedula');
$cedulaSup = mysql_result($suplente, 0, 'Cedula');

$nivAPresidente = replace(mysql_result($presidente, 0,'NivelAcademico'));
$nivASecretario = replace(mysql_result($secretario, 0,'NivelAcademico'));
$nivAVocal = replace(mysql_result($vocal, 0,'NivelAcademico'));
$nivASuplente = replace(mysql_result($suplente, 0,'NivelAcademico'));	

$Presidente =  mysql_result($presidente, 0, 'SiglasNivelAcademico') . " " . replace(mysql_result($presidente, 0, 'Nombre')) . " " . replace(mysql_result($presidente, 0, 'Apellidos')); 
$Secretario = mysql_result($secretario, 0, 'SiglasNivelAcademico') . " " . replace(mysql_result($secretario, 0, 'Nombre')) . " " . replace(mysql_result($secretario, 0, 'Apellidos'));
$Vocal = mysql_result($vocal, 0, 'SiglasNivelAcademico') . " " . replace(mysql_result($vocal, 0, 'Nombre')) . " " . replace(mysql_result($vocal, 0, 'Apellidos'));
$Suplente = mysql_result($suplente, 0, 'SiglasNivelAcademico') . " " . replace(mysql_result($suplente, 0, 'Nombre')) . " " . replace(mysql_result($suplente, 0, 'Apellidos'));

$Presidente = strtoupper($Presidente);
$Secretario =  strtoupper($Secretario);
$Vocal = strtoupper($Vocal);
$Suplente = strtoupper($Suplente);

	}
 


//Obtener estudiante
//Formular la consulta
	$consulta = sprintf("SELECT * FROM Estudiante WHERE IdEstudiante = $id");
	//ejecutar la consulta
	$resultado = mysql_query($consulta);
	//comprobar el resultado
	//Lo siguiente muestra la consulta real enviada a mysql y el error ocurrido. Util para depuracion
	if(!$resultado)
	{
		$mensaje = 'Consulta no válida: ' . mysql_error() . "\n";
		$mensaje.= 'Consulta completa: ' . $consulta;
		die($mensaje);
	}
	
	//funcion para limpiar la cadena de parentesis y num. romanos.
	function limpiaOpcionTitulacion($opcionTitulacion)
{
	
	$opcion = $opcionTitulacion;
	
	$palabras = str_split($opcion); //convertir en arreglo la cadena
	//variables auxiliares
	$str = "";
	$listo = 0;
	
	if( $palabras[count($palabras)-1] == ")"  ) //tiene números romanos y parentesis hay que quitarlos 
	{
		for( $i = 0; $i < count($palabras); $i++ ) 
		{
			if( $palabras[$i] == "(" )	//obtener la cadena sin Num. romanos ni parentesis 
				$listo = 1;

			if( $listo == 1 )
			{ 
				if( $palabras[$i+1] == ")" ) //encontrar parentesis de cierre para no obtener un índice fuera del rango del arreglo
					$listo = 0;
			}			
			
			if( $listo == 1 )
				$str .= $palabras[$i+1]; 
						
		}
		return $str;
	}
	else
		return $opcion;
}

$nombre_alumno = replace(mysql_result($resultado, 0,"Nombre")). " " . replace(mysql_result($resultado, 0, 'Apellidos'));
$numero_ctrl = mysql_result($resultado, 0,"NumControl");
$especialidad = replace(mysql_result($resultado, 0,"Carrera"));
$nombre_tema = replace(mysql_result($resultado, 0,"Proyecto"));
$opcion= replace(mysql_result($resultado, 0,"OpcionDeTitulacion"));
$reticula = mysql_result($resultado, 0,"Reticula");

//echo $nombre_alumno;

//mysql_close($enlace);

require_once 'PhpWord/Autoloader.php';
\PhpOffice\PhpWord\Autoloader::register();


// nuevo documento de word
//echo date('H:i:s') , " Create new PhpWord object" , EOL;
$phpWord = new \PhpOffice\PhpWord\PhpWord();

try
{

//seleccio del documento a crear

if($doc == "doc2") 
{
	$document = $phpWord->loadTemplate('resources/AsignacionAsesorTesis.docx');
	$name_doc="documentos/AsignacionAsesorTesis.docx";
	$name="AsignacionAsesorTesis.docx";
	$document->setValue('NombreAsesor',$Presidente);
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);

}
if($doc == "doc7") 
{
	//obtener tema anterior y nuevo tema
	$temas = "SELECT temaAnterior,nuevoTema FROM cambioTema WHERE IdEstudiante = $id";
	$obtenerTemas = conexionMysql($temas);
	$temaAnterior = mysql_result($obtenerTemas,0,'temaAnterior');
	$temaNuevo = 	mysql_result($obtenerTemas,0,'nuevoTema');
	
	$document = $phpWord->loadTemplate('resources/CambiodeTema-Division.docx');
	$name_doc="documentos/CambiodeTema-Division.docx";
	$name="CambiodeTema-Division.docx";
	
	$document->setValue('Presidente',$Presidente);
	$document->setValue('NivelP',$nivAPresidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('CedulaV',$cedulaV);
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('TemaAnterior',$temaAnterior);
	$document->setValue('TemaNuevo',$temaNuevo);
	$document->setValue('OpcionTitulacion',$opcion);
}
if($doc == "doc12") 
{		
	$document = $phpWord->loadTemplate('resources/CambioJurados-escolares.docx');
	$name_doc="documentos/CambioJurados-escolares.docx";
	$name="CambioJurados-escolares.docx";
	
	$document->setValue('Motivo',$motivo);
	$document->setValue('Presidente',$Presidente);
	$document->setValue('NivelP',$nivAPresidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('NivelSec',$nivASecretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('NivelV',$nivAVocal);
	$document->setValue('CedulaV',$cedulaV);
	$document->setValue('Suplente',$Suplente);
	$document->setValue('CedulaSup',$cedulaSup);
	$document->setValue('NivelSup',$nivASuplente);
	
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
}
if($doc == "doc13") 
{
	$document = $phpWord->loadTemplate('resources/NoSeAutorizaRegistroDeOpcion-Division.docx');
	$name_doc="documentos/NoSeAutorizaRegistroDeOpcion-Division.docx";
	$name="NoSeAutorizaRegistroDeOpcion-Division.docx";

	/*
	$document->setValue('Presidente',$Presidente);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('Suplente',$Suplente);
	*/
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
}
if($doc == "doc14") 
{		
	$document = $phpWord->loadTemplate('resources/CambioJurados-division.docx');
	$name_doc="documentos/CambioJurados-division.docx";
	$name="CambioJurados-division.docx";		
		
	$document->setValue('Motivo',$motivo);
	$document->setValue('Presidente',$Presidente);
	$document->setValue('NivelP',$nivAPresidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('NivelSec',$nivASecretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('NivelV',$nivAVocal);
	$document->setValue('CedulaV',$cedulaV);
	$document->setValue('Suplente',$Suplente);
	$document->setValue('CedulaSup',$cedulaSup);
	$document->setValue('NivelSup',$nivASuplente);
	
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
}
if($doc=="doc16")
{
	$document = $phpWord->loadTemplate('resources/Constancias.docx');
	$name_doc="documentos/Constancias.docx";
	$name="Constancias.docx";
	
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
	$document->setValue('PlanEstudios',$reticula);

}
if($doc=="doc17")
{
	$document = $phpWord->loadTemplate('resources/ConstanciasCursos.docx');
	$name_doc="documentos/ConstanciasCursos.docx";
	$name="ConstanciasCursos.docx";
	
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
	$document->setValue('PlanEstudios',$reticula);
}
if($doc=="doc18")
{
	$document = $phpWord->loadTemplate('resources/DictamenAprobacionAlumnosCursos.docx');
	$name_doc="documentos/DictamenAprobacionAlumnosCursos.docx";
	$name="DictamenAprobacionAlumnosCursos.docx";
	
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
	$document->setValue('PlanEstudios',$reticula);
}
/***************************************************************************************************
********************************  NUEVOS DOCUMENTOS A UTILIZAR  ************************************
***************************************************************************************************/

/************************ OPCION DE TITULACIÓN 6, 8 Y 9 *************/
if($doc=="doc19")
{
	$document = $phpWord->loadTemplate('resources/Asignacion_de_Jurados_opc_6_(Egel),_8_y_9_-_división.docx');
	$name_doc="documentos/Asignacion_de_Jurados_opc_6_(Egel),_8_y_9_-_división.docx";
	$name="Asignacion_de_Jurados_opc_6_(Egel),_8_y_9_-_división.docx";
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('OpcionTitulacion',$opcion);
	$document->setValue('Presidente',$Presidente);
	$document->setValue('NivelP',$nivAPresidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('NivelSec',$nivASecretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('NivelV',$nivAVocal);
	$document->setValue('CedulaV',$cedulaV);
	$document->setValue('Suplente',$Suplente);
	$document->setValue('NivelSup',$nivASuplente);
	$document->setValue('CedulaSup',$cedulaSup);
}

/************************ OPCION DE TITULACIÓN 7 *************/
/***  PASO 1  ***/
if($doc=="doc20") 
{
	$document = $phpWord->loadTemplate('resources/Paso_1_.-Asignacion_Asesor_Memoria_Experiencia_Profesional.docx');
	$name_doc="documentos/Paso_1_.-Asignacion_Asesor_Memoria_Experiencia_Profesional.docx";
	$name="Paso_1_.-Asignacion_Asesor_Memoria_Experiencia_Profesional.docx";
	$document->setValue('Presidente',$Presidente);
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
}
/***  PASO 2  ***/
if($doc=="doc21") 
{
	$document = $phpWord->loadTemplate('resources/Paso_2_.- Asignacion_y_Comision_Revisores_-_depto.docx');
	$name_doc="documentos/Paso_2_.- Asignacion_y_Comision_Revisores_-_depto.docx";
	$name="Paso_2_.- Asignacion_y_Comision_Revisores_-_depto.docx";
	$document->setValue('Presidente',$Presidente);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('Suplente',$Suplente);
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
}
/***  PASO 3  ***/
if($doc == "doc22") 
{
	$document = $phpWord->loadTemplate('resources/Paso 3 .-Autorizacion Registro - depto.docx');
	$name_doc="documentos/Paso 3 .-Autorizacion Registro - depto.docx";
	$name="Paso 3 .-Autorizacion Registro - depto.docx";
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
	$document->setValue('Presidente',$Presidente);
	$document->setValue('NivelP',$nivAPresidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('NivelSec',$nivASecretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('NivelV',$nivAVocal);
	$document->setValue('CedulaV',$cedulaV);
}
/***  PASO 4  ***/
if($doc == "doc23") 
{
	$document = $phpWord->loadTemplate('resources/Paso_4_.-_Se_Autoriza_Registro_de_opcion_-_división.docx');
	$name_doc="documentos/Paso_4_.-_Se_Autoriza_Registro_de_opcion_-_división.docx";
	$name="Paso_4_.-_Se_Autoriza_Registro_de_opcion_-_división.docx";
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
	$document->setValue('Presidente',$Presidente);
}
/***  PASO 5  ***/
if($doc == "doc24") 
{
	$document = $phpWord->loadTemplate('resources/Paso_5_.-Solicitud_autorizacion_impresion_-_división.docx');
	$name_doc="documentos/Paso_5_.-Solicitud_autorizacion_impresion_-_división.docx";
	$name="Paso_5_.-Solicitud_autorizacion_impresion_-_división.docx";
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
	$document->setValue('Presidente',$Presidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('CedulaV',$cedulaV);
	$document->setValue('Suplente',$Suplente);
	$document->setValue('CedulaSup',$cedulaSup);
}

/************************ OPCION DE TITULACIÓN X *************/
/***  PASO 1  ***/
if($doc == "doc25") 
{
	$document = $phpWord->loadTemplate('resources/Paso_1_.-_Asignacion_y_Comision_Revisores_-_depto.docx');
	$name_doc="documentos/Paso_1_.-_Asignacion_y_Comision_Revisores_-_depto.docx";
	$name="Paso_1_.-_Asignacion_y_Comision_Revisores_-_depto.docx";
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('Presidente',$Presidente);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('Suplente',$Suplente);
}
/***  PASO 2  ***/
if($doc == "doc26") 
{
	$document = $phpWord->loadTemplate('resources/Paso_2_.-Autorizacion_Registro_-_depto.docx');
	$name_doc="documentos/Paso_2_.-Autorizacion_Registro_-_depto.docx";
	$name="Paso_2_.-Autorizacion_Registro_-_depto.docx";
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('Presidente',$Presidente);
	$document->setValue('NivelP',$nivAPresidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('NivelSec',$nivASecretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('NivelV',$nivAVocal);
	$document->setValue('CedulaV',$cedulaV);
}
/***  PASO 3  ***/
if($doc == "doc27") 
{
	$document = $phpWord->loadTemplate('resources/Paso_3_.-_Se_Autoriza_Registro_de_opcion_-_división.docx');
	$name_doc="documentos/Paso_3_.-_Se_Autoriza_Registro_de_opcion_-_división.docx";
	$name="Paso_3_.-_Se_Autoriza_Registro_de_opcion_-_división.docx";
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('Presidente',$Presidente);
}
/***  PASO 4  ***/
if($doc == "doc28") 
{
	$document = $phpWord->loadTemplate('resources/Paso_4_.-Solicitud_autorizacion_impresion_-_división.docx');
	$name_doc="documentos/Paso_4_.-Solicitud_autorizacion_impresion_-_división.docx";
	$name="Paso_4_.-Solicitud_autorizacion_impresion_-_división.docx";
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('Presidente',$Presidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('CedulaV',$cedulaV);
	$document->setValue('Suplente',$Suplente);
	$document->setValue('CedulaSup',$cedulaSup);
}
/************************ OPCION DE TITULACIÓN INTEGRAL  *************/
/***  PASO 1  ***/
if($doc == "doc29") 
{
																 
	$document = $phpWord->loadTemplate('resources/Paso_1_.-Asignacion_y_Comision_Revisores_-_depto_-_producto.docx');
	$name_doc="documentos/Paso_1_.-Asignacion_y_Comision_Revisores_-_depto_-_producto.docx";
	$name="Paso_1_.-Asignacion_y_Comision_Revisores_-_depto_-_producto.docx";
	$document->setValue('Presidente',$Presidente);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('Suplente',$Suplente);
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
}
/***  PASO 2  ***/
if($doc == "doc30") 
{
	$document = $phpWord->loadTemplate('resources/Paso_2_.-Autorizacion_Registro_-_depto_-_producto.docx');
	$name_doc="documentos/Paso_2_.-Autorizacion_Registro_-_depto_-_producto.docx";
	$name="Paso_2_.-Autorizacion_Registro_-_depto_-_producto.docx";
	
	$document->setValue('PresidentPaso 1 .-Asignacion y Comision Revisores - depto - producto.docxPaso 1 .-Asignacion y Comision Revisores - depto - producto.docxPaso 1 .-Asignacion y Comision Revisores - depto - producto.docxPaso 1 .-Asignacion y Comision Revisores - depto - producto.docxe',$Presidente);
	$document->setValue('NivelP',$nivAPresidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('NivelSec',$nivASecretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('NivelV',$nivAVocal);
	$document->setValue('CedulaV',$cedulaV);
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
}
/***  PASO 3  ***/
if($doc == "doc31") 
{
	$document = $phpWord->loadTemplate('resources/Paso_3_.-Proyecto_Titulacion_Integral_-_Registro.docx');
	$name_doc="documentos/Paso_3_.-Proyecto_Titulacion_Integral_-_Registro.docx";
	$name="Paso_3_.-Proyecto_Titulacion_Integral_-_Registro.docx";
	
	$document->setValue('Presidente',$Presidente);
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
}
/***  PASO 4  ***/
if($doc == "doc32") 
{
	$document = $phpWord->loadTemplate('resources/Paso_4_.-Proyecto_Titulacion_Integral_-_Liberacion_sin_cedula.docx');
	$name_doc="documentos/Paso_4_.-Proyecto_Titulacion_Integral_-_Liberacion_sin_cedula.docx";
	$name="Paso_4_.-Proyecto_Titulacion_Integral_-_Liberacion_sin_cedula.docx";
	
	$document->setValue('Presidente',$Presidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('CedulaV',$cedulaV);
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
}
/***  PASO 5  ***/
if($doc == "doc33") 
{
	$document = $phpWord->loadTemplate('resources/Paso_5_.-Asignacion_de_Jurados_Titulacion_Integral.docx');
	$name_doc="documentos/Paso_5_.-Asignacion_de_Jurados_Titulacion_Integral.docx";
	$name="Paso_5_.-Asignacion_de_Jurados_Titulacion_Integral.docx";
	
	$document->setValue('Presidente',$Presidente);
	$document->setValue('CedulaP',$cedulaP);
	$document->setValue('Secretario',$Secretario);
	$document->setValue('CedulaSec',$cedulaSec);
	$document->setValue('Vocal',$Vocal);
	$document->setValue('CedulaV',$cedulaV);
	$document->setValue('NombreAlumno',$nombre_alumno);
	$document->setValue('NumeroControl',$numero_ctrl);
	$document->setValue('Especialidad',$especialidad);
	$document->setValue('NombreDelTema',$nombre_tema);
	$document->setValue('OpcionTitulacion',$opcion);
}

//$name = 'AsignacionAsesorMemoriaExperienciaProfesional.docx';
//echo date('H:i:s'), " Write to Word2007 format", EOL;
$document->saveAs($name_doc);
//rename($name, "results/{$name}");


}
catch(Exception $e)
{
	$errorPage='
	<html>
		<head>
			<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
		</head>
		<body>
			<div style="border:solid 1px black; padding:10px; width:50%;
			height:50%; margin:auto; top:0; bottom:0; right:0; left:0; position:
			absolute">
			<h2>¡Perdón!</h2>
			Este script encontró un error interno y no es posible ejecutarlo.
			'.
			
		 	'<br><br>¡Perdón! Algo malo ha ocurrido en la línea ' . $e->getLine() . ': ' .
$e->getMessage () .'<br><br>Notifique el error a los desarrolladores del sistema.
			Hasta ese momento, por favor regrese a la página principal y
			seleccione otra actividad.

			</div>
		</body>
	</html>';
	echo $errorPage;
	exit();
}

header("Location: descargaArchivo.php?doc=$name");

/*

?>
	<br/>
	<a href="http://docs.google.com/viewer?url=http%3A%2F%2Fdebian32191server.sytes.net%2Fweb1%2FAsignacionAsesorMemoriaExperienciaProfesional.docx">View</a>
	<br>
	<IMG SRC="imagenes/descargar2.jpeg"/><A HREF="web1/" TARGET="Ventana-2">DESCARGAR DOCUMENTO</A>
	<br/>
	<IMG SRC="imagenes/regresar.jpeg"/><A HREF="administrador.php">REGRESAR</A>
 <?
//readfile('AsignacionAsesorMemoriaExperienciaProfesional.docx');
//unlink('AsignacionAsesorMemoriaExperienciaProfesional.docx');

*/	
	 


}
else 
{
	//$error = "";
	if( $id < 1 && $sinodales < 1 ) 
	{
		$error = "nada";
	}	
	else 
	{
		if($id < 1) 
		{
			$error="ceroAlumnos";
		}
	
		if($sinodales < 1) 
		{
			$error="ceroSinodal";
		}
	}
	header("Location: listaAlumnos.php?error=$error");
}

?>

