<?php include 'seguridadestudiante.php'; ?>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Proceso | Titulación</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="#"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">	
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Tu información <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="datosPersonalesEstudiante.php">Información personal</a></li>
							<li><a href="datosEscolaresEstudiante.php">Información general</a></li>
						</ul>
					</li>
					<li><a href="procesoTitulacionEstudiante.php">Proceso de titulación</a></li>
					
					
					<?php
					include "funciones.php";
					
					session_name('loginUsuario');
					session_start();
					
					$num_control = $_SESSION["numcontrol"];
					$idAlumno = $_SESSION["id"];					
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAlumno where IdEstudiante = $idAlumno and visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');

					$consulta2 = "select HacerCorrecciones,DatosCorregidos from Estudiante where IdEstudiante = $idAlumno";
					$resultado2 = conexionMysql($consulta2);
					$hacerCorrecciones = mysql_result($resultado2, 0, 'HacerCorrecciones');
					$datosCorregidos = mysql_result($resultado2, 0, 'DatosCorregidos');

					if( $mensajes > 0 ) {
					?>
					<li class='active3'><a class='btn' href='verMensajesAlumno.php'><?php echo $mensajes ?> Mensaje(s)</a></li>
		            <?php
					}
					else {
						echo "<li class='active'><a class='btn' href='verMensajesAlumno.php'>Mensajeria</a></li>";
					}
					if ($hacerCorrecciones == 1 && $datosCorregidos == "no") {
						echo "<li class='active2'><a class='btn' href=''>Corrige tus datos</a></li>";
					}
					?>
					<li class="active"><a class="btn" href="perfilestudiante.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Proceso de titulación</h1>
				</header>
				
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Situación de tu proceso de titulación</h3>
							<br>
							<?php
								function replace($cadena) {
									$cadena = str_replace("&AACUTE;", "Á", $cadena);
									$cadena = str_replace("&EACUTE;", "É", $cadena);
									$cadena = str_replace("&IACUTE;", "Í", $cadena);
									$cadena = str_replace("&OACUTE;", "Ó", $cadena);
									$cadena = str_replace("&UACUTE;", "Ú", $cadena);
									$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
									$cadena = str_replace("&aacute;", "á", $cadena);
									$cadena = str_replace("&eacute;", "é", $cadena);
									$cadena = str_replace("&iacute;", "í", $cadena);
									$cadena = str_replace("&oacute;", "ó", $cadena);
									$cadena = str_replace("&uacute;", "ú", $cadena);
									$cadena = str_replace("&ntilde;", "ñ", $cadena);
									return $cadena;
								}
								
function generaTabla($id,$campo)
{
	$consulta = "select $campo,Nombre,Apellidos,AprobacionRegistro,AprobacionTrabajo from AsignacionDeSinodal,Profesor,firmarAutorizaciones where AsignacionDeSinodal.IdEstudiante = $id and Profesor.IdProfesor=AsignacionDeSinodal.$campo and firmarAutorizaciones.IdProfesor = AsignacionDeSinodal.$campo and firmarAutorizaciones.IdEstudiante = $id";
	$resultado = conexionMysql($consulta);
	
	if( mysql_num_rows($resultado) > 0 ) 
	{	
	
	echo "<td>"; echo replace(mysql_result($resultado, 0, 'Nombre')) ." ". replace(mysql_result($resultado, 0, 'Apellidos')); echo "</td>"; 
	echo "<td>"; 
	if ( mysql_result($resultado, 0, 'AprobacionRegistro') == true )
		echo "<label>SI</label>";
	else
		echo "<label>NO HA FIRMADO</label>";
	echo "</td>";
	
	echo "<td>";	 
	if ( mysql_result($resultado, 0, 'AprobacionTrabajo') == true )
		echo "<label>SI</label>";
	else
		echo "<label>NO HA FIRMADO</label>";
	echo "</td>";
	}
}	
	
	if( $idAlumno > 0 ) 
	{
		echo "<table border>";
			echo "<tr>";
				echo "<td><br></td>"; 
				echo "<th>"; echo "NOMBRE"; echo "</th>";
				echo "<th>"; echo "APROBÓ REGISTRO"; echo "</th>";
				echo "<th>"; echo "APROBÓ TRABAJO"; echo "</th>";
			echo "</tr>";
					
			echo "<tr>"; 
				echo "<th>"; echo "PRESIDENTE"; echo "</th>";
				generaTabla($idAlumno,'Presidente');				
			echo "</tr>";
			
			echo "<tr>"; echo "<th>";  echo "SECRETARIO"; echo "</th>";
				generaTabla($idAlumno,'Secretario');
			echo "</tr>";
			
			echo "<tr>"; 
				echo "<th>";  echo "VOCAL"; echo "</th>";
				generaTabla($idAlumno,'Vocal');
			echo "</tr>";
			
			echo "<tr>"; 
				echo "<th>"; echo "SUPLENTE"; echo "</th>";
				generaTabla($idAlumno,'Suplente');
				echo "</tr>";		
		echo "</table>";
	}	
								
								openConectionMysql();
								mysql_query("SET NAMES 'utf8'");
								$consulta = sprintf("SELECT * FROM Estudiante WHERE NumControl = $num_control");
								$resultado = mysql_query($consulta);
								$fila = mysql_fetch_assoc($resultado);
								$lugar_titulacion_replace = replace($fila['LugarDeCeremoniaDeTitulacion']);

								$consultaFirmasAutorizacionReg = "SELECT count(*) firmas FROM firmarAutorizaciones WHERE IdEstudiante = 
								$idAlumno AND AprobacionRegistro = true";
								$resFirmasAutorizacionReg = conexionMysql($consultaFirmasAutorizacionReg);
								$numFirmasReg = mysql_result($resFirmasAutorizacionReg, 0, 'firmas');

								$consultaFirmasAutorizacionTra = "SELECT count(*) firmas FROM firmarAutorizaciones WHERE IdEstudiante = 
								$idAlumno AND AprobacionTrabajo = true";
								$resFirmasAutorizacionTra = conexionMysql($consultaFirmasAutorizacionTra);
								$numFirmasTra = mysql_result($resFirmasAutorizacionTra, 0, 'firmas');
							?>
							<hr>
							<form name="form1" action="procesoTitulacionEstudiante.php" method="post" onsubmit="return validar()">
								<p class="text-black"><strong>Observaciones</strong></p>	
								<div class="top-margin">
									<input type="text" name="Observaciones" id="Observaciones" 
									value="<?php if ($fila['Observaciones'] == "1") {
											echo "Tienes observaciones en tu proyecto";
										}
										else {
											echo "No tienes observaciones en tu proyecto";
										} 
										?>" class="form-control-observaciones" readonly="readonly">
								</div>
								<br><br>
								<p class="text-black"><strong>Autorización del registro de tu proyecto 
									de titulación</strong></p>
								<div class="top-margin">
									<input type="text" name="AutorizacionDeRegistroTrabajoTitulacion" 
									id="AutorizacionDeRegistroTrabajoTitulacion" 
									value="<?php if ($numFirmasReg >= 3) {
											echo "Registro autorizado";
										}
										else {
											echo "En proceso de autorización";
										}
											?>" class="form-control-autorizacionTrabajoTitulacion" readonly="readonly">
								</div>
								<br><br>
								<p class="text-black"><strong>Autorización de tu proyecto de titulación</strong></p>	
								<div class="top-margin">
									<input type="text" name="Autorizado" id="Autorizado" 
									value="<?php if ($numFirmasTra == 4) {
											echo "Proyecto autorizado";
										}
										else {
											echo "En proceso de autorización";
										}
										?>" class="form-control-situacionproyecto" readonly="readonly">
								</div>
								<br>
								<div class="row top-margin">
									<div class="col-sm-6">
										<p class="text-black"><strong>Fecha de titulación</strong></p>
										<input type="text" name="FechaDeTitulacion" id="FechaDeTitulacion" 
										value="<?php echo $fila['FechaDeTitulacion'];?>" 
										class="form-control-fechatitulacion" readonly="readonly">
									</div>
								</div>
								<div class="top-margin">
									<p class="text-black"><strong>Lugar de la ceremonía de titulación</strong></p>
									<textarea name="LugarDeCeremoniaDeTitulacion" 
									id="LugarDeCeremoniaDeTitulacion" cols="40" rows="2" 
									class="form-control-lugartitulacion" readonly="readonly"><?php echo $lugar_titulacion_replace;?></textarea>
								</div>
							</form>
						</div>
					</div>
				</div>
			</article>
			<!-- /Article -->
		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">
		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
				<br>
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								ALGUNOS DERECHOS RESERVADOS &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
