
<?php

	error_reporting( E_WARNING | E_ERROR);

	include 'funciones.php';

	session_name('loginUsuario');
	session_start();
	
	
	$idAdmon = $_SESSION['id'];	
	
	function generaPuestos() 
{
 	echo "<SELECT name='puestos' id='puestos' onChange='cargaContenido(this.id)' class='form-control' >";
 	echo "<option value=''>Elige una categoria</option>";
 	echo "<option value='Estudiante'>Alumnos</option>";
 	echo "<option value='Profesor'>Profesores</option>";
 	echo "<option value='admons'>Mensaje a administradores</option>";
	echo "</SELECT>";
}
	
	function generaAlumnos() 
	{
			
		//lista muestra los alumnos registrados	
		//echo "<label>SELECCIONA UN ALUMNO PARA CREAR DOCUMENTO<label>";	
		echo "<select name='alumnos' id='alumnos' class='form-control' style='width:300;'>";
		echo "<option value='' selected='selected'>Selecciona un alumno</option>";
		//Formular la consulta
		$consulta = sprintf("SELECT Nombre,Apellidos,IdEstudiante FROM Estudiante");
		$resultado = conexionMysql($consulta);			
		while($fila = mysql_fetch_assoc($resultado))
		{
			
			$id= $fila['IdEstudiante'];
			echo "<option value=$id ";
				if( $_POST["alumnos"] == $id )
				{ 
				echo "selected='selected'"; 
				}
				echo ">";
			echo $fila['Nombre'] . " " . $fila['Apellidos'];
			echo "</option>";
		}
		echo "</select>";
		
		echo "<select name='profesores' id='profesores' onChange='block()' class='form-control' style='width:300;'>";
		echo "<option value='' selected='selected'>Selecciona un alumno</option>";
		//Formular la consulta
		$consulta = sprintf("SELECT Nombre,Apellidos,IdProfesor FROM Profesor");
		$resultado = conexionMysql($consulta);			
		while($fila = mysql_fetch_assoc($resultado))
		{
			
			$id= $fila['IdProfesor'];
			echo "<option value=$id ";
				if( $_POST["profesores"] == $id )
				{ 
				echo "selected='selected'"; 
				}
				echo ">";
			echo $fila['Nombre'] . " " . $fila['Apellidos'];
			echo "</option>";
		}
		echo "</select>";
		
		
	}
						

?>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Enviar | mensajes</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8" />	
		
	<link rel="stylesheet" type="text/css" href="select_dependientes.css">
	<script type="text/javascript" src="select_dependientesEnviarMensajesAdmon.js"></script>
	
	<script type="text/javascript">
	
		function validaForm()
		{	
			//valida la lista de alumnos
			if( document.getElementById('puestos').value == "" )
			{
				alert('Selecciona una opción.');
				document.envioMensajes.puestos.focus();
				return false;
				
			}
			if( document.getElementById('asunto').value.length > 0  )
			{
				var expresion = /^[0-9]*[a-zA-Z]*(\s*[0-9]*[a-zA-Z]*)*[a-zA-Z]*[0-9]*$/;
				var campo = document.getElementById('asunto').value ;
				if( !expresion.test(campo) )
				{
					alert('Contien caracteres no validos.');
					document.envioMensajes.asunto.focus();
					return false;
					
				}
			}
			else
			{
				alert('El campo asunto esta vacio.');
				document.envioMensajes.asunto.focus();
				return false;
			}
			
			if( document.getElementById('mensaje').value == "" )
			{
				alert("El campo mensaje esta vacio");
				document.envioMensajes.mensaje.focus();
				return false;
			}
			
			return true;			
		}	
	
	</script>
		
	</head>
	
	<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="active"><a class="btn" href="verMensajesCoordTitulacion.php">Bandeja de entrada</a></li>
					<li class="active"><a class="btn" href="perfilCoordTitulacion.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Profesor</a></li>
			<li class="active">Enviar mensajes</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Enviar mensajes</h1>
				</header>
				
				<div class="col-md-8 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
			
			<form name="envioMensajes" action="enviarMensajesCoordTitulacion.php" method="post" onsubmit="return validaForm()">
			
				<div id="demo" style="width:600px;">
					<div id="demoDer">
						<select disabled="disabled" name="Estudiantes" id="Estudiantes" class='form-control'>
							<option value="0">Selecciona opci&oacute;n...</option>
						</select>
					</div>
					<div id="demoIzq"><?php generaPuestos(); ?></div>
				</div>
				
				<label>ASUNTO</label><br>
				<input type="text" name="asunto" id="asunto" class='form-control' style='width:300;'/><br>
				<label>Escribe el mensaje</label><br>
				<textarea name="mensaje" id="mensaje" cols="100" rows="5"class='form-control' ></textarea><br>
				<input type="submit" name="enviar_mensaje" value="Enviar mensaje" class='btn btn-danger centrar-boton'/>
			
			</form>

<?php

	if( isset($_POST['enviar_mensaje']) ) 
	{
		session_name("loginUsuario");
		session_start();	
		
		$tabla = $_SESSION['tabla'];
		$idAdmon = $_SESSION['id'];
		
		openConectionMysql();
		$mysqli = conexionMysqli();	
		
		//echo "Insercion en proceso"; echo "<br>";
		$asunto = strip_tags($_POST['asunto']);
		$asunto = $mysqli->real_escape_string(htmlspecialchars($asunto));
		$asunto = htmlentities($asunto);
		echo "<br>";
		//limpieza de datos de entrada 
		$mensaje = strip_tags($_POST['mensaje']);
		$mensaje = $mysqli->real_escape_string(htmlspecialchars($mensaje));
		$mensaje = htmlentities($mensaje);
		$idEstudiante = $_POST['Estudiantes'];echo "<br>";
		$fecha_hora = date("Y-m-d H:i:s");
		
		if(  $tabla == 'Estudiante' ) 
		{
			$insercion = "INSERT INTO MensajesAlumno(IdCoordTitulacion,IdEstudiante,mensaje,asunto,visto,fechaHora)values('$idAdmon','$idEstudiante','$mensaje','$asunto',false,'$fecha_hora')";
		
			$respuesta = mysql_query($insercion);
			if( $respuesta )
				echo "<p class='text-black3'>Mensaje enviado exitosamente.</p>";
			else
				echo "<p class='text-black3'>No se logro enviar el mensaje.</p>";
		}
		
		if(  $tabla == 'Profesor' ) 
		{
			$insercion = "INSERT INTO MensajesProfesor(IdCoordTitulacion,IdProfesor,mensaje,asunto,visto,fechaHora)values('$idAdmon','$idEstudiante','$mensaje','$asunto',false,'$fecha_hora')";
		
			$respuesta = mysql_query($insercion);
			if( $respuesta )
				echo "<p class='text-black3'>Mensaje enviado exitosamente.</p>";
			else
				echo "<p class='text-black3'>No se logro enviar el mensaje.</p>";
		}
		 
		if(  $tabla == 'Administrador' ) 
		{
			if( $idEstudiante == 'admon1' ) 
			{			
				$insercion = "INSERT INTO MensajesAdministrador(IdAdmon,IdCoordTitulacion,mensaje,asunto,visto,fechaHora)values('1','$idAdmon','$mensaje','$asunto',false,'$fecha_hora')";
		
				$respuesta = mysql_query($insercion);
				if( $respuesta )
					echo "<p class='text-black3'>Mensaje enviado exitosamente.</p>";
				else
					echo "<p class='text-black3'>No se logro enviar el mensaje.</p>";
			}
			else 
			{
				$insercion = "INSERT INTO MensajesCoordTitulacion(IdCoordTitulacion,IdAdmon,mensaje,asunto,visto,fechaHora)values(2,'$idAdmon','$mensaje','$asunto',false,'$fecha_hora')";
				$respuesta = mysql_query($insercion);
				if( $respuesta )
					echo "<p class='text-black3'>Mensaje enviado exitosamente.</p>";
				else
					echo "<p class='text-black3'>No se logro enviar el mensaje.</p>";
			}
		}	
	}
?>


</div>
					</div>
				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
								
								
								
								
