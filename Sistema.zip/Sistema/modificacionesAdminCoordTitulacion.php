<?php include 'seguridadCoordTitulacion.php'; ?>
<?php include 'funciones.php'; ?>

<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Modificaciones | adminCoordTitulacion</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">

	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
	<script src="md5.js"></script>

	<script type="text/javascript">
		function habilitar() {
			document.form1.Nombre.disabled = !document.form1.Nombre.disabled;
			document.form1.Apellidos.disabled = !document.form1.Apellidos.disabled;
		}
		function habilitar2() {
			document.form1.ClaveDeAccesoActual.disabled = !document.form1.ClaveDeAccesoActual.disabled;
			document.form1.ClaveDeAccesoNueva.disabled = !document.form1.ClaveDeAccesoNueva.disabled;
		}
		function habilitar3() {
			document.form1.Sexo.disabled = !document.form1.Sexo.disabled;
		}
		function soloLetras(e) {
    		tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==32) { // espacio
				return true; 
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[a-zA-Z]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function claveDeAcceso(e) {
			tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==190) { //punto
				return false;
			}
			if (tecla==32) { // espacio
				return false; 
			}
			if (tecla==60) { // <
				return false;
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==189) { // guión
				return true;
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (tecla==0) { // ¿
				return false;
			}
			if (e.shiftKey && tecla==49 /* ! */ || e.shiftKey && tecla==50 /* "" */ ||  
				e.shiftKey && tecla==54 /* & */ || e.shiftKey && tecla==55 /* / */ || 
				e.shiftKey && tecla==56 /* ( */ || e.shiftKey && tecla==57 /* ) */ || 
				e.shiftKey && tecla==48 /* = */ || e.shiftKey && tecla==186 /* ; */ || 
				e.shiftKey && tecla==191 /* ? */ || e.shiftKey && tecla==192 /* ¨ */ || 
				e.shiftKey && tecla==219 /* [ */ || e.shiftKey && tecla==220 /* | */ || 
				e.shiftKey && tecla==221 /* ] */ || e.shiftKey && tecla==222 /* '' */ || 
				e.shiftKey && tecla==187 /* * */ || e.shiftKey && tecla==60 /* > */ ||
				e.shiftKey && tecla==0 /* ¡ */ || e.shiftKey && tecla==171 /* * */ ||
				e.shiftKey && tecla==174 /* [ */ || e.shiftKey && tecla==175 /* ] */) {
				return false;
			} 
			if (e.shiftKey && tecla==51 /* # */ || e.shiftKey && tecla==52 /* $ */ ||
				e.shiftKey && tecla==53 /* % */ || e.shiftKey && tecla==189 /* _ */ ) {
				return true;
			}
			if (tecla==187 || tecla==188 || tecla==191 || tecla==192 || tecla==219 || tecla==220 || 
				tecla==221 || tecla==222 || tecla==171 /* + */ || tecla==174 /* { */ || tecla==175 /* } */) {
				return false;
			}
			if (e.altGraphKey && tecla==81) { // @
				return true;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[0-9a-zA-Z\W]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function validar(form1) {
			if (document.form1.ModificarNombre.checked != true && document.form1.ModificarClaveDeAcceso.checked != true && document.form1.ModificarSexo.checked != true) {
				alert("Imposible guardar cambios. No se ha habilitado la opción 'Modificar nombre' o la opción 'Modificar contraseña' o la opción 'Modificar sexo'");
				return false;
			}
			else {
				if (document.form1.ModificarNombre.checked == true) {
					if (document.form1.Nombre.value == "" || document.form1.Apellidos.value == "") {
						alert("Imposible guardar. Tiene campos vacíos");
						return false;
					}
				}
				if (document.form1.ModificarClaveDeAcceso.checked == true) {
					if (document.form1.ClaveDeAccesoActual.value == "" || document.form1.ClaveDeAccesoNueva.value == "") {
						alert("Imposible guardar. Tiene campos vacíos");
						return false;
					}
					else {
						//SE VALIDA LA CONTRASEÑA
						var cadena = document.form1.ClaveDeAccesoNueva.value;
						var numcaracteres = cadena.length;
						var espacio = " ";
						if (cadena.indexOf(espacio) > -1) {
							alert("La contraseña no debe contener espacios en blanco");
							return false;
						}
						else {
							if (numcaracteres < 8) {
								alert("La contraseña es corta");
								return false;
							}
							else {
								if (!(cadena.match(/\d/))) {
     								alert("La contraseña debe contener al menos un número");
     								return false;
								}
								if (!(cadena.match(/\W+/))) {
									alert("La contraseña debe de contener al menos un caracter especial");
									return false;
								}
								var md5_clave_actual = hex_md5(document.form1.ClaveDeAccesoActual.value);
								document.form1.ClaveDeAccesoActual.value = md5_clave_actual;
								var md5_clave_nueva = hex_md5(document.form1.ClaveDeAccesoNueva.value);
								document.form1.ClaveDeAccesoNueva.value = md5_clave_nueva;
							}
						}
					}
				}
			}
		}
	</script>
</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="#"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Estudiantes <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="estudiantesautorizados.php">Estudiantes autorizados</a></li>
						</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrador<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="modificacionesAdminCoordTitulacion.php">Modificaciones</a></li>
						</ul>
					</li>
					
					<?php
					
					$consulta = "select count(*) as MensajesNuevos from MensajesCoordTitulacion where visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					?>
					<li class="active3"><a class="btn" href="verMensajesCoordTitulacion.php"><?php echo $mensajes ?> Mensaje(s)</a></li>
					<?php
					}
					else
						echo '<li class="active"><a class="btn" href="verMensajesCoordTitulacion.php">Mensajeria</a></li>';
					?>
					<li class="active"><a class="btn" href="perfilCoordTitulacion.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
					
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Modificaciones</h1>
				</header>
				
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h2 class="thin text-center">Modificaciones que puede realizar</h2>
							<br>
							<?php
								function replace($cadena) {
									$cadena = str_replace("&AACUTE;", "Á", $cadena);
									$cadena = str_replace("&EACUTE;", "É", $cadena);
									$cadena = str_replace("&IACUTE;", "Í", $cadena);
									$cadena = str_replace("&OACUTE;", "Ó", $cadena);
									$cadena = str_replace("&UACUTE;", "Ú", $cadena);
									$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
									$cadena = str_replace("&aacute;", "á", $cadena);
									$cadena = str_replace("&eacute;", "é", $cadena);
									$cadena = str_replace("&iacute;", "í", $cadena);
									$cadena = str_replace("&oacute;", "ó", $cadena);
									$cadena = str_replace("&uacute;", "ú", $cadena);
									$cadena = str_replace("&ntilde;", "ñ", $cadena);
									return $cadena;
								}
								session_name("loginUsuario");
								session_start();
								$id = $_SESSION["id"];
								//$mysqli = new mysqli('localhost','root','samushomysql123');
								$mysqli = conexionMysqli();
								
								openConectionMysql();
								mysql_query("SET NAMES 'utf8'");
								$consulta = sprintf("SELECT * FROM Administrador WHERE IdAdministrador = $id");
								$resultado = mysql_query($consulta);
								$fila = mysql_fetch_assoc($resultado);

								$nombre_replace = replace($fila['Nombre']);
								$apellidos_replace = replace($fila['Apellidos']);

								if (isset($_POST['guardar_cambios'])) {
									$modificar_nombre = $_POST['ModificarNombre'];
									$modificar_clave = $_POST['ModificarClaveDeAcceso'];
									$modificar_sexo = $_POST['ModificarSexo'];

									if ($modificar_nombre != true && $modificar_clave != true && $modificar_sexo != true) {
										echo "<p class='text-center text-black2'>Imposible guardar. No se ha habilitado la opción 'Modificar nombre' o la opción 'Modificar contraseña o la opción 'Modificar sexo'</p>";
									}
									else {
										if ($modificar_nombre == true) {
											if (empty($_POST['Nombre']) || empty($_POST['Apellidos'])) {
												echo "<p class='text-center text-black2'>Imposible guardar.<br>El campo nombre está vacío</p>";
											}
											else {
												$nombre = $mysqli->real_escape_string(htmlspecialchars($_POST['Nombre']));
												$nombre = htmlentities($nombre);
												if (ctype_upper($nombre) != true) {
													$nombre = strtr(strtoupper($nombre),
													"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
												}
												$apellidos = $mysqli->real_escape_string(htmlspecialchars($_POST['Apellidos']));
												$apellidos = htmlentities($apellidos);
												if (ctype_upper($apellidos) != true) {
													$apellidos = strtr(strtoupper($apellidos),
													"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
												}
												openConectionMysql();
												mysql_query("SET NAMES 'utf8'");
												$queryUpdateNombre = "UPDATE Administrador SET Nombre = '$nombre', Apellidos = '$apellidos' WHERE IdAdministrador = '$id'";
												if (mysql_query($queryUpdateNombre)) {
													echo "<p class='text-center text-black2'>Se ha modificado correctamente el nombre</p>";
												}
												else {
													echo "<p class='text-center text-black2'>Error al guardar<br>Vuelva a intentarlo</p>";
												}
											}
										}
										if ($modificar_sexo == true) {
											$sexo = $_POST['Sexo'];
											openConectionMysql();
											$queryUpdateSexo = "UPDATE Administrador SET Sexo = '$sexo' WHERE IdAdministrador = '$id'";
											if (mysql_query($queryUpdateSexo)) {
												echo "<p class='text-center text-black2'>Se ha modificado correctamente el sexo</p>";
											}
											else {
												echo "<p class='text-center text-black2'>Error al guardar<br>Vuelva a intentarlo</p>";
											}
										}
										if ($modificar_clave == true) {
											if (empty($_POST['ClaveDeAccesoActual']) || empty($_POST['ClaveDeAccesoNueva'])) {
												echo "<p class='text-center text-black2'>Imposible guardar.<br>Tiene campos vacíos al actualizar contraseña</p>";
											}
											else {
												$clave_actual = $_POST['ClaveDeAccesoActual'];
												$clave_nueva = $_POST['ClaveDeAccesoNueva'];
												$consultaClaveAcceso = "SELECT ClaveDeAcceso FROM Administrador WHERE IdAdministrador = 2";
												$resultadoClaveAcceso = conexionMysql($consultaClaveAcceso);
												$clave = mysql_result($resultadoClaveAcceso,0,'ClaveDeAcceso');

												if (strcmp($clave_actual, $clave) != 0) {
													$error = true;
													echo "<p class='text-center text-black2'>La contraseña actual no es correcta</p>";
												}
												else {
													if (strcmp($clave_actual, $clave_nueva) == 0) {
														$error = true;
														echo "<p class='text-center text-black2'>No puede proporcionar la misma contraseña</p>";
													}
													else {
														if ($error != true) {
															openConectionMysql();
															mysql_query("SET NAMES 'utf8'");
															$queryUpdateClave = "UPDATE Administrador SET ClaveDeAcceso = '$clave_nueva' WHERE IdAdministrador = 2 AND ClaveDeAcceso = '$clave'";
															if (mysql_query($queryUpdateClave)) {
																echo "<p class='text-center text-black2'>Se ha modificado correctamente la contraseña</p>";
															}
															else {
																echo "<p class='text-center text-black2'>Error al guardar<br>Vuelva a intentarlo</p>";
															}
														}
													}
												}
											}
										}
									}
								}
							?>
							<hr>
							<h3 class="thin text-center">Nombre y sexo del administrador de la Coordinación de titulación</h3>
							<br>
							<p class="text-center text-muted">Si desea cambiar el nombre del administrador<br>seleccione la opción <strong>"Modificar nombre"</strong>,<br>después proporcione el nuevo nombre y<br> de clic en <strong>"Guardar cambios"</strong>
							</p>
							<br>
							<form name="form1" action="modificacionesAdminCoordTitulacion.php" method="post" onsubmit="return validar()">
								<div class="top-margin centrar-checks2">
									<label>Modificar nombre</label>
										<input type="checkbox" name="ModificarNombre" id="ModificarNombre" value="1" onclick="return habilitar()" class="checks centrar-checks2">
								</div>
								<div class="top-margin">
									<label>Nombre</label>
									<input type="text" name="Nombre" value="<?php echo $nombre_replace;?>" class="form-control-nombreadmin" onkeypress="return soloLetras(event);" disabled>
								</div>
								<div class="top-margin">
									<label>Apellidos<span class="text-danger">*</span></label>
									<input type="text" name="Apellidos" value="<?php echo $apellidos_replace;?>" class="form-control-apellidosadmin" onkeypress="return soloLetras(event);" disabled>
								</div>
								<div class="top-margin">
									<label>Sexo</label>
									<input type="text" name="Sexo2" value="<?php echo $fila['Sexo'];?>" class="form-control-sexo-adminCoordTitulacion" onkeypress="return soloLetras(event);" disabled>
								</div>
								<br>
								<p class="text-center text-muted">Si desea cambiar el sexo seleccione la opción<br><strong>"Modificar sexo" </strong>y elija su opción
								</p>
								<div class="top-margin centrar-checks2">
									<label>Modificar sexo</label>
										<input type="checkbox" name="ModificarSexo" id="ModificarSexo" value="1" onclick="return habilitar3()" class="checks centrar-checks2">
								</div>
								<div class="top-margin">
									<label>Sexo<span class="text-danger">*</span></label>
									<select name="Sexo" class="form-control-sexo-adminCoordTitulacion" disabled>
										<option value="masculino">Masculino</option>
										<option value="femenino">Femenino</option>
									</select>
								</div>
								<hr>
								<h3 class="thin text-center">Contraseña</h3>
								<br>
								<p class="text-center text-muted">Si desea cambiar la contraseña seleccione la opción<br><strong>"Modificar contraseña"</strong>, después proporcione<br>la contraseña actual y la nueva y de clic<br><strong>en "Guardar cambios"</strong></p>
								<br>
								<div class="top-margin centrar-checks3">
									<label>Modificar contraseña</label>
										<input type="checkbox" name="ModificarClaveDeAcceso" id="ModificarClaveDeAcceso" value="1" onclick="return habilitar2()" class="checks centrar-checks3">
								</div>
								<br>
								<div class="row top-margin">
									<div class="col-sm-6">
										<label class="etiqueta-claveacceso-actual">Contraseña actual <span class="text-danger">*</span></label>
										<input type="password" name="ClaveDeAccesoActual" value="" class="form-control-claveaccesoadmin-actual" onkeydown="return claveDeAcceso(event);" disabled>
									</div>
									<div class="col-sm-6">
										<label class="etiqueta-claveacceso-nueva">Contraseña nueva <span class="text-danger">*</span></label>
										<input type="password" name="ClaveDeAccesoNueva" value="" class="form-control-claveaccesoadmin-nueva" onkeydown="return claveDeAcceso(event);" disabled>
									</div>
								</div>
								<hr>
								<div class="top-margin">
									<div class="col-lg-4 boton-guardar-estudiantesregistrados">
										<button class="btn btn-danger" type="submit" name="guardar_cambios" onclick="">Guardar cambios</button>
									</div>
								</div>	
							</form>
						</div>
					</div>
				</div>
			</article>
			<!-- /Article -->
		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">
		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
				<br>
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								ALGUNOS DERECHOS RESERVADOS &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
</body>
</html>
