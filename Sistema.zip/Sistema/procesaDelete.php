<?php
	
include 'funciones.php';

//error_reporting( E_WARNING | E_ERROR);

function generaTablaMensajes($id) 
{
	//mostrar mensajes										 
	$consulta="SELECT visto,IdMensaje,Estudiante.IdEstudiante user,Profesor.Nombre profesor,Profesor.Apellidos apellidosp,Estudiante.Nombre estudiante,Estudiante.Apellidos apellidose,mensaje,DATE_FORMAT(fechaHora,'%d/%m/%Y a las %H:%i') fechaHora, asunto FROM Profesor,MensajesAlumno,Estudiante WHERE MensajesAlumno.IdProfesor = Profesor.IdProfesor and MensajesAlumno.IdEstudiante = Estudiante.IdEstudiante and MensajesAlumno.IdEstudiante = $id";
	
	$consulta2 = "SELECT visto,IdMensaje,Estudiante.IdEstudiante user,Administrador.Nombre profesor,Estudiante.Nombre estudiante,Estudiante.Apellidos apellidose,mensaje,DATE_FORMAT(fechaHora,'%d/%m/%Y a las %H:%i') fechaHora, asunto FROM Administrador,MensajesAlumno,Estudiante WHERE MensajesAlumno.IdAdmon = Administrador.IdAdministrador and MensajesAlumno.IdEstudiante = Estudiante.IdEstudiante and MensajesAlumno.IdEstudiante = $id";
										
	$resultado = conexionMysql($consulta);
	$resultado2 = conexionMysql($consulta2);
		
	//TABLA A MOSTRAR DE ALUMNOS
	echo "<div id='iframe'>";
	echo "<table width='100%' border='0' align='center' cellpadding='4' cellspacing='0'>";
	
	if( mysql_num_rows($resultado) > 0 ) 
	{
	echo "<tr><td colspan='4'><label>Mensajes de profesores.</label></td></tr>";	
		$bgcolorVisto = "'#d0e7ff' style='border-right:1px solid #cccccc;'";
		$bgcolorNoVisto =	"'#FFFF99' style='border-right:1px solid #cccccc;'";		
			
		while($fila = mysql_fetch_assoc($resultado)) 
		{
			$usuario = $fila['user'];
			$mensaje =$fila['IdMensaje'];
					
		echo "<tr>";
			echo "<td bgcolor=";
			if( $fila['visto'] == true ){ 
			echo $bgcolorVisto;}
			else {
			echo $bgcolorNoVisto;} echo ">"; echo "<input type='checkbox' name='eliminar[]' id='eliminar[]' value='$mensaje+1'><label>&nbsp Eliminar</label>"; echo "</td>";
			echo "<td bgcolor=";
			if( $fila['visto'] == true ){ 
			echo $bgcolorVisto;}
			else {
			echo $bgcolorNoVisto;} echo ">"; echo $fila['fechaHora']; echo "</td>";
			echo "<td bgcolor=";
			if( $fila['visto'] == true ){ 
			echo $bgcolorVisto;}
			else {
			echo $bgcolorNoVisto;} echo ">"; echo $fila['profesor']." ".$fila['apellidosp']; echo "</td>";
			echo "<td bgcolor=";
			if( $fila['visto'] == true ){ 
			echo $bgcolorVisto;}
			else {
			echo $bgcolorNoVisto;} echo ">"; echo "<a href='visorMensajesAlumno.php?user=$usuario&message=$mensaje'>"; echo $fila['asunto']; echo "</a>"; echo "</td>";
		echo "</tr>";
		}
			
	}
	else 
		{
			echo "<label>Aun no tienes mensajes de profesores.</label>";			
		}
	if( mysql_num_rows($resultado2) > 0 ) 
	{	
		echo "<tr><td colspan='4'><label>Mensajes del administrador</label></td></tr>";
		$bgcolorVisto = "'#d0e7ff' style='border-right:1px solid #cccccc;'";
		$bgcolorNoVisto =	"'#FFFF99' style='border-right:1px solid #cccccc;'";			
			
			while($fila = mysql_fetch_assoc($resultado2)) 
			{
				$usuario = $fila['user'];
				$mensaje =$fila['IdMensaje'];
				
				echo "<tr>";
				echo "<td bgcolor=";
				if( $fila['visto'] == true ){ 
				echo $bgcolorVisto;}
				else {
				echo $bgcolorNoVisto;} echo ">"; echo "<input type='checkbox' name='eliminar[]' id='eliminar[]'  value='$mensaje+1'><label>&nbsp Eliminar</label>"; echo "</td>";
				echo "<td bgcolor=";
				if( $fila['visto'] == true ){ 
				echo $bgcolorVisto;}
				else {
				echo $bgcolorNoVisto;} echo ">"; echo $fila['fechaHora']; echo "</td>";
				
				echo "<td bgcolor=";
				if( $fila['visto'] == true ){ 
				echo $bgcolorVisto;}
				else {
				echo $bgcolorNoVisto;} echo ">"; echo $fila['profesor']; echo "</td>";
	
				echo "<td bgcolor=";
				if( $fila['visto'] == true ){ 
				echo $bgcolorVisto;}
				else {
				echo $bgcolorNoVisto;} echo ">"; echo "<a href='visorMensajesAlumno.php?user=$usuario&message=$mensaje'>"; echo $fila['asunto']; echo "</a>"; echo "</td>";
			echo "</tr>";
			}
		}
		else 
		{
			echo "<label>Aun no tienes mensajes del administrador.</label>";			
		}
		echo "</table>";
		echo "</div>";
	}
	
	
	session_name('loginUsuario');
	session_start();	
	
	$id = $_SESSION["id"];
	
	$eliminar = count($_POST['id']);

	//$nombre = $_POST['id'];
	echo $eliminar;
	//echo $nombre;

	//echo '<div id="datos">';
	echo "<form>";
		generaTablaMensajes($id);
	echo	'<input type="text" name="nombre" id="nombre" />';
	echo '<input type="submit" value="enviar" onclick="mostrarInfo(); return false" >';
	echo "</form>";
	//echo "</div>";
	
	//eliminar = $_POST['id'];
	//$nombre = $_POST['id'];
	//echo $eliminar[0];
	//echo $nombre;
	
	/*
	if( !empty( $eliminar ) ) 
	{
		foreach( $eliminar as $m)
		{
			echo $m; echo "<br>";
		}
	}
	
	
	
	//$nombre = $_POST['id'];
	//echo $nombre[0];
	

	/*
	echo "<form >";
		echo "<table>";
			echo '<input type="text" name="nombre" id="nombre" />';
			echo "<tr><td>OSVALDO MUÑOZ VENCES</td></tr>";
			echo " </table>";
			echo '<input type="submit" value="enviar" onclick="mostrarInfo(); return false" >';
			echo "</form>";
	echo $nombre = $_POST['id'];
	*/
	
	
?>
