
<?php

include('ftpfunc.php'); //Incluye el archivo de funciones

error_reporting( E_ERROR );


function upload()
{
	if(!empty($_FILES["archivo"]))
	{
		$file = $_FILES["archivo"]["tmp_name"];
		$base_archivo = basename($_FILES["archivo"]["name"]);
		$id_ftp=ConectarFTP();
		$upload = ftp_put($id_ftp, $base_archivo, $file, FTP_BINARY);
		if (!$upload) 
		{
			echo $status = "<div class='mensaje'><font color='red' size='5'>Error al guardar " . $base_archivo."</font></div>";
		}
		else 
		{
			echo $status = "<div class='mensaje'><font COLOR='red' size='5'>Éxito al guardar: " . $base_archivo."</font></div>";
		}
		unset($_FILES["archivo"]);
		ftp_quit($id_ftp);
	}
	
	if( !is_null( $status ))
	{
		//$status;
	}
	?>
	<!--Formulario para elejir el archivo a subir -->
	<br>
	<form action="" method="post" name="form_ftp" id="form_ftp" enctype="multipart/form-data">
		
			<font size="3" face="Verdana, Tahoma, Arial">
				<input type="file" name="archivo" id="archivo" / ><br>
				<input name="Submit" type="submit" value="Subir Archivo" class="btn btn-danger"/>
			</font> 
		
	</form>
	<?php	
}
	?>

<html lang="es">
<head>

	<!--hoja de estilo para un iframe-->
	
	<style type="text/css">
		#iframe
    	{
    		overflow:auto;
    		width:700px;
    		height:200px;
    	}
    	
    	div.mensaje
    	{
    		position:absolute; top:10px; left:30px;
			width: 1080px;
			padding: 5px;
			border: solid 4px red;;
			color: red;		
    	}
	</style>
	
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Actualizar | plantillas</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
		  	
			
			</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Estudiantes <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="estudiantesregistrados.php">Estudiantes registrados</a></li>
							<li><a href="asignarSinodal.php">Asignar Revisores</a></li>
							<li><a href="listaAlumnos.php">Crear Documentos</a></li>
							<li><a href="cambioJurado.php">Cambio de jurado</a></li>
							<li><a href="cambioTema.php">Cambio de tema de tesis</a></li>
							<li><a href="bitacora2.php">Bitácora</a></li>
							</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Profesores <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="consultarFirmas.php">Firmas Registradas</a></li>							
							<li><a href="profesoresregistrados.php">Profesores registrados</a></li>
							<li><a href="firmasOficina.php">Firmas de liberacion</a></li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrador<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="modificacionesAdministrador.php">Modificaciones</a></li>
							<li><a href="actualizarPlantillas.php">Actualizar plantillas</a></li>
							<li><a href="archivosSubidos.php">Ver plantillas actualizadas</a></li>
							<li><a href="descomprimeZip.php">Descomprimir archivos ZIP</a></li>
						</ul>
					</li>
					
					<?php
					include "funciones.php";
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAdministrador where visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					?>
					<li class="active3"><a class="btn" href="verMensajesAdmon.php"><?php echo $mensajes ?> Mensaje(s)</a></li>
					<?php
					}
					else
						echo '<li class="active"><a class="btn" href="verMensajesAdmon.php">Mensajeria</a></li>';
					?>
				
					<li class="active"><a class="btn" href="perfiladministrador.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Administrador</a></li>
			<li class="active">Actualizar plantillas</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Actualizar plantillas</h1>
				</header>
				
				<div class="col-md-12 col-md-offset-0 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body"><br><br><br><br>		
		<p>
			<font size="5" ><label>Para actualizar las plantillas del servidor siga las siguientes instrucciones:</label></font>
		</p>
		<p>
			<font size="4" ><label>Descargue el archivo donde se encuentran los identificadores para configurar las plantillas nuevas.<a href="descargaArchivo.php?doc=identificadores.docx" >Click aquí para descargar los Identificadores.</a></label></font>
		</p>
		<p>
			<font size="4" ><label>Selecciona el pdf de muestra de la plantilla a actualizar. Utiliza los identificadores que descargaste para reemplazarlos en los lugares que indica el pdf de muestra.</label></font>
		</p>
		<p>
			<font size="4" ><label>Puedes subir archivos individuales o seleccionar todos los archivos click derecho comprimir con ZIP y subir el archivo comprimido. Nota comprimir solamente con ZIP, no crear una carpeta y arrastrar los archivos, siga las instrucciones del párrafo anterior.</label></font>
		</p>
		<center>
		<p>
			<font size="4" ><label>DOCUMENTOS</label></font>
		</p>
		</center>
			<center>
				<table cellspacing="8">
					<!------------------------------------------------------------------>
					<!--------------------- Opción 6, 8 y 9 de titulación -------------->
					<!------------------------------------------------------------------>
					<tr>
						<td colspan="2"><center><label>Opción 6, 8 y 9 de titulación</label></center></td>
					</tr>
					<tr>	
						<td><label>Asignacion_de_Jurados_opc_6_(Egel),_8_y_9_-_división.docx</label></td>
						<td><label><A HREF="pdf/Asignacion_de_Jurados_opc_6_(Egel),_8_y_9_-_división.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>
					</tr>
					<tr>
						<td>&nbsp</td>
					</tr>
					<!------------------------------------------------------------------>
					<!--------------------- Opción 7 de titulación --------------------->
					<!------------------------------------------------------------------>
					<tr>
						<td colspan="2"><center><label>Opción 7 de titulación</label></center></td>
					</tr>
					<tr>
						<td><label>Paso_1_.-Asignacion_Asesor_Memoria_Experiencia_Profesional.docx</label></td>
						<td><label><A HREF="pdf/Paso_1_.-Asignacion_Asesor_Memoria_Experiencia_Profesional.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_2_.- Asignacion_y_Comision_Revisores_-_depto.docx</label></td>
						<td><label><A HREF="pdf/Paso_2_.- Asignacion_y_Comision_Revisores_-_depto.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_3_.-Autorizacion_Registro_-_depto.docx</label></td>
						<td><label><A HREF="pdf/Paso_3_.-Autorizacion_Registro_-_depto.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_4_.-_Se_Autoriza_Registro_de_opcion_-_división.docx</label></td>
						<td><label><A HREF="pdf/Paso_4_.-_Se_Autoriza_Registro_de_opcion_-_división.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_5_.-Solicitud_autorizacion_impresion_-_división.docx</label></td>
						<td><label><A HREF="pdf/Paso_5_.-Solicitud_autorizacion_impresion_-_división.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td>&nbsp</td>
					</tr>
					<!------------------------------------------------------------------>
					<!--------------------- Opción X de titulación --------------------->
					<!------------------------------------------------------------------>
					<tr>
						<td colspan="2"><center><label>Opción X de titulación</label></center></td>
					</tr>
					<tr>
						<td><label>Paso_1_.-_Asignacion_y_Comision_Revisores_-_depto.docx</label></td>
						<td><label><A HREF="pdf/Paso_1_.-_Asignacion_y_Comision_Revisores_-_depto.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_2_.-Autorizacion_Registro_-_depto.docx</label></td>
						<td><label><A HREF="pdf/Paso_2_.-Autorizacion_Registro_-_depto.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_3_.-_Se_Autoriza_Registro_de_opcion_-_división.docx</label></td>
						<td><label><A HREF="pdf/Paso_3_.-_Se_Autoriza_Registro_de_opcion_-_división.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_4_.-Solicitud_autorizacion_impresion_-_división.docx</label></td>
						<td><label><A HREF="pdf/Paso_4_.-Solicitud_autorizacion_impresion_-_división.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td>&nbsp</td>
					</tr>
					<!-------------------------------------------------------------------------->
					<!--------------------- Opción ITRP 2010 de titulación --------------------->
					<!-------------------------------------------------------------------------->
					<tr>
						<td colspan="2"><center><label>Opción ITRP 2010 de titulación</label></center></td>
					</tr>
					<tr>
						<td><label>Paso_1_.-Asignacion_y_Comision_Revisores_-_depto_-_producto.docx</label></td>
						<td><label><A HREF="pdf/Paso_1_.-Asignacion_y_Comision_Revisores_-_depto_-_producto.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_2_.-Autorizacion_Registro_-_depto_-_producto.docx</label></td>
						<td><label><A HREF="pdf/Paso_2_.-Autorizacion_Registro_-_depto_-_producto.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_3_.-Proyecto_Titulacion_Integral_-_Registro.docx</label></td>
						<td><label><A HREF="pdf/Paso_3_.-Proyecto_Titulacion_Integral_-_Registro.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_4_.-Proyecto_Titulacion_Integral_-_Liberacion_sin_cedula.docx</label></td>
						<td><label><A HREF="pdf/Paso_4_.-Proyecto_Titulacion_Integral_-_Liberacion_sin_cedula.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					<tr>
						<td><label>Paso_5_.-Asignacion_de_Jurados_Titulacion_Integral.docx</label></td>
						<td><label><A HREF="pdf/Paso_5_.-Asignacion_de_Jurados_Titulacion_Integral.pdf" TARGET="Ventana-2" >PDF muestra</a></label></td>	
					</tr>
					
					<tr><td colspan="2"></td></tr>
				</table>
				<?php upload() ?>
								
			</center>
				
</div>
					</div>
				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
