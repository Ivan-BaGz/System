
<?php
	include "funciones.php";
	
function limpiaOpcionTitulacion()
{
	$consulta = sprintf("SELECT OpcionDeTitulacion FROM Estudiante WHERE IdEstudiante = 1 ");
	$resultado = conexionMysql($consulta);
	
	$opcion = mysql_result($resultado,0,'OpcionDeTitulacion');
	
	$palabras = str_split($opcion); //convertir en arreglo la cadena
	//variables auxiliares
	$str = "";
	$listo = 0;
	
	if( $palabras[count($palabras)-1] == ")"  ) //tiene números romanos y parentesis hay que quitarlos 
	{
		for( $i = 0; $i < count($palabras); $i++ ) 
		{
			if( $palabras[$i] == "(" )	//obtener la cadena sin Num. romanos ni parentesis 
				$listo = 1;

			if( $listo == 1 )
			{ 
				if( $palabras[$i+1] == ")" ) //encontrar parentesis de cierre para no obtener un índice fuera del rango del arreglo
					$listo = 0;
			}			
			
			if( $listo == 1 )
				$str .= $palabras[$i+1]; 
						
		}
		return $str;
	}
	else
		return $opcion;
}

echo limpiaOpcionTitulacion();
	
?>
