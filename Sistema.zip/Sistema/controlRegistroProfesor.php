<?php
	//funciones
	include 'funciones.php';		
	error_reporting( E_WARNING | E_ERROR );
	//$mysqli = new mysqli('localhost','root','samushomysql123');
	$mysqli = conexionMysqli();

							
	if (isset($_POST['crear_cuenta'])) {
		if (empty($_POST['NumTargeta'])) {
			$error = true;
			header("Location: registroprofesor.php?vacio=si");
		}
		else {
			$num_targeta = $_POST['NumTargeta'];
		}
		if (empty($_POST['Nombre'])) {
			$error = true;
			header("Location: registroprofesor.php?vacio=si");
		}
		else {
			$nombre = $mysqli->real_escape_string(htmlspecialchars($_POST['Nombre']));
			$nombre = htmlentities($nombre);
			if (ctype_upper($nombre) != true) {
				$nombre = strtr(strtoupper($nombre),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
			}
		}
		if (empty($_POST['Apellidos'])) {
			$error = true;
			header("Location: registroprofesor.php?vacio=si");
		}
		else {
			$apellidos = $mysqli->real_escape_string(htmlspecialchars($_POST['Apellidos']));
			$apellidos = htmlentities($apellidos);
			if (ctype_upper($apellidos) != true) {
				$apellidos = strtr(strtoupper($apellidos),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
			}
		}
		$sexo = $mysqli->real_escape_string(htmlspecialchars($_POST['Sexo']));
		$sexo = htmlentities($sexo);
		if (empty($_POST['Cedula'])) {
			$error = true;
			header("Location: registroprofesor.php?vacio=si");
		}
		else {
			$cedula = $mysqli->real_escape_string(htmlspecialchars($_POST['Cedula']));
			$cedula = htmlentities($cedula);
		}
		if (empty($_POST['GradoAcademico'])) {
			$error = true;
			header("Location: registroprofesor.php?vacio=si");
		}
		else {
			$grado_academico = $mysqli->real_escape_string(htmlspecialchars($_POST['GradoAcademico']));
			$grado_academico = htmlentities($grado_academico);
			if (ctype_upper($grado_academico) != true) {
				$grado_academico = strtr(strtoupper($grado_academico),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
			}
		}
		if (empty($_POST['SiglasGradoAcademico'])) {
			$error = true;
			header("Location: registroprofesor.php?vacio=si");
		}
		else {
			$siglas_grado_academico = $mysqli->real_escape_string(htmlspecialchars($_POST['SiglasGradoAcademico']));
			$siglas_grado_academico = htmlentities($siglas_grado_academico);
			if (ctype_upper($siglas_grado_academico) != true) {
				$siglas_grado_academico = strtr(strtoupper($siglas_grado_academico),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
			}
			if (strcmp($siglas_grado_academico, "MC") == 0) {
				$siglas_grado_academico = "M.C.";
			}
			if (strcmp($siglas_grado_academico, "MTI") == 0) {
				$siglas_grado_academico = "M.T.I.";
			}
			if (strcmp($siglas_grado_academico, "ING") == 0) {
				$siglas_grado_academico = "ING.";
			}
			if (strcmp($siglas_grado_academico, "LIC") == 0) {
				$siglas_grado_academico = "LIC.";
			}
			if (strcmp($siglas_grado_academico, "LI") == 0) {
				$siglas_grado_academico = "L.I.";
			}
			if (strcmp($siglas_grado_academico, "DR") == 0) {
				$siglas_grado_academico = "DR.";
			}
			if (strcmp($siglas_grado_academico, "DRA") == 0) {
				$siglas_grado_academico = "DRA.";
			}
		}
		if (empty($_POST['CorreoElectronico'])) {
			$error = true;
			header("Location: registroprofesor.php?vacio=si");
		}
		else {
			$correo_electronico = $mysqli->real_escape_string(htmlspecialchars($_POST['CorreoElectronico']));
			$correo_electronico = htmlentities($correo_electronico);
		}
		$departamento = $mysqli->real_escape_string(htmlspecialchars($_POST['Departamento']));
		$departamento = htmlentities($departamento);
		if (ctype_upper($departamento) != true) {
			$departamento = strtr(strtoupper($departamento),"àèìòùáéíóúçñäëïöü","ÀÈÌÒÙÁÉÍÓÚÇÑÄËÏÖÜ");
		}
		if (empty($_POST['ClaveDeAcceso'])) {
			$error = true;
			header("Location: registroprofesor.php?vacio=si");
		}
		else {
			$clave_de_acceso = $_POST['ClaveDeAcceso'];
		}
		if (empty($_POST['FirmaD'])) {
			$error = true;
			header("Location: registroprofesor.php?vacio=si");
		}
		else {
			$firma_digital = $_POST['FirmaD'];
		}
		if (empty($_POST['ConfClaveDeAcceso'])) {
			$error = true;
			header("Location: registroprofesor.php?vacio=si");
		}
		else {
			$conf_clave_de_acceso = $_POST['ConfClaveDeAcceso'];
		}
		/******** VALIDAR CONTRASEÑA ********/
		if (preg_match("/[ ]/", $clave_de_acceso)) {
			$error = true;
			header("Location: registroprofesor.php?claveconespacio=si");
		}
		else {
			/******** COMPROBAR SI LA CONTRASEÑA ES CORTA ********/
			if (strlen($clave_de_acceso)<8) {
				$error = true;
				header("Location: registroprofesor.php?clavecorta=si");
			}
			else {
				/******** COMPROBAR QUE LA CONTRASEÑA TENGA LOS CARACTERES PERMITIDOS ********/
									
				/******** COMPROBAR QUE AL MENOS TENGA UN NÚMERO ********/
				if (!preg_match("/[0-9]/", $clave_de_acceso)) {
					$error = true;
					header("Location: registroprofesor.php?clavesinnum=si");
				}
									
				/****** COMPROBAR QUE AL MENOS TENGA UN CARACTER ESPECIAL ******/
				if (!preg_match("/[@#%-_&*?¿]/", $clave_de_acceso)) {
					$error = true;
					header("Location: registroprofesor.php?clavesinespecial=si");
				}								
				/****** COMPROBAR QUE LA CONTRASEÑA COINCIDA ******/
				if (strcmp($clave_de_acceso, $conf_clave_de_acceso)!=0) {
					$error = true;
					header("Location: registroprofesor.php?clavesdiferentes=si");
				}
				if ($error != true) {
					/**************  COMPROBAR LA EXISTENCIA DEL PROFESOR  *************/
		
					//BUSCA SI EXISTE EL NÚMERO DE TARGETA
		
					openConectionMysql();	// SE ABRE LA CONEXION A LA BASE DE DATOS CON ESTA FUNCION
					mysql_query("SET NAMES 'utf8'");	
					$nuevo_numtargeta = mysql_query("SELECT NumTargeta FROM Profesor WHERE NumTargeta ='$num_targeta'");	//QUERY PARA OBTENER LOS REGISTROS EXISTENTES
		
					//SI HAY MAS DE UN REGISTRO		
					if(mysql_num_rows($nuevo_numtargeta)>0) {
						header("Location: registroprofesor.php?numtargetaexistente=si");
					}
					//SI NO HAY UN REGISTRO CON ESE NÚMERO DE TARGETA SE GUARDAN LOS DATOS EN LA BASE DE DATOS							
					else {
						$fecha_hora_registro = date("Y-n-j H:i:s");	
						$query="INSERT INTO Profesor(Nombre,Apellidos,Sexo,NumTargeta,Cedula,SiglasNivelAcademico,
						NivelAcademico,CorreoElectronico,Departamento,ClaveDeAcceso,FirmaD,FechaYHoraDeRegistro,
						HacerCorrecciones,DatosCorregidos)values('$nombre','$apellidos','$sexo','$num_targeta',
						'$cedula','$siglas_grado_academico','$grado_academico','$correo_electronico',
						'$departamento','$clave_de_acceso','$firma_digital','$fecha_hora_registro',false,'no')";
						if(mysql_query($query)) { //SI SE LOGRÓ LA CONSULTA		
							header("Location: registroProfesorExitoso.php");
						}
						else { //SI NO SE LOGRÓ LA CONSULTA
							header("Location: registroprofesor.php?registrofallido=si");
						}
					}
				}	
			}
		}
	}
?>
