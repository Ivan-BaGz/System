<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Agregar | profesor</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
</head>
<body>

	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="active"><a class="btn" href="perfiladministrador.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">

		<ol class="breadcrumb">
			<li><a href="#">Administrador</a></li>
			<li class="active">Agregar profesor</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Agregar profesor</h1>
				</header>
				
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Proporcione los datos del profesor</h3>
							<p class="text-center text-muted">Registro de profesor al Sistema de apoyo para la coordinación de Titulación</p>
							
							<script type="text/javascript">
								function soloNumeros(e) {
									var entrada = window.event ? window.event.keyCode : e.which;
									if (entrada == 8 || entrada == 9) 
										return true;

									return /\d/.test(String.fromCharCode(entrada));
								}
								function validar(form1) {
									if (document.form1.NumTargeta.value=="") {
										alert("Tienes campos vacíos");
										return false;
									}
									else if (document.form1.Nombre.value=="") {
										alert("Tienes campos vacíos");
										return false;
									}
									else if (document.form1.Apellidos.value=="") {
										alert("Tienes campos vacíos");
										return false;
									}
									else if (document.form1.GradoAcademico.value=="") {
										alert("Tienes campos vacíos");
										return false;
									}
									else if (document.form1.CorreoElectronico.value=="") {
										alert("Tienes campos vacíos");
										return false;
									}
									else if (document.form1.ClaveDeAcceso.value=="") {
										alert("Tienes campos vacíos");
										return false;
									}
									else if (document.form1.ConfClaveDeAcceso.value=="") {
										alert("Tienes campos vacíos");
										return false;
									}
									else {
										//SE VALIDA LA CONTRASEÑA
										var cadena = document.form1.ClaveDeAcceso.value;
										var cadena2 = document.form1.ConfClaveDeAcceso.value;
										var numcaracteres = cadena.length;
										var espacio = " ";
										if (cadena.indexOf(espacio) > -1) {
											alert("La contraseña no debe contener especios en blanco");
											return false;
										}
										else {
											if (numcaracteres < 10) {
												alert("La contraseña es corta");
												return false;
											}
											else {
												if (!(cadena.match(/\d/))) {
     												alert("La contraseña debe contener al menos un número");
     												return false;
												}
												if (!(cadena.match(/[a-z]/))) {
													alert("La contraseña debe contener al menos una letra minuscula");
													return false;
												}
												if (!(cadena.match(/[A-Z]/))) {
													alert("La contraseña debe contener al menos una letra mayuscula");
													return false;
												}
												if (!(cadena.match(/\W+/))) {
													alert("La contraseña debe de contener al menos un caracter especial");
													return false;
												}
												if (cadena != cadena2) {
													alert("Las contraseñas no coinciden");
													return false;
												}
											}
										}
									}
								}	
							</script>

						<?php
							//funciones
							include 'funciones.php';

							$aux = 0;

							if (isset($_POST['crear_cuenta'])) {
								if (empty($_POST['NumTargeta'])) {
									echo "<p class='text-center text-alert'>Tiene campos vacíos</p>";
									$error = true;
								}
								else {
									$num_targeta = $_POST['NumTargeta'];
								}
								if (empty($_POST['Nombre'])) {
									echo "<p class='text-center text-alert'>Tiene campos vacíos</p>";
									$error = true;
								}
								else {
									$nombre = $_POST['Nombre'];
								}
								if (empty($_POST['Apellidos'])) {
									echo "<p class='text-center text-alert'>Tiene campos vacíos</p>";
									$error = true;
								}
								else {
									$apellidos = $_POST['Apellidos'];
								}
								if (empty($_POST['GradoAcademico'])) {
									echo "<p class='text-center text-alert'>Tiene campos vacíos</p>";
									$error = true;
								}
								else {
									$grado_academico = $_POST['GradoAcademico'];
								}
								if (empty($_POST['CorreoElectronico'])) {
									echo "<p class='text-center text-alert'>Tiene campos vacíos</p>";
									$error = true;
								}
								else {
									$correo_electronico = $_POST['CorreoElectronico'];
								}
								$departamento = $_POST['Departamento'];
								if (empty($_POST['ClaveDeAcceso'])) {
									echo "<p class='text-center text-alert'>Tiene campos vacíos</p>";
									$error = true;
								}
								else {
									$clave_de_acceso = $_POST['ClaveDeAcceso'];
								}
								if (empty($_POST['ConfClaveDeAcceso'])) {
									echo "<p class='text-center text-alert'>Tiene campos vacíos</p>";
									$error = true;
								}
								else {
									$conf_clave_de_acceso = $_POST['ConfClaveDeAcceso'];
								}
								/******** VALIDAR CONTRASEÑA ********/
								$espacio = " ";
								if (preg_match("/[ ]/", $clave_de_acceso)) {
									echo "<p class='text-center text-alert'>La contraseña no debe de contener espacios en blanco</p>";
									$error = true;
								}
								else {
								/******** COMPROBAR SI LA CONTRASEÑA ES CORTA ********/
								if (strlen($clave_de_acceso)<10) {
									echo "<p class='text-center text-alert'>La contraseña es corta</p>";
									$error = true;
								}
								else {

									/******** COMPROBAR QUE LA CONTRASEÑA TENGA LOS CARACTERES PERMITIDOS ********/
									
									/******** COMPROBAR QUE AL MENOS TENGA UN NÚMERO ********/
									if (!preg_match("/[0-9]/", $clave_de_acceso)) {
										echo "<p class='text-center text-alert'>La contraseña debe contener al menos un número</p>";
										$error = true;
									}
									
										/****** COMPROBAR QUE AL MENOS TENGA UNA MINUSCULA ******/
										if (!preg_match("/[a-z]/", $clave_de_acceso)) {
											echo "<p class='text-center text-alert'>La contraseña debe contener al menos una letra minuscula</p>";
											$error = true;
										}
										
											/****** COMPROBAR QUE AL MENOS TENGA UNA MAYUSCULA ******/
											if (!preg_match("/[A-Z]/", $clave_de_acceso)) {
												echo "<p class='text-center text-alert'>La contraseña debe contener al menos una letra mayuscula</p>";
												$error = true;
											}
											
												/****** COMPROBAR QUE AL MENOS TENGA UN CARACTER ESPECIAL ******/
												if (!preg_match("/[@#%-_&*?¿]/", $clave_de_acceso)) {
													echo "<p class='text-center text-alert'>La contraseña debe contener al menos un caracter especial</p>";
													$error = true;
												}
												
													/****** COMPROBAR QUE LA CONTRASEÑA COINCIDA ******/
													if (strcmp($clave_de_acceso, $conf_clave_de_acceso)!=0) {
														echo "<p class='text-center text-alert'>La contraseña no es igual</p>";
														$error = true;
													}
													if ($error != true) {
														/**************  COMPROBAR LA EXISTENCIA DEL PROFESOR  *************/
		
														//BUSCA SI EXISTE EL NÚMERO DE TARGETA
		
														openConectionMysql();	// SE ABRE LA CONEXION A LA BASE DE DATOS CON ESTA FUNCION	
														$nuevo_numtargeta = mysql_query("SELECT NumTargeta FROM Profesor WHERE NumTargeta ='$num_targeta'");	//QUERY PARA OBTENER LOS REGISTROS EXISTENTES
		
														//SI HAY MAS DE UN REGISTRO		
														if(mysql_num_rows($nuevo_numtargeta)>0) {
															echo "<p class='text-center text-alert'>Este número de targeta ya se encuentra registrado</p>";	
														}
		
														//SI NO HAY UN REGISTRO CON ESE NÚMERO DE TARGETA SE GUARDAN LOS DATOS EN LA BASE DE DATOS
														else {	
															$query="INSERT INTO Profesor(Nombre,Apellidos,NumTargeta,GradoAcademico,CorreoElectronico,Departamento,ClaveDeAcceso)values('$nombre','$apellidos','$num_targeta','$grado_academico',$correo_electronico,'$departamento','$clave_de_acceso')";
															if(mysql_query($query)) { //SI SE LOGRÓ LA CONSULTA		
															echo "<p class='text-center text-alert'>El registro se efectuó satisfactoriamente</p>";
															}
															else { //SI NO SE LOGRÓ LA CONSULTA
																echo "<p class='text-center text-alert'>No se logró el registro<br>Vuelve a intentarlo</p>";		
															}
														}
													}	
								}
								}
							}	
						?>
							
							<hr>

							<form action="agregarsinodal.php" method="post">
								<div class="top-margin">
									<label>Número de targeta<span class="text-danger">*</span> </label>
									<input type="text" name="Nombre" maxlength="3" onkeypress="return soloNumeros(event);" 
									class="form-control-numtargeta ajustar-numtargeta" onsubmit="return validar()">
								</div>
								<div class="top-margin">
									<label>Nombre<span class="text-danger">*</span> </label>
									<input type="text" name="Nombre" class="form-control-nombreprofesor">
								</div>
								<div class="top-margin">
									<label>Apellidos <span class="text-danger">*</span> </label>
									<input type="text" name="Cedula" class="form-control-apellidos">
								</div>
								<div class="top-margin">
									<label>Grado académico <span class="text-danger">*</span></label>
									<input type="text" name="Escolaridad" class="form-control-gradoacademico">
								</div>
								<div class="top-margin">
									<label>Correo electrónico <span class="text-danger">*</span> </label>
									<input type="text" name="CorreoElectronico" class="form-control-correo">
								</div>
								<div class="top-margin">
									<label>Departamento</label>
									<select name="Departamento" class="form-control-departamentoprofesor">
										<option value="sistemas">Departamento de sistemas y computación</option>
										<option value="ingenieria industrial">Departamento de ciencias básicas</option>
										<option value="ingenieria civil">Departamento de ciencias de la tierra</option>
									</select>
								</div>
								<div class="row top-margin">
									<div class="col-sm-6">
										<label class="centrar">Contraseña <span class="text-danger">*</span></label>
										<input type="password" name="ClaveDeAcceso" maxlength="18" class="form-control-claveacceso centrar">
									</div>
									<div class="col-sm-6">
										<label>Confirme la contraseña <span class="text-danger">*</span></label>
										<input type="password" name="ConfClaveDeAcceso" maxlength="18" class="form-control-confclaveacceso">
									</div>
									<p class="text-center text-muted">
										10 caracteres como mínimo, 18 como máximo<br>
										Sin espacios en blanco<br>
										Debe contener al menos un número, una letra mayuscula, una letra minuscula y un caracter especial
									</p>
								</div>
							
								<hr>

								<div class="row">
									<div class="col-lg-4 text-right">
										<button class="btn btn-info centrar-boton" type="submit" name="agregar_sinodal">Agregar</button>
									</div>
								</div>
							</form>
						</div>
					</div>

				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title"></h3>
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2014
							</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
