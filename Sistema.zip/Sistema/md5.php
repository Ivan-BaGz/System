<?php
echo md5("azkm969@qpwo#15");
?>
