
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Enviar | mensajes</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8" />	
		
	<link rel="stylesheet" type="text/css" href="select_dependientes.css">
	<script type="text/javascript" src="select_dependientesListaAlumnos.js"></script>
	
	<style type="text/css">
	#iframe
    {
    overflow:auto;
    width:800px;
    height:300px;
    }
   </style>
		
	</head>
	
	<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="active"><a class="btn" href="enviarMensajesCoordTitulacion.php">Redactar mensajes</a></li>
					<li class="active"><a class="btn" href="perfilCoordTitulacion.php">Regresar</a></li>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Estudiante</a></li>
			<li class="active">Ver mensajes</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Ver mensajes</h1>
				</header>
				
				<div class="col-md-10 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">

<?php

include 'funciones.php';

if( isset($_POST['borrar_mensajes']) ) 
	{
		if( !empty($_POST['eliminar']) ) 
		{
			$eliminar = $_POST['eliminar'];
			openConectionMysql();
			foreach( $eliminar as $mensajes )
			{
				$borrar = "DELETE FROM MensajesCoordTitulacion WHERE IdMensaje = $mensajes";
				mysql_query($borrar);
			}
			$self = $_SERVER['PHP_SELF']; //Obtenemos la página en la que nos encontramos
			header("refresh:1; url=$self"); //Refrescamos la pagina	
		}
	}

function generaTablaMensajes($id) 
{
	function replace($cadena) {
		$cadena = str_replace("&AACUTE;", "Á", $cadena);
		$cadena = str_replace("&EACUTE;", "É", $cadena);
		$cadena = str_replace("&IACUTE;", "Í", $cadena);
		$cadena = str_replace("&OACUTE;", "Ó", $cadena);
		$cadena = str_replace("&UACUTE;", "Ú", $cadena);
		$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
		$cadena = str_replace("&aacute;", "á", $cadena);
		$cadena = str_replace("&eacute;", "é", $cadena);
		$cadena = str_replace("&iacute;", "í", $cadena);
		$cadena = str_replace("&oacute;", "ó", $cadena);
		$cadena = str_replace("&uacute;", "ú", $cadena);
		$cadena = str_replace("&ntilde;", "ñ", $cadena);
		return $cadena;
	}
	//mostrar mensajes										 
	$consulta="SELECT visto,IdMensaje,Administrador.IdAdministrador user,Estudiante.Nombre estudiante,Estudiante.Apellidos apellidose,Administrador.Nombre admon,mensaje,DATE_FORMAT(fechaHora,'%d/%m/%Y a las %H:%i') fechaHora, asunto FROM Administrador,MensajesCoordTitulacion,Estudiante WHERE MensajesCoordTitulacion.IdEstudiante = Estudiante.IdEstudiante and MensajesCoordTitulacion.IdCoordTitulacion = Administrador.IdAdministrador and MensajesCoordTitulacion.IdCoordTitulacion =$id";
	
	$consulta2 ="SELECT visto,IdMensaje,Administrador.IdAdministrador user,Profesor.Nombre profesor,Profesor.Apellidos apellidosp,Administrador.Nombre admon,mensaje,DATE_FORMAT(fechaHora,'%d/%m/%Y a las %H:%i') fechaHora, asunto FROM Administrador,MensajesCoordTitulacion,Profesor WHERE MensajesCoordTitulacion.IdProfesor = Profesor.IdProfesor and MensajesCoordTitulacion.IdCoordTitulacion = Administrador.IdAdministrador and MensajesCoordTitulacion.IdCoordTitulacion = $id";
	
	$consulta3 = "SELECT visto,IdMensaje,IdCoordTitulacion user,Nombre,mensaje,DATE_FORMAT(fechaHora,'%d/%m/%Y a las %H:%i') fechaHora, asunto FROM Administrador,MensajesCoordTitulacion WHERE MensajesCoordTitulacion.IdCoordTitulacion = $id and MensajesCoordTitulacion.IdAdmon = 1 and MensajesCoordTitulacion.IdAdmon = Administrador.IdAdministrador";	
										
	$resultado = conexionMysql($consulta);
	$resultado2 = conexionMysql($consulta2);
	$resultado3 = conexionMysql($consulta3);
	
	echo "<div id='iframe'>";
	echo "<table width='100%' border='0' align='center' cellpadding='4' cellspacing='0'>";
	
	if( mysql_num_rows($resultado) > 0 ) 
	{
	echo "<tr><td colspan='4'><label>Mensajes de alumnos.</label></td></tr>";	
		$bgcolorVisto = "'#d0e7ff' style='border-right:1px solid #cccccc;'";
		$bgcolorNoVisto =	"'#FFFF99' style='border-right:1px solid #cccccc;'";		
			
		while($fila = mysql_fetch_assoc($resultado)) 
		{
			$usuario = $fila['user'];
			$mensaje =$fila['IdMensaje'];
					
		echo "<tr>";
			echo "<td bgcolor=";
			if( $fila['visto'] == true ){ 
			echo $bgcolorVisto;}
			else {
			echo $bgcolorNoVisto;} echo ">";
			
			if( $fila['visto'] == true ) { 
				echo "<input type='checkbox' name='eliminar[]' id='eliminar[]' value='$mensaje'>";
			}
			else {
				echo "<input type='checkbox' name='eliminar[]' id='eliminar[]' value='$mensaje' disabled='disabled'>";
			}
			echo "<label>&nbsp Eliminar</label>"; 
			
			echo "</td>";
			
			echo "<td bgcolor=";
			if( $fila['visto'] == true ){ 
			echo $bgcolorVisto;}
			else {
			echo $bgcolorNoVisto;} echo ">"; echo $fila['fechaHora']; echo "</td>";
			echo "<td bgcolor=";
			if( $fila['visto'] == true ){ 
			echo $bgcolorVisto;}
			else {
			echo $bgcolorNoVisto;} echo ">"; echo replace($fila['estudiante'])." ".replace($fila['apellidose']); echo "</td>";
			echo "<td bgcolor=";
			if( $fila['visto'] == true ){ 
			echo $bgcolorVisto;}
			else {
			echo $bgcolorNoVisto;} echo ">"; echo "<a href='visorMensajesCoordTitulacion.php?user=$usuario&message=$mensaje'>"; echo $fila['asunto']; echo "</a>"; echo "</td>";
		echo "</tr>";
		}
			
	}
	else 
		{
			echo "<label>Aun no tienes mensajes de alumnos.</label>";			
		}
	if( mysql_num_rows($resultado2) > 0 ) 
	{	
		echo "<tr><td colspan='4'><label>Mensajes de profesores</label></td></tr>";
		$bgcolorVisto = "'#d0e7ff' style='border-right:1px solid #cccccc;'";
		$bgcolorNoVisto =	"'#FFFF99' style='border-right:1px solid #cccccc;'";			
			
			while($fila = mysql_fetch_assoc($resultado2)) 
			{
				$usuario = $fila['user'];
				$mensaje =$fila['IdMensaje'];
				
				echo "<tr>";
				echo "<td bgcolor=";
			if( $fila['visto'] == true ){ 
			echo $bgcolorVisto;}
			else {
			echo $bgcolorNoVisto;} echo ">";
			
			if( $fila['visto'] == true ) { 
				echo "<input type='checkbox' name='eliminar[]' id='eliminar[]' value='$mensaje'>";
			}
			else {
				echo "<input type='checkbox' name='eliminar[]' id='eliminar[]' value='$mensaje' disabled='disabled'>";
			}
			echo "<label>&nbsp Eliminar</label>"; 
			
			echo "</td>";
				echo "<td bgcolor=";
				if( $fila['visto'] == true ){ 
				echo $bgcolorVisto;}
				else {
				echo $bgcolorNoVisto;} echo ">"; echo $fila['fechaHora']; echo "</td>";
				
				echo "<td bgcolor=";
				if( $fila['visto'] == true ){ 
				echo $bgcolorVisto;}
				else {
				echo $bgcolorNoVisto;} echo ">"; echo replace($fila['profesor'])." ".replace($fila['apellidosp']); echo "</td>";
	
				echo "<td bgcolor=";
				if( $fila['visto'] == true ){ 
				echo $bgcolorVisto;}
				else {
				echo $bgcolorNoVisto;} echo ">"; echo "<a href='visorMensajesCoordTitulacion.php?user=$usuario&message=$mensaje'>"; echo $fila['asunto']; echo "</a>"; echo "</td>";
			echo "</tr>";
			}
		}
		else 
		{
			echo "<label>Aun no tienes mensajes de profesores.</label>";			
		}
		if( mysql_num_rows($resultado3) > 0 ) 
		{	
		echo "<tr><td colspan='4'><label>Mensajes del administrador</label></td></tr>";
		$bgcolorVisto = "'#d0e7ff' style='border-right:1px solid #cccccc;'";
		$bgcolorNoVisto =	"'#FFFF99' style='border-right:1px solid #cccccc;'";			
			
			while($fila = mysql_fetch_assoc($resultado3)) 
			{
				$usuario = $fila['user'];
				$mensaje =$fila['IdMensaje'];
				
				echo "<tr>";
				echo "<td bgcolor=";
			if( $fila['visto'] == true ){ 
			echo $bgcolorVisto;}
			else {
			echo $bgcolorNoVisto;} echo ">";
			
			if( $fila['visto'] == true ) { 
				echo "<input type='checkbox' name='eliminar[]' id='eliminar[]' value='$mensaje'>";
			}
			else {
				echo "<input type='checkbox' name='eliminar[]' id='eliminar[]' value='$mensaje' disabled='disabled'>";
			}
			echo "<label>&nbsp Eliminar</label>"; 
			
			echo "</td>";
				echo "<td bgcolor=";
				if( $fila['visto'] == true ){ 
				echo $bgcolorVisto;}
				else {
				echo $bgcolorNoVisto;} echo ">"; echo $fila['fechaHora']; echo "</td>";
				
				echo "<td bgcolor=";
				if( $fila['visto'] == true ){ 
				echo $bgcolorVisto;}
				else {
				echo $bgcolorNoVisto;} echo ">"; echo replace($fila['Nombre']); echo "</td>";
	
				echo "<td bgcolor=";
				if( $fila['visto'] == true ){ 
				echo $bgcolorVisto;}
				else {
				echo $bgcolorNoVisto;} echo ">"; echo "<a href='visorMensajesCoordTitulacion.php?user=$usuario&message=$mensaje'>"; echo $fila['asunto']; echo "</a>"; echo "</td>";
			echo "</tr>";
			}
		}
		else 
		{
			echo "<label>Aun no tienes mensajes del administrador.</label>";			
		}
		echo "</table>";
		echo "</div>";
	}
	
	session_name('loginUsuario');
	session_start();	
	
	$id = $_SESSION["id"];
	
	echo "<form action='verMensajesCoordTitulacion.php' method='post'>";
		generaTablaMensajes($id);
	echo '<input type="submit" name="borrar_mensajes" value="Borrar mensajes" class="btn btn-danger">';
	echo "</form>";
?>

</div>
					</div>
				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
