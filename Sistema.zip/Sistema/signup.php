
<?php
	error_reporting( E_WARNING | E_ERROR );
?>

<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Registro | egresado</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
	<script src="jquery-1.10.2.min.js"></script>
	<script src="md5.js"></script>
	<script type="text/javascript" src="select_dependientesListaOpcionesTitulacion.js"></script>
	
	<script type="text/javascript">
		function soloNumeros(e) {
			var entrada = window.event ? window.event.keyCode : e.which;
			if (entrada == 8 || entrada == 9){
				return true;
			}
				return /\d/.test(String.fromCharCode(entrada));
		}
		function soloLetras(e) {
    		tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==32) { // espacio
				return true; 
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (tecla==0) { // ñ
				return true;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[a-zA-Z]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function correoElectronico(e) {
			tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==190) { //punto
				return true;
			}
			if (tecla==32) { // espacio
				return false; 
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==189) { // -
				return true;
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (e.shiftKey && tecla==189) {
				return true;
			}
			if (e.shiftKey && tecla==49 || e.shiftKey && tecla==50 || e.shiftKey && tecla==51 || 
				e.shiftKey && tecla==52 || e.shiftKey && tecla==53 || e.shiftKey && tecla==54 || 
				e.shiftKey && tecla==55 || e.shiftKey && tecla==56 || e.shiftKey && tecla==57 || 
				e.shiftKey && tecla==48 || e.shiftKey && tecla==186 || e.shiftKey && tecla==187 || 
				e.shiftKey && tecla==191 || e.shiftKey && tecla==192 || e.shiftKey && tecla==219 || 
				e.shiftKey && tecla==220 || e.shiftKey && tecla==221 || e.shiftKey && tecla==222) {
				return false;
			}
			if (tecla==187 || tecla==188 || tecla==191 || tecla==192 || tecla==219 || tecla==220 || tecla==221 || tecla==222) {
				return false;
			}
			if (e.altGraphKey && tecla==81) { // @
				return true;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[0-9a-zA-Z\W]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function proyecto(e) {
			tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==190) { //punto
				return true;
			}
			if (tecla==32) { // espacio
				return true; 
			}
			if (tecla==60) { // <
				return false;
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==189) { // guión
				return true;
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (tecla==0) { // ¿ ñ
				return true;
			}
			if (tecla==188) {
				return true;
			}
			if (e.shiftKey && tecla==49 /* ! */ || e.shiftKey && tecla==50 /* "" */ ||  
				e.shiftKey && tecla==54 /* & */ || e.shiftKey && tecla==55 /* / */ ||
				e.shiftKey && tecla==48 /* = */ || e.shiftKey && tecla==186 /* ; */ || 
				e.shiftKey && tecla==191 /* ? */ || e.shiftKey && tecla==192 /* ¨ */ || 
				e.shiftKey && tecla==219 /* [ */ || e.shiftKey && tecla==220 /* | */ || 
				e.shiftKey && tecla==221 /* ] */ || e.shiftKey && tecla==222 /* '' */ || 
				e.shiftKey && tecla==187 /* * */ || e.shiftKey && tecla==60 /* > */ ||
				e.shiftKey && tecla==0 /* ¡ */ || e.shiftKey && tecla==171 /* * */ ||
				e.shiftKey && tecla==174 /* [ */ || e.shiftKey && tecla==175 /* ] */ ||
				e.shiftKey && tecla==52 /* $ */ || e.shiftKey && tecla==53 /* % */) {
				return false;
			} 
			if (e.shiftKey && tecla==51 /* # */ || e.shiftKey && tecla==56 /* ( */ || 
				e.shiftKey && tecla==57 /* ) */ || e.shiftKey && tecla==189 /* _ */ ) {
				return true;
			}
			if (tecla==187 || tecla==191 || tecla==192 || tecla==219 || tecla==220 || 
				tecla==221 || tecla==222 || tecla==171 /* + */ || tecla==174 /* { */ || tecla==175 /* } */) {
				return false;
			}
			if (tecla==255 && tecla==81) { // @
				return false;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[0-9a-zA-Z\W]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function claveDeAcceso(e) {
			tecla = (document.all) ? e.keyCode : e.which;
    		if (tecla==8) { // backspace
    			return true; 
			}
			if (tecla==190) { //punto
				return false;
			}
			if (tecla==32) { // espacio
				return false; 
			}
			if (tecla==60) { // <
				return false;
			}
			if (tecla==9) { // tabulador
				return true; 
			}
			if (tecla==189) { // guión
				return true;
			}
			if (tecla==37) { // flecha izquierda
				return true;
			}
			if (tecla==39) { // flecha derecha
				return true;
			}
			if (tecla==0) { // ¿
				return false;
			}
			if (e.shiftKey && tecla==49 /* ! */ || e.shiftKey && tecla==50 /* "" */ ||  
				e.shiftKey && tecla==54 /* & */ || e.shiftKey && tecla==55 /* / */ || 
				e.shiftKey && tecla==56 /* ( */ || e.shiftKey && tecla==57 /* ) */ || 
				e.shiftKey && tecla==48 /* = */ || e.shiftKey && tecla==186 /* ; */ || 
				e.shiftKey && tecla==191 /* ? */ || e.shiftKey && tecla==192 /* ¨ */ || 
				e.shiftKey && tecla==219 /* [ */ || e.shiftKey && tecla==220 /* | */ || 
				e.shiftKey && tecla==221 /* ] */ || e.shiftKey && tecla==222 /* '' */ || 
				e.shiftKey && tecla==187 /* * */ || e.shiftKey && tecla==60 /* > */ ||
				e.shiftKey && tecla==0 /* ¡ */ || e.shiftKey && tecla==171 /* * */ ||
				e.shiftKey && tecla==174 /* [ */ || e.shiftKey && tecla==175 /* ] */) {
				return false;
			} 
			if (e.shiftKey && tecla==51 /* # */ || e.shiftKey && tecla==52 /* $ */ ||
				e.shiftKey && tecla==53 /* % */ || e.shiftKey && tecla==189 /* _ */ ) {
				return true;
			}
			if (tecla==187 || tecla==188 || tecla==191 || tecla==192 || tecla==219 || tecla==220 || 
				tecla==221 || tecla==222 || tecla==171 /* + */ || tecla==174 /* { */ || tecla==175 /* } */) {
				return false;
			}
			if (e.altGraphKey && tecla==81) { // @
				return true;
			}
			if (e.ctrlKey && tecla==86) { //Ctrl v
				return false; 
			}
			if (e.ctrlKey && tecla==67) { //Ctrl c
				return false; 
			}
			if (e.ctrlKey && tecla==88) { //Ctrl x
				return false; 
 			}
			patron = /[0-9a-zA-Z\W]/; //patron
 
			te = String.fromCharCode(tecla);
			return patron.test(te); // prueba de patron
		}
		function validar(form1) {
			if (document.form1.NumControl.value=="") {
				alert("Tienes campos vacíos");
				return false;
			}
			else if (document.form1.Nombre.value=="") {
					alert("Tienes campos vacíos");
					return false;
					}
				else if (document.form1.Apellidos.value=="") {
						alert("Tienes campos vacíos");
						return false;
						}
					else if (document.form1.Direccion.value=="") {
							alert("Tienes campos vacíos");
							return false;
							}
						else if (document.form1.TelefonoCelular.value=="" && document.form1.TelefonoDeCasa.value=="") {
								alert("Tienes campos vacíos. Al menos introduce un número telefónico");
								return false;
								}
							else if (document.form1.CorreoElectronico.value=="") {
									alert("Tienes campos vacíos");
									return false;
									}
								else if (document.form1.ClaveDeAcceso.value=="") {
										alert("Tienes campos vacíos");
										return false;
										}
									else if (document.form1.ConfClaveDeAcceso.value=="") {
											alert("Tienes campos vacíos");
											return false;
											}
										else {
											//SE VALIDA CORREO ELECTRÓNICO
											var correo = document.form1.CorreoElectronico.value;
											expr = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
											//expr = /^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,3})$/;
    										if ( !expr.test(correo) ) {
        										alert("Error: La dirección de correo " + correo + " es incorrecta.");
        										return false;
        									}
											//SE VALIDA LA CONTRASEÑA

											var cadena = document.form1.ClaveDeAcceso.value;
											var cadena2 = document.form1.ConfClaveDeAcceso.value;
											var numcaracteres = cadena.length;
											var espacio = " ";
											if (cadena.indexOf(espacio) > -1) {
												alert("La contraseña no debe contener espacios en blanco");
												return false;
											}
											else {
												if (numcaracteres < 8) {
													alert("La contraseña es corta");
													return false;
												}
												else {
													if (!(cadena.match(/\d/))) {
     													alert("La contraseña debe contener al menos un número");
     													return false;
													}
													if (!(cadena.match(/\W+/))) {
														alert("La contraseña debe de contener al menos un caracter especial");
														return false;
													}
													if (cadena != cadena2) {
														alert("Las contraseñas no coinciden");
														return false;
													}
													else {
														var md5_clave = hex_md5(cadena);
														document.form1.ClaveDeAcceso.value = md5_clave;
														var md5_conf_clave = hex_md5(cadena2);
														document.form1.ConfClaveDeAcceso.value = md5_conf_clave;
													}
												}
											}
										}
		}	
	</script>

</head>
<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="#"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="active"><a class="btn" href="index.html">Inicio</a></li>
					<li class="active"><a class="btn" href="signin.php">Regresar</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">

		<ol class="breadcrumb">
			<li><a href="index.html">Inicio</a></li>
			<li><a href="signin.php">Autenticación del egresado</a></li>
			<li class="active">Registro del egresado</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Registro del egresado</h1>
				</header>
				
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
							<h3 class="thin text-center">Registrate en el sistema</h3><br>
							<p class="text-center text-muted">Al registrarte, estás dando inicio a tu trámite de titulación</p>
							<p class="text-center text-muted">Si ya te has registrado <a href="signin.php">¡Inicia seción aquí!</a> </p>
							<br>
							
							<?php
								if ($_GET["vacio"] == "si") {
									echo "<p class='text-center text-black2'>Tienes campos vacíos</p>";	
								}
								if ($_GET["sinnumtel"] == "si") {
									echo "<p class='text-center text-black2'>Proporciona al menos un número telefónico</p>";	
								}
								if ($_GET["espacioenblanco"] == "si") {
									echo "<p class='text-center text-black2'>La contraseña no debe contener espacios en blanco</p>";	
								}
								if ($_GET["clavecorta"] == "si") {
									echo "<p class='text-center text-black2'>La contraseña es muy corta</p>";	
								}
								if ($_GET["clavesinnumero"] == "si") {
									echo "<p class='text-center text-black2'>La contraseña debe contener al menos un número</p>";	
								}
								if ($_GET["clavesinespecial"] == "si") {
									echo "<p class='text-center text-black2'>La contraseña debe contener al menos un caracter especial</p>";	
								}
								if ($_GET["novalidos"] == "si") {
									echo "<p class='text-center text-black2'>La contraseña contiene caracteres no válidos</p>";	
								}
								if ($_GET["clavesdiferentes"] == "si") {
									echo "<p class='text-center text-black2'>La contraseña no es igual</p>";	
								}
								if ($_GET["numcontrolexistente"] == "si") {
									echo "<p class='text-center text-black2'>Éste número de control ya se encuentra registrado</p>";	
								}
								if ($_GET["registrofallido"] == "si") {
									echo "<p class='text-center text-black2'>No se logró el registro<br>Vuelve a intentarlo</p>";	
								}
							?>
							<hr>
							<form name="form1" id="form1" action="controlRegistroEstudiante.php" method="post" onsubmit="return validar()">
								<div class="row top-margin">
									<div class="col-sm-6">
										<label>Número de control <span class="text-danger">*</span> </label>
										<input type="text" name="NumControl" maxlength="8" onkeypress="return soloNumeros(event);" class="form-control-numcontrol">
									</div>
									<div class="col-sm-6">
										<label>Nombre <span class="text-danger">*</span> </label>
										<input type="text" name="Nombre" onkeydown="return soloLetras(event);" class="form-control">
									</div>
								</div>
								<div class="top-margin">
									<label>Apellidos <span class="text-danger">*</span></label>
									<input type="text" name="Apellidos" onkeydown="return soloLetras(event);" class="form-control-apellidos">
								</div>
								<div class="top-margin">
									<label>Sexo</label>
									<select name="Sexo" class="form-control-sexo">
										<option value="masculino">Masculino</option>
										<option value="femenino">Femenino</option>
									</select>
								</div>
								<div class="top-margin">
									<label>Dirección <span class="text-danger">*</span> </label>
									<input type="text" name="Direccion" class="form-control-direccion">
								</div>
								<div class="row top-margin">
									<div class="col-sm-6">
										<label class="centrar">Telefono celular</label>
										<input type="text" name="TelefonoCelular" maxlength="10" onkeypress="return soloNumeros(event);" class="form-control-telcelular centrar">
									</div>
									<div class="col-sm-6">
										<label class="ajustar-telcasa">Telefono de casa</label>
										<input type="text" name="TelefonoDeCasa" maxlength="10" onkeypress="return soloNumeros(event);" class="form-control-telcasa ajustar-telcasa">
									</div>
									<p class="text-center text-muted">Si no cuentas con los dos números telefónicos<br>
										proporciona al menos uno</p>
								</div>
								<div class="top-margin">
									<label>Correo electrónico<span class="text-danger">*</span></label>
									<input type="text" name="CorreoElectronico" onkeydown="return correoElectronico(event);" class="form-control-correo">
								</div>
								<div class="top-margin">
									<label>Carrera</label>
									<select name="Carrera" class="form-control-carrera">
										<option value="INGENIERÍA EN SISTEMAS COMPUTACIONALES">Ingeniería en sistemas computacionales</option>
									</select>
								</div>
								
								<!--***********************************************************************
								**********************  SELECT DINÁMICOS   *****************************
								***********************************************************************-->								
								
								<div class="top-margin">
									<div id="lista1" style="width:800px;">
										<label>Reticula</label>
										<select name="Reticula" id="Reticula" onChange='cargaContenido(this.id)' class="form-control-reticula">
											<option value='0'>Selecciona tu reticula</option>										
											<option value="ISIC-2010-224">ISIC-2010-224</option>
											<option value="ISIC-2004-296">ISIC-2004-296</option>
											<option value="ISIC-1993-296">ISIC-1993-296</option>
									 	</select>		
									</div>
									<br>
									<div id="lista2">
										<label>Opción de titulación</label>
										<select disabled="disabled" name="OpcionDeTitulacion" id="OpcionDeTitulacion" class='form-control'>
											<option value="0">Selecciona opci&oacute;n...</option>
										</select>
									</div>	
    							</div>							
								
								<!-- ****************************************************************-->
								
								<div class="top-margin">
									<label>Nombre del proyecto<span class="text-danger">*</span> </label>
									<textarea name="Proyecto" cols="55" rows="5" onkeydown="return proyecto(event);" class="form-control"></textarea>
								</div>
								<div class="row top-margin">
									<div class="col-sm-6">
										<label class="centrar">Contraseña <span class="text-danger">*</span></label>
										<input type="password" name="ClaveDeAcceso" maxlength="100" onkeydown="return claveDeAcceso(event);" class="form-control-claveacceso centrar">
									</div>
									<div class="col-sm-6">
										<label class="etiqueta-claveacceso">Confirma la contraseña <span class="text-danger">*</span></label>
										<input type="password" name="ConfClaveDeAcceso" maxlength="100" onkeydown="return claveDeAcceso(event);" class="form-control-confclaveacceso">
									</div>
									<p class="text-center text-muted">
										Las contraseñas entre más largas sean, más seguras son<br>
										Contienen números, letras y caracteres especiales
									</p>
								</div>
								<hr>
								<div class="row">
									<div class="col-lg-4 text-right">
										<button class="btn btn-danger centrar-boton-registro-egresado" type="submit" name="crear_cuenta">REGISTRARME</button>
									</div>
								</div>
							</form>
						</div>
					</div>

				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	
	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>	
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>

				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
	<script>$("#carrera").on("change", buscarReticulas);</script>
	<script type="text/javascript">

	function buscarReticulas(){
    $("#localidad").html("<option value=''>- primero seleccione un municipio -</option>");
 
    $estado = $("#estado").val();
 
    if($estado == ""){
            $("#municipio").html("<option value=''>- primero seleccione un estado -</option>");
    }
    else {
        $.ajax({
            dataType: "json",
            data: {"estado": $estado},
            url:   'buscar.php',
            type:  'post',
            beforeSend: function(){
                //Lo que se hace antes de enviar el formulario
                },
            success: function(respuesta){
                //lo que se si el destino devuelve algo
                $("#municipio").html(respuesta.html);
            },
            error:    function(xhr,err){
                alert("readyState: "+xhr.readyState+"\nstatus: "+xhr.status+"\n \n responseText: "+xhr.responseText);
            }
        });
    }
}
</script>
</body>
</html>
