
<?php
include "funciones.php";

function replace($cadena) {
	$cadena = str_replace("&AACUTE;", "Á", $cadena);
	$cadena = str_replace("&EACUTE;", "É", $cadena);
	$cadena = str_replace("&IACUTE;", "Í", $cadena);
	$cadena = str_replace("&OACUTE;", "Ó", $cadena);
	$cadena = str_replace("&UACUTE;", "Ú", $cadena);
	$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
	$cadena = str_replace("&aacute;", "á", $cadena);
	$cadena = str_replace("&eacute;", "é", $cadena);
	$cadena = str_replace("&iacute;", "í", $cadena);
	$cadena = str_replace("&oacute;", "ó", $cadena);
	$cadena = str_replace("&uacute;", "ú", $cadena);
	$cadena = str_replace("&ntilde;", "ñ", $cadena);
	return $cadena;
}

if( isset($_POST['cambio_jurado']) ) 
	{
		
		//funciones para armar el mensaje en el documento de cambio de jurado
		function generaCadena($jurado,$motivoCambio)
		{
			if( count($jurado) == 1 )
			 return $cadena = "$jurado[0] $motivoCambio";
			
			if( count($jurado) == 2 )
			 return $cadena = "$jurado[0] y $jurado[1] $motivoCambio";
			 
			if( count($jurado) == 3 )
			 return $cadena = "$jurado[0], $jurado[1] y $jurado[2] $motivoCambio";
			 
			if( count($jurado) == 4 )
			 return $cadena = "$jurado[0], $jurado[1], $jurado[2] y $jurado[3] $motivoCambio";
		}		
		
		//obtener id del alumno seleccionado
		if( !empty($_POST['alumnos']) ) 
			$idAlumno = $_POST['alumnos'];		
		
		//consultar el jurado actual antes del cambio de jurados
		$consulta = "select Presidente,Secretario,Vocal,Suplente from AsignacionDeSinodal where IdEstudiante = $idAlumno";
		$resultado = conexionMysql($consulta);
		
		//tiene asignado revisores?
		if( mysql_num_rows($resultado) > 0 ) 
		{
			//arreglo de los jurados a cambiar
			$arrayJurado = array();
			
			//obtiene jurado a cambiar como presidente
			if( !empty($_POST['presidente']) )
			{
				$idP = $_POST['presidente'];
			}
			//no realizó cambio de jurado
			else
			{
				$idP = mysql_result($resultado,0,'Presidente');
			}
			//obtiene jurado a cambiar como secretario	
			if( !empty($_POST['secretario']) )
			{
				$idS = $_POST['secretario'];
			}
			//no realizó cambio de jurado
			else 
			{
				$idS = mysql_result($resultado,0,'Secretario');
			} 
			//obtiene jurado a cambiar como vocal
			if( !empty($_POST['vocal']) )
			{
				$idV = $_POST['vocal'];
			} 
			//no realizó cambio de jurado
			else 
			{
				$idV = mysql_result($resultado,0,'Vocal');
			}
			//obtiene jurado a cambiar como suplente
			if( !empty($_POST['suplente']) )
			{
				$idSup = $_POST['suplente'];
			}
			//no realizó cambio de jurado
			else 
			{
				$idSup = mysql_result($resultado,0,'Suplente');
			}
			//insertar en una tabla temporal para comparar con la tabla original y saber los cambios
			
			$consulta = sprintf("SELECT * FROM tempAsignacionDeSinodal");
			$resultado = conexionMysql($consulta);
			if( mysql_num_rows($resultado) > 0 ) //¿ya hay un registro?
			{
				$update = sprintf("UPDATE tempAsignacionDeSinodal SET Presidente=$idP, Secretario=$idS, Vocal=$idV, Suplente=$idSup");
				mysql_query($update);
			}
			else
			{
				$insertar = "INSERT INTO tempAsignacionDeSinodal(Presidente,Secretario,Vocal,Suplente)values($idP,$idS,$idV,$idSup)";
				mysql_query($insertar);
			}
				
			//comparar las dos tablas y saber cuales jurados se cambiaron, aqui se utiliza el arreglo de jurados para llenarlo
			
			$consulta = sprintf("SELECT * from AsignacionDeSinodal where IdEstudiante = $idAlumno ");
			$resultado = conexionMysql($consulta);
			
			$consulta = sprintf("SELECT * from tempAsignacionDeSinodal");
			$resultado2 = conexionMysql($consulta);
			
				if( mysql_result($resultado,0,'Presidente') != mysql_result($resultado2,0,'Presidente') )
				{
					array_push($arrayJurado,'PRESIDENTE');
				}
				if( mysql_result($resultado,0,'Secretario') != mysql_result($resultado2,0,'Presidente') && mysql_result($resultado,0,'Secretario') != mysql_result($resultado2,0,'Secretario') )
				{
					array_push($arrayJurado,'SECRETARIO');
				}
				if( mysql_result($resultado,0,'Vocal') != mysql_result($resultado2,0,'Presidente') && mysql_result($resultado,0,'Vocal') != mysql_result($resultado2,0,'Secretario') && mysql_result($resultado,0,'Vocal') != mysql_result($resultado2,0,'Vocal') )
				{
					array_push($arrayJurado,'VOCAL');
				}
				if( mysql_result($resultado,0,'Suplente') != mysql_result($resultado2,0,'Presidente') && mysql_result($resultado,0,'Suplente') != mysql_result($resultado2,0,'Secretario') && mysql_result($resultado,0,'Suplente') != mysql_result($resultado2,0,'Vocal') && mysql_result($resultado,0,'Suplente') != mysql_result($resultado2,0,'Suplente') )
				{
					array_push($arrayJurado,'SUPLENTE');
				}			
			
			//verifica si hubo un cambio de jurado
			if( count($arrayJurado) > 0  ) 
			{
				//obtiene motivo del cambio de jurado
				if( !empty($_POST['motivo']) )
				$motivo = $_POST['motivo'];
						
				//llamada a las funcion generaCadena()
				$cadenaCompleta = generaCadena($arrayJurado,$motivo);
					 
				//verificar si ya hubo un cambio de jurado para el alumno seleccionado
				$consulta = "select * from cambioJurado where IdEstudiante = $idAlumno";
				$resultado = conexionMysql($consulta);
					 
				//fecha y hora del cambio de jurado
				$fecha_hora = date("Y-m-d H:i:s");		
							 
				if( mysql_num_rows($resultado) > 0 ) 
				{
				if(count($arrayJurado) > 0)
					{
						$j = count($arrayJurado);
						$j--;
						
						for( $i =$j; $i > -1; $i-- ) 
						{
							if($arrayJurado[$i] == 'VOCAL')
							{
								$consulta = sprintf("SELECT Vocal from AsignacionDeSinodal where IdEstudiante = $idAlumno");
								$resultado = conexionMysql($consulta);							
								$vocal = mysql_result($resultado,0,'Vocal');
								$consulta = sprintf("SELECT IdFirma from firmarAutorizaciones where IdEstudiante = $idAlumno and IdProfesor = $vocal");
								$resultado = conexionMysql($consulta);
								$idFirma = mysql_result($resultado,0,'IdFirma');
								$insertar = "update firmarAutorizaciones set IdProfesor = $idV  where IdFirma = $idFirma";
								mysql_query($insertar);
								
								//notificar al nuevo jurado
				
								$fecha_hora = date("Y-m-d H:i:s");
								$mensaje = 'Fuiste asignado como VOCAL debido a un cambio de jurado.';
								$asunto = 'Cambio de jurado';					
					
								$notificacion = sprintf("INSERT INTO MensajesProfesor(IdProfesor,IdAdmon,mensaje,asunto,visto,fechaHora)values('$idV',1,'$mensaje','$asunto',false,'$fecha_hora')");
								mysql_query($notificacion);
							}
							else if( $arrayJurado[$i] == 'SUPLENTE')
							{ 
							
								$consulta = sprintf("SELECT Suplente from AsignacionDeSinodal where IdEstudiante = $idAlumno");
								$resultado = conexionMysql($consulta);							
								$suplente = mysql_result($resultado,0,'Suplente');
								$consulta = sprintf("SELECT IdFirma from firmarAutorizaciones where IdEstudiante = $idAlumno and IdProfesor = $suplente");
								$resultado = conexionMysql($consulta);
								$idFirma = mysql_result($resultado,0,'IdFirma');
								$insertar = "update firmarAutorizaciones set IdProfesor = $idSup  where IdFirma = $idFirma";
								mysql_query($insertar);
								
								//notificar al nuevo jurado
				
								$fecha_hora = date("Y-m-d H:i:s");
								$mensaje = 'Fuiste asignado como SUPLENTE debido a un cambio de jurado.';
								$asunto = 'Cambio de jurado';					
					
								$notificacion = sprintf("INSERT INTO MensajesProfesor(IdProfesor,IdAdmon,mensaje,asunto,visto,fechaHora)values('$idSup',1,'$mensaje','$asunto',false,'$fecha_hora')");
								mysql_query($notificacion);
							}
							else if( $arrayJurado[$i] == 'SECRETARIO')
							{ 
								$consulta = sprintf("SELECT Secretario from AsignacionDeSinodal where IdEstudiante = $idAlumno");
								$resultado = conexionMysql($consulta);							
								$secretario = mysql_result($resultado,0,'Secretario');
								$consulta = sprintf("SELECT IdFirma from firmarAutorizaciones where IdEstudiante = $idAlumno and IdProfesor = $secretario");
								$resultado = conexionMysql($consulta);
								$idFirma = mysql_result($resultado,0,'IdFirma');
								$insertar = "update firmarAutorizaciones set IdProfesor = $idS  where IdFirma = $idFirma";
								mysql_query($insertar);
								
								//notificar al nuevo jurado
				
								$fecha_hora = date("Y-m-d H:i:s");
								$mensaje = 'Fuiste asignado como SECRETARIO debido a un cambio de jurado.';
								$asunto = 'Cambio de jurado';					
					
								$notificacion = sprintf("INSERT INTO MensajesProfesor(IdProfesor,IdAdmon,mensaje,asunto,visto,fechaHora)values('$idS',1,'$mensaje','$asunto',false,'$fecha_hora')");
								mysql_query($notificacion);
							}
							
						}
					} 					
					
					
				//actualizar el registro
				$insertar  = "UPDATE cambioJurado SET Presidente=$idP,Secretario=$idS,Vocal=$idV,Suplente=$idSup,motivo='$cadenaCompleta',fecha_hora='$fecha_hora' WHERE IdEstudiante = $idAlumno";
				mysql_query($insertar);
				$insertar  = "UPDATE AsignacionDeSinodal SET Presidente=$idP,Secretario=$idS,Vocal=$idV,Suplente=$idSup WHERE IdEstudiante = $idAlumno";
				mysql_query($insertar);
					 
				}
				else
				{
				 	//no hay un registro de cambio de jurado para el alumno seleccionado
				 	$insertar = "INSERT INTO cambioJurado(IdEstudiante,Presidente,Secretario,Vocal,Suplente,motivo,fecha_hora)values($idAlumno,$idP,$idS,$idV,$idSup,'$cadenaCompleta','$fecha_hora')";
					 	mysql_query($insertar);
				}
				  //header("Location: listaAlumnos.php");
				//header("Location: listaAlumnos.php?alumnos=$idAlumno&documento=doc12");
				
			}
			else 
			{
				echo "<div class='error'>";
					echo "<center><p>LO SENTIMOS NO HA REALIZADO NINGÚN CAMBIO DE JURADO</center></p>";
				echo "</div>";
				
				//$self = $_SERVER['PHP_SELF']; //Obtenemos la página en la que nos encontramos
				//header("refresh:4; url=$self"); //Refrescamos la pagina
			}
			
		}
		else 
		{
			echo "<div class='error'>";
				echo "<center><label>EL ALUMNO SELECCIONADO NO TIENE ASIGNADO REVISORES</label></center>";
			echo "</div>";
			//$self = $_SERVER['PHP_SELF']; //Obtenemos la página en la que nos encontramos
			//header("refresh:4; url=$self"); //Refrescamos la pagina
		}
				
	}
?>


<html lang="es">
<head>

	<!--hoja de estilo para un iframe-->
	
	<style type="text/css">
		#iframe
    	{
    		overflow:auto;
    		width:700px;
    		height:200px;
    	}
    	div.error
    	{
    		position:absolute; top:430px; left:525px;
			width: 300px;
			padding: 5px;
			border: solid 2px red;;
			color: red;	
		}
	</style>
	
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	
	<title>Cambio | jurado</title>

	<link rel="shortcut icon" href="gt_favicon.png">
	
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="bootstrap.min.css">
	<link rel="stylesheet" href="font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="main.css">
		<meta http-equiv="content-type" content="text/html; charset=UTF-8" />	
		
	<link rel="stylesheet" type="text/css" href="select_dependientes.css">
	
		<script>
		
		  function Block()
		  {
		  				
				var checkPresidente = document.getElementById('cambia_presidente');
				var listaPresidente = document.getElementById('presidente');
				
				var checkSecretario = document.getElementById('cambia_secretario');
				var listaSecretario = document.getElementById('secretario')
				
				var checkVocal = document.getElementById('cambia_vocal');
				var listaVocal = document.getElementById('vocal')
				
				var checkSuplente = document.getElementById('cambia_suplente');
				var listaSuplente = document.getElementById('suplente')
				
				//habilita o deshabilita el presidente
				if( checkPresidente.type == 'checkbox' )
				{
					if( checkPresidente.checked == true )
					listaPresidente.disabled = false;
					else
					listaPresidente.disabled = true;		
				}
				//habilita o deshabilita el secretario
				if( checkSecretario.type == 'checkbox' )
				{
					if( checkSecretario.checked == true )
					listaSecretario.disabled = false;
					else
					listaSecretario.disabled = true;		
				}
				//habilita o deshabilita el vocal
				if( checkVocal.type == 'checkbox' )
				{
					if( checkVocal.checked == true )
					listaVocal.disabled = false;
					else
					listaVocal.disabled = true;		
				}
				//habilita o deshabilita el suplente
				if( checkSuplente.type == 'checkbox' )
				{
					if( checkSuplente.checked == true )
					listaSuplente.disabled = false;
					else
					listaSuplente.disabled = true;		
				}		
			}

			function mostrarInfo(id)
			{			
				if (window.XMLHttpRequest)
				{// code for IE7+, Firefox, Chrome, Opera, Safari
				xmlhttp=new XMLHttpRequest();
				}
				else
				{// code for IE6, IE5
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
				}
				xmlhttp.onreadystatechange=function()
				{
				if (xmlhttp.readyState==4 && xmlhttp.status==200)
				{
				document.getElementById("datos").innerHTML=xmlhttp.responseText;
				}else{
				document.getElementById("datos").innerHTML='Cargando...';
				}
				}
				xmlhttp.open("POST","procesaCambioJurado.php",true);
				xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
				xmlhttp.send("id="+id);
			}
			
			function validaForm()
			{	
				//
				if( document.getElementById('motivo').value.length > 0  )
				{
					var expresion = /^[a-zñáéíóú]*(\s*[a-zñáéíóú]*)*[a-zñáéíóú]*$/i;
					//var expresion = /^([a-z ñáéíóú]{2,60})$/i;
					var campo = document.getElementById('motivo').value;
					if( !expresion.test(campo) )
					{
						alert('Contiene caracteres no validos.');
						document.cambio.motivo.focus();
						return false;
					}
				}
				else
				{
					alert('El campo motivo esta vacio.');
					document.cambio.motivo.focus();
					return false;
				}
				
				return true;			
			}

			</script>
			
			</head>

<body>
	<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="index.html"><img src="" alt="Instituto Tecnológico de Zacatepec"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Estudiantes <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="estudiantesregistrados.php">Estudiantes registrados</a></li>
							<li><a href="asignarSinodal.php">Asignar Revisores</a></li>
							<li><a href="listaAlumnos.php">Crear Documentos</a></li>
							<li><a href="cambioJurado.php">Cambio de jurado</a></li>
							<li><a href="cambioTema.php">Cambio de tema de tesis</a></li>
							<li><a href="bitacora2.php">Bitácora</a></li>
							</ul>
					</li>
					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Profesores <b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="consultarFirmas.php">Firmas Registradas</a></li>							
							<li><a href="profesoresregistrados.php">Profesores registrados</a></li>
							<li><a href="firmasOficina.php">Firmas de liberacion</a></li>
						</ul>
					</li>

					<li class="dropdown">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">Administrador<b class="caret"></b></a>
						<ul class="dropdown-menu">
							<li><a href="modificacionesAdministrador.php">Modificaciones</a></li>
							<li><a href="actualizarPlantillas.php">Actualizar plantillas</a></li>
							<li><a href="archivosSubidos.php">Ver plantillas actualizadas</a></li>
							<li><a href="descomprimeZip.php">Descomprimir archivos ZIP</a></li>
						</ul>
					</li>
					
					<?php
					
					$consulta = "select count(*) as MensajesNuevos from MensajesAdministrador where visto = false";
					$resultado = conexionMysql($consulta);
					$mensajes = mysql_result($resultado, 0, 'MensajesNuevos');
					if( $mensajes > 0 ) {
					?>
					<li class="active3"><a class="btn" href="verMensajesAdmon.php"><?php echo $mensajes ?> Mensaje(s)</a></li>
					<?php
					}
					else
						echo '<li class="active"><a class="btn" href="verMensajesAdmon.php">Mensajeria</a></li>';
											
					?>
					<li class="active"><a class="btn" href="salir.php">Salir</a></li>
					<li class="active"><a class="btn" href="perfiladministrador.php">Regresar</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->

	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">
		<ol class="breadcrumb">
			<li><a href="#">Administrador</a></li>
			<li class="active">Cambio de jurado</li>
		</ol>

		<div class="row">
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Cambio de jurado</h1>
				</header>
				
				<div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">
<?php

	function generaAlumnos() 
		{	
			//lista muestra los alumnos registrados	
			//echo "<label>SELECCIONA UN ALUMNO PARA CREAR DOCUMENTO<label>";	
			echo "<select name='alumnos' id='alumnos' onchange='mostrarInfo(this.value)' class='form-control' style='width:300;'>";
			echo "<option value='0'>Selecciona un alumno</option>";
			//Formular la consulta
			$consulta = sprintf("SELECT Estudiante.Nombre,Estudiante.Apellidos,Estudiante.IdEstudiante FROM Estudiante,AsignacionDeSinodal where AsignacionDeSinodal.IdEstudiante = Estudiante.IdEstudiante");
			$resultado = conexionMysql($consulta);			
			while($fila = mysql_fetch_assoc($resultado))
			{
				$id= $fila['IdEstudiante'];
				echo "<option value=$id ";
					/*if( $_POST["alumnos"] == $id )
					{ 
					echo "selected='selected'"; 
					}*/
					echo ">";
				echo replace($fila['Nombre']) . " " . replace($fila['Apellidos']);
				echo "</option>";
			}
			echo "</select>";
		}

	

?>



							<hr>
							<label>SELECCIONA UN ALUMNO</label>
							
	<form name='cambio' action='cambioJurado.php' method='post' onsubmit="return validaForm()">
		<center>
			<?php
				generaAlumnos();			
			?>	
		</center>		
		
		<center>
			<div id="datos"></div>
		</center>
	<form>	
		
						</div>
					</div>
				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer" class="top-space">

		<div class="footer1">
			<div class="container">
				<div class="row">
					<div class="col-md-3 widget">
						<h3 class="widget-title">Contacto</h3>
						<div class="widget-body">
							<p>Departamento de Sistemas y computación<br>Ext. 277</p>
						</div>
					</div>

					<div class="col-md-3 widget">
						<h3 class="widget-title">Desarrollaron</h3>
						<div class="widget-body">
							<p>* Osvaldo Muñoz Vences<br>* Ivan Barrientos González</p>
						</div>
					</div>

					<div class="col-md-6 widget">
						<h3 class="widget-title">Datos generales</h3>
						<div class="widget-body">
							<p>
								Instituto Tecnológico de Zacatepec<br>
								Calzada Tecnológico No. 27, C.P. 62780, Zacatepec de Hidalgo, Morelos. A.P. 45<br>
								Tels. Dir. Fax 01 (734) 343-41-41, Conmut. 343-13-94, 343-21-10, 343-21-11, 343-07-23, 343-01-02, 343-41-42 
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>

		<div class="footer2">
			<div class="container">
				<div class="row">
					<div class="col-md-6 widget">
						<div class="widget-body">
						</div>
					</div>

					<div class="col-md-6 widget">
						<div class="widget-body">
							<p class="text-right">
								Algunos derechos reservados &copy; 2015
							</p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		
	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="/headroom.min.js"></script>
	<script src="/jQuery.headroom.min.js"></script>
	<script src="/template.js"></script>
</body>
</html>
