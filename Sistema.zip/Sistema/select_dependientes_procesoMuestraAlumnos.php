<?php

include 'funciones.php';

// Array que vincula los IDs de los selects declarados en el HTML con el nombre de la tabla donde se encuentra su contenido
$listadoSelects=array(
"puestos"=>"puestos",
"Estudiantes"=>"Estudiante"
);

function validaSelect($selectDestino)
{
	// Se valida que el select enviado via GET exista
	global $listadoSelects;
	if(isset($listadoSelects[$selectDestino])) return true;
	else return false;
}

function validaOpcion($opcionSeleccionada)
{
	// Se valida que la opcion seleccionada por el usuario en el select tenga un valor de cadena de texto
	if(is_string($opcionSeleccionada)) return true;
	else return false;
}

function replace($cadena) {
	$cadena = str_replace("&AACUTE;", "Á", $cadena);
	$cadena = str_replace("&EACUTE;", "É", $cadena);
	$cadena = str_replace("&IACUTE;", "Í", $cadena);
	$cadena = str_replace("&OACUTE;", "Ó", $cadena);
	$cadena = str_replace("&UACUTE;", "Ú", $cadena);
	$cadena = str_replace("&NTILDE;", "Ñ", $cadena);
	$cadena = str_replace("&aacute;", "á", $cadena);
	$cadena = str_replace("&eacute;", "é", $cadena);
	$cadena = str_replace("&iacute;", "í", $cadena);
	$cadena = str_replace("&oacute;", "ó", $cadena);
	$cadena = str_replace("&uacute;", "ú", $cadena);
	$cadena = str_replace("&ntilde;", "ñ", $cadena);
	return $cadena;
}
$selectDestino=$_GET["select"]; $opcionSeleccionada=$_GET["opcion"];

if(validaSelect($selectDestino) && validaOpcion($opcionSeleccionada))
{
	session_name("loginUsuario");
	session_start();			
	
	$idAdmon = $_SESSION["id"];	
	
		if( $opcionSeleccionada == "Estudiante" ) 
		{
			$_SESSION['tabla'] = 'Estudiante';			
			
			$consulta = "SELECT Nombre,Apellidos ,IdEstudiante FROM Estudiante";
			$resultado = conexionMysql($consulta);
			
			echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
 				while( $fila = mysql_fetch_assoc($resultado)) 
				{
					echo "<option value=".$fila['IdEstudiante'].">"; echo replace($fila['Nombre'])." ".replace($fila['Apellidos']); echo "</option>";
				}
			echo "</SELECT>";
		}
		if( $opcionSeleccionada == "Profesor" ) 
		{
			$_SESSION['tabla'] = 'Profesor';			
			
			$consulta = "SELECT Nombre,Apellidos ,IdProfesor FROM Profesor";
			$resultado = conexionMysql($consulta);
			
			echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
 				while( $fila = mysql_fetch_assoc($resultado)) 
				{
					echo "<option value=".$fila['IdProfesor'].">"; echo replace($fila['Nombre'])." ".replace($fila['Apellidos']); echo "</option>";
				}
			echo "</SELECT>";
		}
		
		if( $opcionSeleccionada == "admons" ) 
		{
			$_SESSION['tabla'] = 'Administrador';				
				
			$consulta = "SELECT * from Administrador";																		
			$resultado = conexionMysql($consulta);
 
				echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='form-control'>";
						if( $idAdmon == 1) {
							echo "<option value='admon2'>".replace(mysql_result($resultado,1,'Nombre'))."(Coordinacion titulación)</option>";		
						}
						else {
 							echo "<option value='admon1'>".replace(mysql_result($resultado,0,'Nombre'))."(Administrador)</option>";
 						}

				echo "</SELECT>";
		}				
	}
?>